#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/select.h>
#include <errno.h>
#include <string.h>

#define PIPE_READ 0
#define PIPE_WRITE 1
#define BUFFER_SIZE 1024

int spawn_child_and_capture_output(const char *command, char *const args[]) {
    int stdout_pipe[2];
    int stderr_pipe[2];
    pid_t pid;
    fd_set read_fds;
    char buffer[BUFFER_SIZE];
    int max_fd;
    ssize_t count;

    if (pipe(stdout_pipe) != 0 || pipe(stderr_pipe) != 0) {
        perror("pipe");
        return -1;
    }

    if ((pid = fork()) == -1) {
        perror("fork");
        return -1;
    }

    if (pid == 0) { // Child process
        // Redirect stdout to the write end of stdout_pipe
        dup2(stdout_pipe[PIPE_WRITE], STDOUT_FILENO);
        close(stdout_pipe[PIPE_READ]);
        close(stdout_pipe[PIPE_WRITE]);

        // Redirect stderr to the write end of stderr_pipe
        dup2(stderr_pipe[PIPE_WRITE], STDERR_FILENO);
        close(stderr_pipe[PIPE_READ]);
        close(stderr_pipe[PIPE_WRITE]);

        // Execute the command
        /*execvp(command, args);*/
        /*perror("execvp");*/
        sleep(5);
        exit(EXIT_FAILURE);
    } else { // Parent process
        // Close unused write ends
        close(stdout_pipe[PIPE_WRITE]);
        close(stderr_pipe[PIPE_WRITE]);

        // Initialize the read file descriptor set
        max_fd = (stdout_pipe[PIPE_READ] > stderr_pipe[PIPE_READ]) ? stdout_pipe[PIPE_READ] : stderr_pipe[PIPE_READ];

        while (1) {
            FD_ZERO(&read_fds);
            FD_SET(stdout_pipe[PIPE_READ], &read_fds);
            FD_SET(stderr_pipe[PIPE_READ], &read_fds);

            printf("select\n");
            int ret = select(max_fd + 1, &read_fds, NULL, NULL, NULL);
            if (ret < 0) {
                perror("select");
                break;
            } else if (ret == 0) {
                continue;
            }

            // Read from stdout
            if (FD_ISSET(stdout_pipe[PIPE_READ], &read_fds)) {
                count = read(stdout_pipe[PIPE_READ], buffer, BUFFER_SIZE);
                if (count == -1) {
                    perror("read stdout");
                    break;
                } else if (count == 0) {
                    // EOF
                    printf("stdout_pipe read EOF\n");
                    FD_CLR(stdout_pipe[PIPE_READ], &read_fds);
                    close(stdout_pipe[PIPE_READ]);
                } else {
                    fwrite(buffer, 1, count, stdout);
                }
            }

            // Read from stderr
            if (FD_ISSET(stderr_pipe[PIPE_READ], &read_fds)) {
                count = read(stderr_pipe[PIPE_READ], buffer, BUFFER_SIZE);
                if (count == -1) {
                    perror("read stderr");
                    break;
                } else if (count == 0) {
                    // EOF
                    printf("stderr_pipe read EOF\n");
                    FD_CLR(stderr_pipe[PIPE_READ], &read_fds);
                    close(stderr_pipe[PIPE_READ]);
                } else {
                    fwrite(buffer, 1, count, stderr);
                }
            }

            // Check if both pipes are closed
            if (FD_ISSET(stdout_pipe[PIPE_READ], &read_fds) == 0 &&
                FD_ISSET(stderr_pipe[PIPE_READ], &read_fds) == 0)
            {
                break;
            }
        }

        // Wait for the child process to finish
        waitpid(pid, NULL, 0);
    }

    return 0;
}

int main() {
    char *args[] = {"ls", "-l", "/tmp", NULL};
    spawn_child_and_capture_output("ls", args);
    return 0;
}
