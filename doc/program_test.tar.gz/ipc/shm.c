#include <fcntl.h>           // For O_* constants
#include <sys/mman.h>        // For shm_open, mmap
#include <unistd.h>          // For ftruncate, close
#include <string.h>          // For strcpy
#include <stdio.h>           // For printf

#define SHM_NAME "/my_shm"
#define SHM_SIZE 4096

int main() {
    // Create shared memory object
    int shm_fd = shm_open(SHM_NAME, O_CREAT | O_RDWR, 0666);
    if (shm_fd == -1) {
        perror("shm_open");
        return 1;
    }

    // Set the size of the shared memory object
    if (ftruncate(shm_fd, SHM_SIZE) == -1) {
        perror("ftruncate");
        return 1;
    }

    // Map shared memory object into the process's address space
    void *shm_ptr = mmap(0, SHM_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
    if (shm_ptr == MAP_FAILED) {
        perror("mmap");
        return 1;
    }

    // Write a message to the shared memory
    const char *message = "Hello from the writer process!";
    strcpy((char *)shm_ptr, message);
    printf("1- Message written to shared memory: %s\n", message);
    sleep(1000);


/*
 *    if (shm_unlink(SHM_NAME) == -1) {
 *        perror("shm_unlink");
 *        return 1;
 *
 *    }
 *    printf("Unlink Shared memory object '%s'\n", SHM_NAME);
 *
 */
    // Cleanup
    munmap(shm_ptr, SHM_SIZE);
    close(shm_fd);
    printf("Unmap Shared memory object '%s'\n", SHM_NAME);

    /*printf("2- Message written to shared memory: %s\n", (char *)shm_ptr);*/

    return 0;
}
