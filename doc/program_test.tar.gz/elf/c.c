int share = 1;


int foo(int a)
{
    return (3+a);
}

