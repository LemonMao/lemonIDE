#include <stdio.h>
/*#include <string>*/

extern int share;
extern int foo(int a);

int global_init_val = 1234;
int global_un_init_val;
/*std::string global_string = "global string!";*/
void my_init(void)__attribute__ ((constructor));
void my_init()
{
    printf("Hello ");
}

static int localFoo()
{
    return 5;
}

int main(int argc, const char *argv[])
{
    static int status;
    int a;

    printf("World!");
    status = foo(share);
    a = 2 + status + global_un_init_val + global_init_val;
    printf("Get status:%d, a:%d", status, a);

    return 0;
} /* end of main */
