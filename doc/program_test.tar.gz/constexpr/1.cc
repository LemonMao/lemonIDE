#include <stdio.h>
#include <iostream>
#include <array>

class Foo
{
public:
    constexpr Foo(int a=0, int b=0) : a(a), b(b) {}
public:
    int a;
    int b;
};

constexpr                                   //pow是绝不抛异常的
int pow(int base, int exp) noexcept         //constexpr函数
{
    int result = 1;
    while (exp)
    {
        if (exp & 1)
            result *= base;
        exp >>= 1;
        base *= base;
    }
    return result;
}

void LsFoo(Foo &foo)
{
    std::cout << "Non-const: a-" << foo.a << ", b-" << foo.b << std::endl;
}
void LsFoo(const Foo &foo)
{
    std::cout << "Const: a-" << foo.a << ", b-" << foo.b << std::endl;
}

void lsConstExpr(int a)
{
    std::cout << "lsConstExpr: " << std::endl;
}

int main(int argc, const char *argv[])
{
    /* compile error:need constant expression
     *int a=3;
     *constexpr Foo foo1{a,2};
     */
    // compile ok: 
    constexpr int a=3;
    constexpr Foo foo1{a,2};

    //LsFoo(foo1);

    int c=1, b=2;
    //int arr[pow(foo1.a, foo1.b)];
    //int arr2[pow(c, b)];
    std::array<int, pow(foo1.a, foo1.b)> sarr1;
    std::array<int, pow(c, b)> sarr2;
    return 0;
} /* end of main */
