#ifndef _MYVALUE3_H_
#define _MYVALUE3_H_

#include "kv.cpp"

class request_store : public kvstore
{
public:
    // constructor and destructor
    request_store();
    ~request_store() = default;

    // default copyable and moveable
    request_store(const request_store &) = default;
    request_store& operator=(const request_store &) = default;
    request_store(request_store &&) = default;
    request_store& operator=(request_store &&) = default;

};

template <>
bool Decode<MyValue3>(MyValue3& value, const std::vector<uint8_t>& data)
{
    if (data.size() != 2)
    {
        return false;
    }

    value.x = data[0];
    value.y = data[1];
    return true;
}

template <>
bool Encode<MyValue3>(std::vector<uint8_t>& data, MyValue3& value)
{
    data.push_back(value.x);
    data.push_back(value.y);
    return true;
}



#endif /* end of include guard: _MYVALUE3_H_ */
