#ifndef _KV_H_
#define _KV_H_

#include <ctime>
#include <map>
#include <vector>

/*
 *template <class T>
 *bool Encode(std::vector<uint8_t>& data, T& value)
 *{
 *    static_assert(sizeof(T) != sizeof(T), "A specialization of `Encode<T>()` is required!");
 *    return true;
 *}
 */

template <class T>
bool Decode(T& value, const std::vector<uint8_t>& data)
{
    static_assert(sizeof(T) != sizeof(T), "A specialization of `Decode<T>()` is required!");
    return true;
}

class kvstore
{
public:
    // Why not use T.encode() here? We should ensure that the encoding function works
    // for fundamental types.
    template <typename T>
    bool insert(const char* key, T&& value)
    {
        std::vector<uint8_t> data;
        if (Encode(data, value) == false)
            return false;

        auto [it, ret] = m.insert(std::pair<std::string, std::vector<uint8_t>>(key, data));
        return ret;
    }

    template <typename T>
    bool find(const char* key, T& value)
    {
        auto it = m.find(key);
        if (it != m.end())
        {
            return Decode(value, it->second);
        }
        return false;
    }

private:
    std::map<std::string, std::vector<uint8_t>> m;
};

#endif /* end of include guard: _KV_H_ */
