#include <iostream>
#include "kv.hpp"

class MyValue
{
public:
    int x{0};
    int y{1};

    MyValue() = default;
    MyValue(int x, int y) : x(x), y(y) {}
};

template <>
bool Decode<MyValue>(MyValue& value, const std::vector<uint8_t>& data)
{
    if (data.size() != 2)
    {
        return false;
    }

    value.x = data[0];
    value.y = data[1];
    return true;
}

template <typename T>
auto Encode(std::vector<uint8_t>& data, T& value)
    -> typename std::enable_if<std::is_same<T, MyValue>::value, bool>::type
{
    data.push_back(value.x);
    data.push_back(value.y);
    return true;
}

/*
 *template <typename T,
 *          typename std::enable_if<std::is_same<T, MyValue>::value>::type* = nullptr>
 *bool Encode(std::vector<uint8_t>& data, T& value)
 *{
 *    data.push_back(value.x);
 *    data.push_back(value.y);
 *    return true;
 *}
 */

/*
 *template <>
 *bool Encode<MyValue>(std::vector<uint8_t>& data, MyValue& value)
 *{
 *    data.push_back(value.x);
 *    data.push_back(value.y);
 *    return true;
 *}
 */

class MyValue2
{
public:
    int x;
    int y;
    int z;

    MyValue2() = default;
    MyValue2(int x, int y, int z) : x(x), y(y), z(z) {}
};

template <>
bool Decode<MyValue2>(MyValue2& value, const std::vector<uint8_t>& data)
{
    if (data.size() != 3)
    {
        return false;
    }

    value.x = data[0];
    value.y = data[1];
    value.z = data[2];
    return true;
}

template <typename T>
auto Encode(std::vector<uint8_t>& data, T& value)
    -> typename std::enable_if<std::is_same<T, MyValue2>::value, bool>::type
{
    data.push_back(value.x);
    data.push_back(value.y);
    return true;
}

/*
 *template <>
 *bool Encode<MyValue2>(std::vector<uint8_t>& data, MyValue2& value)
 *{
 *    data.push_back(value.x);
 *    data.push_back(value.y);
 *    data.push_back(value.z);
 *    return true;
 *}
 */

int main(int argc, const char *argv[])
{
    kvstore kv;

    MyValue val;

    if (kv.insert("key1", MyValue(1,3)))
    {
        std::cout << "Successfully insert" << std::endl;
    }
    else
    {
        std::cout << "Failed insert" << std::endl;
    }

    if (kv.find("key1", val) == true)
    {
        std::cout << "Find MyValue:" << val.x << "-" << val.y << std::endl;
    }
    else
    {
        std::cout << "Not found" << std::endl;
    }

    MyValue2 val2;
    if (kv.insert("key2", MyValue2(6,3,4)))
    {
        std::cout << "Successfully insert" << std::endl;
    }
    else
    {
        std::cout << "Failed insert" << std::endl;
    }

    if (kv.find("key2", val2) == true)
    {
        std::cout << "Find MyValue:" << val2.x << "-" << val2.y << std::endl;
    }
    else
    {
        std::cout << "Not found" << std::endl;
    }

    return 0;
} /* end of main */
