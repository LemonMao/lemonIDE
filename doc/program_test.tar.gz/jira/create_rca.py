import requests
import json
import sys
import os
import getpass

jira_url = "https://jira.cec.lab.emc.com"

# Get Jira credentials
username = os.environ.get('USERNAME')
if not username:
    username = input("Enter username: ")

password = os.environ.get('PASSWORD')
if not password:
    password = getpass.getpass("Enter password: ")

# Get issue ID
if len(sys.argv) != 2:
    print("Usage: python3 get_issue_details.py ISSUE_ID")
    quit()
issue_id = sys.argv[1]
if not issue_id:
    issue_id = input("Enter issue ID: ")

print(f"#1 - Prepare to get the information of issue {issue_id}...\n...\n...")

url = f"{jira_url}/rest/api/2/issue/{issue_id}"
auth = (username, password)
print("Request for url : ", url)
response = requests.get(url, auth=auth, verify=False)

# Build the API endpoint URL
url = f"{jira_url}/rest/api/2/issue/{issue_id}"
auth = (username, password)
print("Request for url : ", url)
response = requests.get(url, auth=auth, verify=False)

# Check for successful response
if response.status_code == 200:
  data = response.json()
  issue_data = {}
  issue_data["summary"] = data["fields"]["summary"]
  issue_data["comment"] = []
  for comment in data["fields"]["comment"]["comments"]:
      author_name = comment["author"]["name"]
      if author_name == "svc_nppscaleaa":
          continue
      ct = {}
      ct["author"] = author_name
      ct["body"] = comment["body"]
      issue_data["comment"].append(ct)
  # issue_data["description"] = data["fields"]["description"]

  issue_data = json.dumps(issue_data, indent=4)
  print(f"Issue : {issue_data}")
else:
  print(f"Error retrieving data from {url}: {response.status_code}")
  quit()

print(f"#2 - Get the RCA from LLM...\n...\n...")


