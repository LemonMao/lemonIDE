import requests
import json
import sys
import os
import getpass
from urllib.parse import unquote_plus, quote
from urllib3.exceptions import InsecureRequestWarning

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

def get_comments_nr(comments):
    length = 0
    for comment in comments:
        author_name = comment["author"]["name"]
        # print(f"auth_name: {author_name}")
        if "svc_" in author_name:
            continue
        length += 1
    return length

jira_host = "https://jira.cec.lab.emc.com"
maxResults = os.environ.get('MAX_JIRA_RESULT')
if maxResults is None:
    maxResults = 10

# Get Jira credentials
username = os.environ.get('USERNAME')
if not username:
    username = input("Enter username: ")

password = os.environ.get('PASSWORD')
if not password:
    password = getpass.getpass("Enter password: ")

# Get issue ID
if len(sys.argv) != 2:
    print("Usage: python3 list_comments_len.py <JQL string>")
    quit()

jql = sys.argv[1]
if not jql:
    jql = input("Enter JQL: ")

print(f"#1 - Prepare to get the issues according to JQL- {unquote_plus(jql)}...\n...\n...")

base_url = f"{jira_host}/rest/api/2/search?"
query_str = f"fields=key&maxResults={maxResults}&jql=" + quote(jql)
url = base_url + query_str

auth = (username, password)
print("Request for url : \n...\n", url)
response = requests.get(url, auth=auth, verify=False)

# Check for successful response
if response.status_code == 200:
  data = response.json()
  issues = []
  for issue in data["issues"]:
      issues.append(issue["key"])
  print(f"Issues: {issues}\n...\n")
else:
  print(f"Error retrieving data from {url}: {response.status_code}")
  quit()

print(f"#2 - List the comments length...\n...\n...")
comments = {}
comments["issues"] = []
for issue in issues:
    url = f"{jira_host}/rest/api/2/issue/{issue}"
    print("Request for url : ", url)
    response = requests.get(url, auth=auth, verify=False)

    # Check for successful response
    if response.status_code == 200:
        data = response.json()
        issue_data = {}
        issue_data["issue_id"] = issue
        issue_data["comment_len"] = get_comments_nr(data["fields"]["comment"]["comments"])
        comments["issues"].append(issue_data)
    else:
        print(f"Error retrieving data from {url}: {response.status_code}")
        continue

comments["issues"] = sorted(comments["issues"], key=lambda issue: issue["comment_len"])
print(f"Issue : {json.dumps(comments, indent=4)}")
# print(f"#2 - Get the RCA from LLM...\n...\n...")


