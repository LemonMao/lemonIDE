/* -*- mode: c; c-basic-offset: 4; indent-tabs-mode: nil; tab-width: 4 -*-
 * ex: set softtabstop=4 tabstop=8 expandtab shiftwidth=4: *
 * Editor Settings: expandtabs and use 4 spaces for indentation
 */

/*
 * Copyright (C) 2023 Dell Inc. All Rights Reserved.
 *
 */

#include <iostream>
#include "CmdManager.hpp"

int main(int argc, const char *argv[])
{
    try
    {
        // Process command line...
        CmdManager::Instance().Initialize();
        CmdManager::Instance().ProcessCmdLine(argc, argv);
    }
    catch (const std::exception &ex)
    {
        std::cerr << "Failure: " << ex.what() << '\n';
    }
    catch (...)
    {
        std::cerr << "Failure: Unknown exception" << '\n';
    }
}
