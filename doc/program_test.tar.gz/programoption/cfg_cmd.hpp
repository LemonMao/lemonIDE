/* -*- mode: c; c-basic-offset: 4; indent-tabs-mode: nil; tab-width: 4 -*-
 * ex: set softtabstop=4 tabstop=8 expandtab shiftwidth=4: *
 * Editor Settings: expandtabs and use 4 spaces for indentation
 */

/*
 * Copyright (C) 2023 Dell Inc. All Rights Reserved.
 *
 */

#ifndef _CFG_CMD_H_
#define _CFG_CMD_H_

class get_cmd : public cfg_cmd
{
public:
    // constructor and destructor
    get_cmd();
    ~get_cmd() = default;

    // non-copyable and non-moveable
    get_cmd(const get_cmd&) = delete;
    get_cmd& operator=(const get_cmd&) = delete;
    get_cmd(get_cmd&&) = delete;
    get_cmd& operator=(get_cmd&&) = delete;

    // interfaces
    void parser() override;
    void execute() override;

private:

};


parser()
{
    display_vec_string(opts);

    options_description desc_("Options");
    desc.add_options()
        ("id,i", value<std::string>(), "id")
        ("ep", value<std::string>(), "ep");

    // display help info and return
    if (show_help)
    {
        std::cout << "usage: ciamctl get <args> [options]\n\n"
            << "Get ciam configuration from endpoints.\n"
            //<< display_support_endpoints()
            << "Support endpoints:\n"
            << "   client\n"
            << "   tenant\n"
            << "\n"
            << desc
            << std::endl;

        return ;
    }

    positional_options_description pos;
    pos.add("ep", 1);

    // Parse again...
    variables_map vm;
    parsed_options parsed = command_line_parser(opts).
        options(desc).
        positional(pos).
        run();
    store(parsed, vm);

    if (!vm.count("ep"))
    {
        std::cout << "Error: Expect endpoint." << std::endl;
        return ;
    }

    //std::string ep;
    auto ep = vm["ep"].as<std::string>();

    std::cout << "get " << ep << " -i " << vm["id"].as<std::string>() << std::endl;
}

class cfg_cmd
{
public:
    // constructor and destructor
    cfg_cmd()
        : desc_()
        , pos_()
        , vm_()

    {

    };
    ~cfg_cmd() = default;

    // non-copyable and non-moveable
    cfg_cmd(const cfg_cmd &) = delete;
    cfg_cmd& operator=(const cfg_cmd &) = delete;
    cfg_cmd(cfg_cmd &&) = delete;
    cfg_cmd& operator=(cfg_cmd &&) = delete;

    //interfaces
    virtual void parser();
    virtual void execute();

    auto& get_desc() { return desc_; };
    auto& get_pos() { return pos_; };

protected:
    options_description desc_;
    positional_options_description pos_;
    variables_map vm_;
    std::string help_;
};


#endif /* end of include guard: _CFG_CMD_H_ */


