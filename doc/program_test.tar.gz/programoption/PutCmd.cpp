/* -*- mode: c; c-basic-offset: 4; indent-tabs-mode: nil; tab-width: 4 -*-
 * ex: set softtabstop=4 tabstop=8 expandtab shiftwidth=4: *
 * Editor Settings: expandtabs and use 4 spaces for indentation
 */

/*
 * Copyright (C) 2023 Dell Inc. All Rights Reserved.
 *
 */


#include <cstdlib>
#include <exception>
#include "CmdNode.hpp"
#include "PutCmd.hpp"

namespace po = boost::program_options;

PutCmd::PutCmd()
    : CmdNode
      {
          "put", "Create and modify CIAM configuration.",
          "Examples:\n"
          "  #ciamctl put client -d {\"name\":\"xxx\"}\n"
          "  #ciamctl put client -d {\"name\":\"xxx\"} -i 0000-0000",
      }
{
}

CmdResult
PutCmd::ParseCmdLine(int argc, char **argv)
{
    optDesc_.add_options()
        ("help,h", "Help information")
        ("ep", po::value<std::string>(), "endpoint of CIAM configuration");

    pos_.add("ep", 1);

    po::parsed_options parsed = po::command_line_parser(argc, argv).
        options(optDesc_).
        positional(pos_).
        run();
    po::store(parsed, vm_);

    // mandatory validation
    if (vm_.count("help"))
    {
        return CmdResult::HELP;
    }
    else if (!vm_.count("ep"))
    {
        throw std::runtime_error("Expect endpoint.");
    }

    return CmdResult::OK;
}

void
PutCmd::DoCommand()
{
    auto ep = vm_["ep"].as<std::string>();
    std::cout << "put " << ep << std::endl;
}
