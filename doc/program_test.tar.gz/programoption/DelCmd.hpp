/* -*- mode: c; c-basic-offset: 4; indent-tabs-mode: nil; tab-width: 4 -*-
 * ex: set softtabstop=4 tabstop=8 expandtab shiftwidth=4: *
 * Editor Settings: expandtabs and use 4 spaces for indentation
 */

/*
 * Copyright (C) 2023 Dell Inc. All Rights Reserved.
 *
 */


#ifndef _DELCMD_H_
#define _DELCMD_H_


#include "CmdNode.hpp"

class DelCmd : public CmdNode
{
public:
    // constructor and destructor
    DelCmd();
    ~DelCmd() = default;

    // non-copyable and non-moveable
    DelCmd(const DelCmd &) = delete;
    DelCmd& operator=(const DelCmd &) = delete;
    DelCmd(DelCmd &&) = delete;
    DelCmd& operator=(DelCmd &&) = delete;

    void DoCommand() override;
    CmdResult ParseCmdLine(int argc, char **argv) override;

private:
    //ciam_config ccfg_;
};


#endif /* end of include guard: _DELCMD_H_ */
