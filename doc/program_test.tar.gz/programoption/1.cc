#include <iostream>
#include <string>
#include <boost/program_options.hpp>
#include <vector>

using namespace boost::program_options;

int main(int argc, char** argv)
{
    try
    {
        namespace po = boost::program_options;

        po::options_description global("Global options");
        global.add_options()
            ("debug,d", "Turn on debug output")
            ("command", po::value<std::string>(), "command to execute");
            //("subargs", po::value<std::vector<std::string> >(), "Arguments for command");

        po::positional_options_description pos;
        pos.add("command", 1);
            //add("subargs", -1);

        po::variables_map vm;

        std::vector<std::string> opts {"xx", "--debug"};
        po::parsed_options parsed = po::command_line_parser(opts).
        //po::parsed_options parsed = po::command_line_parser(argc, argv).
            options(global).
            positional(pos).
            allow_unregistered().
            run();

        po::store(parsed, vm);


        auto cmd = vm["command"].as<std::string>();
        std::cout << "cmd is " << cmd << std::endl;

        /*
         *auto args = vm["subargs"].as<std::vector<std::string>>();
         *std::cout << "args:[";
         *for (auto &it : args)
         *{
         *    std::cout << it << ", ";
         *}
         *std::cout << "]" << std::endl;
         */
    }
    catch (const error &ex)
    {
        std::cerr << ex.what() << '\n';
    }
}

