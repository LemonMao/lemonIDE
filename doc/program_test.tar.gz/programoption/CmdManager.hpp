/* -*- mode: c; c-basic-offset: 4; indent-tabs-mode: nil; tab-width: 4 -*-
 * ex: set softtabstop=4 tabstop=8 expandtab shiftwidth=4: *
 * Editor Settings: expandtabs and use 4 spaces for indentation
 */

/*
 * Copyright (C) 2023 Dell Inc. All Rights Reserved.
 *
 */

#ifndef _CMDMANAGER_H_
#define _CMDMANAGER_H_

#include <map>
#include <memory>
#include <string>
#include "CmdNode.hpp"

class CmdManager
{
public:
    using CmdNodePtr  = std::shared_ptr<CmdNode>;
    using CmdListType = std::map<std::string, CmdNodePtr>;

    // constructor and destructor
    CmdManager();
    ~CmdManager() = default;

    // non-copyable and non-moveable
    CmdManager(const CmdManager &) = delete;
    CmdManager& operator=(const CmdManager &) = delete;
    CmdManager(CmdManager &&) = delete;
    CmdManager& operator=(CmdManager &&) = delete;

    static CmdManager& Instance();
    void Initialize();
    void ProcessCmdLine(int argc, const char **argv);

private:
    void ShowUsage();

private:
    std::map<std::string, CmdNodePtr> cmdList_;
};


#endif /* end of include guard: _CMDMANAGER_H_ */
