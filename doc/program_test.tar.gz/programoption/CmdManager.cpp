/* -*- mode: c; c-basic-offset: 4; indent-tabs-mode: nil; tab-width: 4 -*-
 * ex: set softtabstop=4 tabstop=8 expandtab shiftwidth=4: *
 * Editor Settings: expandtabs and use 4 spaces for indentation
 */

/*
 * Copyright (C) 2023 Dell Inc. All Rights Reserved.
 *
 */


#include <iostream>
#include <stdexcept>
#include "CmdManager.hpp"
#include "CmdNode.hpp"
#include "GetCmd.hpp"
#include "PutCmd.hpp"
#include "DelCmd.hpp"

CmdManager::CmdManager()
    : cmdList_()
{
}

CmdManager&
CmdManager::Instance()
{
    static CmdManager list;
    return list;
}

void
CmdManager::Initialize()
{
    // Install commands here. Please use upper string.
    cmdList_["GET"]     = std::make_shared<GetCmd>();
    cmdList_["PUT"]     = std::make_shared<PutCmd>();
    cmdList_["DEL"]     = std::make_shared<DelCmd>();
    //cmdList_["PATCH"]   = std::make_shared<PatchCmd>();
    //cmdList_["SERVICE"] = std::make_shared<ServCmd>();
}

// Parses command line arguments.
void
CmdManager::ProcessCmdLine(int argc, const char **argv)
{
    // parse command line
    if (argc > 1 && argv[1])
    {
        std::string inCmd(argv[1]);
        std::transform(inCmd.begin(), inCmd.end(), inCmd.begin(), ::toupper);
        auto it = cmdList_.find(inCmd);
        if ( it != cmdList_.end())
        {
            auto cmdPtr = it->second;
            if (cmdPtr == nullptr)
            {
                ShowUsage();
                return ;
            }

            try
            {
                if (cmdPtr->ParseCmdLine(argc-1, const_cast<char**>(argv)+1)
                    == CmdResult::OK)
                {
                    cmdPtr->DoCommand();
                }
                else
                {
                    cmdPtr->ShowUsage();
                }
            }
            catch (const std::exception& ex)
            {
                cmdPtr->ShowUsage();
                throw;
            }
            return ;
        }

        auto errstr = "No such command " + inCmd;
        throw std::runtime_error(errstr.c_str());
    }

    // Display usage
    ShowUsage();

    return ;
}

void
CmdManager::ShowUsage()
{
    std::cout << "Description:  Command line tool for CIAM server.\n"
              << "Commands are case insensitive. Options are not.\n"
              << "For help with any of those, simply call them with --help/-h.\n\n"
              << "Usage: ciamctl <commands> <args> [options]\n\n"
              << "Available commands:\n";
    for (const auto &[key, cmd] : cmdList_)
    {
        //std::cout.unsetf(std::left);
        std::cout << "  ";
        std::cout.width(20);
        std::cout << std::left << cmd->GetNameStr()
                  << cmd->GetHelpStr()
                  << std::endl;
    }
    std::cout << "\nUse \"cfscli [commands] -h\" for more information about a command." <<std::endl;
}
