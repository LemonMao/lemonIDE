/* -*- mode: c; c-basic-offset: 4; indent-tabs-mode: nil; tab-width: 4 -*-
 * ex: set softtabstop=4 tabstop=8 expandtab shiftwidth=4: *
 * Editor Settings: expandtabs and use 4 spaces for indentation
 */

/*
 * Copyright (C) 2023 Dell Inc. All Rights Reserved.
 *
 */


#ifndef _PUTCMD_H_
#define _PUTCMD_H_

#include "CmdNode.hpp"

class PutCmd : public CmdNode
{
public:
    // constructor and destructor
    PutCmd();
    ~PutCmd() = default;

    // non-copyable and non-moveable
    PutCmd(const PutCmd &) = delete;
    PutCmd& operator=(const PutCmd &) = delete;
    PutCmd(PutCmd &&) = delete;
    PutCmd& operator=(PutCmd &&) = delete;

    void DoCommand() override;
    CmdResult ParseCmdLine(int argc, char **argv) override;

private:
    //ciam_config ccfg_;
};

#endif /* end of include guard: _PUTCMD_H_ */
