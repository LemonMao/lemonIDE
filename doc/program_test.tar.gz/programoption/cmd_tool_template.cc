#include <boost/program_options.hpp>
#include <iostream>
#include <vector>

using namespace boost::program_options;

void display_vec_string(std::vector<std::string> &opts)
{
    std::cout << "opts: [";
    for (auto &it : opts)
    {
        std::cout << it << ", ";
    }
    std::cout << "]" << std::endl;
}

void execute_get(std::vector<std::string> &opts, bool show_help)
{
    display_vec_string(opts);

    options_description desc("Options");
    desc.add_options()
        ("help,h", "Help screen")
        ("id,i", value<std::string>(), "id")
        ("ep", value<std::string>(), "ep");

    // display help info and return
    if (show_help)
    {
        std::cout << "usage: ciamctl get <args> [options]\n\n"
            << "Get ciam configuration from endpoints.\n"
            //<< display_support_endpoints()
            << "Support endpoints:\n"
            << "   client\n"
            << "   tenant\n"
            << "\n"
            << desc
            << std::endl;

        return ;
    }

    positional_options_description pos;
    pos.add("ep", 1);

    // Parse again...
    variables_map vm;
    parsed_options parsed = command_line_parser(opts).
        options(desc).
        positional(pos).
        run();
    store(parsed, vm);

    if (!vm.count("ep"))
    {
        std::cout << "Error: Expect endpoint." << std::endl;
        return ;
    }

    //std::string ep;
    auto ep = vm["ep"].as<std::string>();

    std::cout << "get " << ep << " -i " << vm["id"].as<std::string>() << std::endl;
}

void execute_put(std::vector<std::string> &opts, bool show_help)
{
    options_description desc{"Options"};
    desc.add_options()
        ("help,h", "Help screen")
        ("data,d", value<std::string>(), "get ep")
        ("ep", value<std::string>(), "ep");

    // display help info and return
    if (show_help)
    {
        std::cout << "usage: ciamctl get <args> [options]\n\n"
            << "Get ciam configuration from endpoints.\n"
            //<< display_support_endpoints()
            << "Support endpoints:\n"
            << "   client\n"
            << "   tenant\n"
            << "\n"
            << desc
            << std::endl;

        return ;
    }

    positional_options_description pos;
    pos.add("ep", 1);

    // Parse again...
    variables_map vm;
    parsed_options parsed = command_line_parser(opts).
        options(desc).
        positional(pos).
        run();
    store(parsed, vm);

    if (!vm.count("ep"))
    {
        std::cout << "Error: Expect endpoint." << std::endl;
        return ;
    }

    auto ep = vm["ep"].as<std::string>();

    std::cout << "put " << ep << " -d " << vm["data"].as<std::string>() << std::endl;
}

int main(int argc, const char *argv[])
{
    try
    {
        std::string cmd;

        options_description global_desc{"commands"};
        global_desc.add_options()
            ("help,h", "Help screen")
            ("command", value<std::string>(), "command to execute")
            ("subargs", value<std::vector<std::string> >(), "Arguments for command");

        positional_options_description pos;
        pos.add("command", 1).
            add("subargs", -1);

        variables_map vm;

        parsed_options parsed = command_line_parser(argc, argv).
            options(global_desc).
            positional(pos).
            allow_unregistered().
            run();

        store(parsed, vm);

        if (vm.count("command"))
        {
            cmd = vm["command"].as<std::string>();
        }

        // global help info
        bool show_help = (vm.count("help") > 0);
        if (cmd.empty() && show_help)
        {
            if (show_help)
            {
                std::cout << "usage: ciamctl <commands> <args> [options]\n\n"
                    << "Commands:\n"
                    << "\tget\t" << "Get ciam configuration\n"
                    << "\tput\t" << "Put ciam configuration\n"
                    << std::endl;
                return 0;
            }
        }

        // Collect all the unrecognized options from the first pass. This will include the
        // (positional) command name, so we need to erase that.
        std::vector<std::string> opts = collect_unrecognized(parsed.options, include_positional);
        if (!opts.empty())
        {
            opts.erase(opts.begin());
        }

        // command execution
        if (cmd == "get")
        {
            execute_get(opts, show_help);
        }
        else if (cmd == "put")
        {
            execute_put(opts, show_help);
        }
    }
    catch (const error &ex)
    {
        std::cerr << ex.what() << '\n';
    }
}
