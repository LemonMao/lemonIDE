/* -*- mode: c; c-basic-offset: 4; indent-tabs-mode: nil; tab-width: 4 -*-
 * ex: set softtabstop=4 tabstop=8 expandtab shiftwidth=4: *
 * Editor Settings: expandtabs and use 4 spaces for indentation
 */

/*
 * Copyright (C) 2023 Dell Inc. All Rights Reserved.
 *
 */


#ifndef _GETCMD_H_
#define _GETCMD_H_

#include "CmdNode.hpp"

class GetCmd : public CmdNode
{
public:
    // constructor and destructor
    GetCmd();
    ~GetCmd() = default;

    // non-copyable and non-moveable
    GetCmd(const GetCmd &) = delete;
    GetCmd& operator=(const GetCmd &) = delete;
    GetCmd(GetCmd &&) = delete;
    GetCmd& operator=(GetCmd &&) = delete;

    void DoCommand() override;
    CmdResult ParseCmdLine(int argc, char **argv) override;

private:
    //ciam_config ccfg_;
};




#endif /* end of include guard: _GETCMD_H_ */

