/* -*- mode: c; c-basic-offset: 4; indent-tabs-mode: nil; tab-width: 4 -*-
 * ex: set softtabstop=4 tabstop=8 expandtab shiftwidth=4: *
 * Editor Settings: expandtabs and use 4 spaces for indentation
 */

/*
 * Copyright (C) 2023 Dell Inc. All Rights Reserved.
 *
 */

#ifndef _CMDNODE_H_
#define _CMDNODE_H_

#include <boost/program_options.hpp>
#include <string>
#include <vector>
#include <map>
#include <iostream>

enum class CmdResult
{
    OK,
    FAIL,
    HELP,
};

class CmdNode
{
public:

    // ctor and dtor
    CmdNode(const std::string& name, const std::string &help,
        const std::string &example)
        : name_(name)
        , help_(help)
        , example_(example)
        , optDesc_("Options")
        , pos_()
        , vm_()
    {
    }
    virtual ~CmdNode() {};

    // default copyable and moveable
    CmdNode(const CmdNode &) = default;
    CmdNode& operator=(const CmdNode &) = default;
    CmdNode(CmdNode &&) = default;
    CmdNode& operator=(CmdNode &&) = default;

    virtual void DoCommand() = 0;
    virtual CmdResult ParseCmdLine(int argc, char **argv) = 0;

    void ShowUsage()
    {
        std::cout << "Description:" << "  " << help_ << "\n\n"
            << "Usage:    ciamctl " << name_ << " <args> [options]\n\n"
            << optDesc_ << "\n"
            << example_ << "\n"
            << std::endl;
    }

    const std::string& GetNameStr() const { return name_; };
    const std::string& GetHelpStr() const { return help_; };

protected:
    std::string name_;
    std::string help_;
    std::string example_;
    boost::program_options::options_description optDesc_;
    boost::program_options::positional_options_description pos_;
    boost::program_options::variables_map vm_;
};

#endif /* end of include guard: _CMDNODE_H_ */
