#include <stdio.h>
#include <iostream>
#include <unistd.h>

class Foo
{
public:
    // constructor and destructor
    Foo()
    {
        std::cout << "Default ctor for " << this << std::endl;
    };
    ~Foo()
    {
        std::cout << "Default ~dtor for " << this << std::endl;
    }

    // default copyable and moveable
    Foo(const Foo &x)
    {
        std::cout << "Copy ctor from " << &x << " to " << this  << std::endl;
    }
    Foo& operator=(const Foo &)
    {
        std::cout << "Copy assg for "  << this << std::endl;
        return *this;
    }
    Foo(Foo && x){
        std::cout << "Move cotr from " << &x << " to " << this << std::endl;
    }
    Foo& operator=(Foo &&)
    {
        std::cout << "Move assg for "  << this << std::endl;
        return *this;
    }
    int i {1};
};

static Foo obj;
int main(int argc, const char *argv[])
{
    std::cout << "-- Main Start --" << std::endl;
    sleep(2);
    std::cout << "-- Main End --" << std::endl;
    return 0;
} /* end of main */
