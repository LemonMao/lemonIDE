#include <stdio.h>
#include <iostream>

/*
 *c++ 1.cc -fno-elide-constructors -std=c++17 && ./a.out  && echo -e "------------\n\n\n" && c++ 1.cc  -std=c++17 && ./a.out
 *c++ 1.cc -fno-elide-constructors -std=c++14 && ./a.out  && echo -e " ------------\n\n\n" && c++ 1.cc  -std=c++14 && ./a.out
 */
class Foo
{
public:
    // constructor and destructor
    Foo()
    {
        std::cout << "Default ctor for " << this << std::endl;
    };
    ~Foo()
    {
        std::cout << "Default ~dtor for " << this << std::endl;
    }

    // default copyable and moveable
    Foo(const Foo &x)
    {
        std::cout << "Copy ctor from " << &x << " to " << this  << std::endl;
    }
    Foo& operator=(const Foo &)
    {
        std::cout << "Copy assg for "  << this << std::endl;
        return *this;
    }
    Foo(Foo && x){
        std::cout << "Move cotr from " << &x << " to " << this << std::endl;
    }
    Foo& operator=(Foo &&)
    {
        std::cout << "Move assg for "  << this << std::endl;
        return *this;
    }
    int i {1};
};

class Foo2
{
public:
    // constructor and destructor
    Foo2(){};
    ~Foo2() = default;

    // non-copyable and non-moveable
    Foo2(const Foo2 &) = delete;
    Foo2& operator=(const Foo2 &) = delete;
    Foo2(Foo2 &&) = delete;
    Foo2& operator=(Foo2 &&) = delete;

    int i{2};
};



Foo createfoo1()
{
    return Foo();
}

Foo createfoo2()
{
    Foo obj2;
    return obj2;
}

Foo go;
Foo createfoo3()
{
    return go;
}

/*
 *Foo2 createfoo4()
 *{
 *    return Foo2();
 *}
 *
 */
/*
 *Foo2 createfoo5()
 *{
 *    Foo2 obj;
 *    return obj;
 *}
 */

void modifyfoo1(Foo obj)
{
    obj.i = 2;
}

void modifyfoo2(Foo& obj)
{
    obj.i = 2;
}

int main(int argc, const char *argv[])
{
/*
 *    Foo obj;
 *    std::cout << "------start---------" << std::endl;
 *    obj = createfoo2();
 *    //auto obj = createfoo2();
 *    //Foo obj;
 *
 *    std::cout << "------endxxx--------" << std::endl;
 *    std::cout << "\nobj:" << &obj << " ->i:" << obj.i << std::endl;
 */

    /*
     *std::cout << "------start---------" << std::endl;
     *const Foo& obj2 = createfoo3();
     *std::cout << "------endxxx--------" << std::endl;
     */

    std::cout << "------start---------" << std::endl;
    modifyfoo1(go);
    std::cout << "---------------" << std::endl;
    modifyfoo2(go);
    std::cout << "------endxxx--------" << std::endl;
    return 0;
} /* end of main */

