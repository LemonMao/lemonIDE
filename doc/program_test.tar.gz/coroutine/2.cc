#include <coroutine>
#include <iostream>
#include <utility>
#include <exception>

// coroutine interface to deal with a simple task
// - providing resume() to resume the coroutine
class [[nodiscard]] CoroTask {
public:
	struct promise_type;
	using CoroHdl = std::coroutine_handle<promise_type>;

private:
	CoroHdl hdl; // native coroutine handle

public:
	// constructor and destructor:
	CoroTask(auto h)
		: hdl{h} { // store coroutine handle in interface
		}
	~CoroTask() {
		if (hdl) {
			hdl.destroy(); // destroy coroutine handle
		}
	}

	// non-copyable but movable:
	CoroTask(const CoroTask&) = delete;
	CoroTask& operator=(const CoroTask&) = delete;
    CoroTask(CoroTask&& c) noexcept
        : hdl{std::move(c.hdl)} {
            c.hdl = nullptr;
        }
    CoroTask& operator=(CoroTask&& c) noexcept {
        if (this != &c) { // if no self-assignment
            if (hdl) {
                hdl.destroy(); // - destroy old handle (if there is one)
            }
            hdl = std::move(c.hdl); // - move handle
            c.hdl = nullptr; // - moved-from object has no handle anymore
        }
        return *this;
    }

    // promise type to be used by the coroutine
	struct promise_type {
		auto get_return_object() { // init and return the coroutine interface
			return CoroTask{CoroHdl::from_promise(*this)};
		}
		auto initial_suspend() { // initial suspend point
			return std::suspend_always{}; // - suspend immediately
		}

        int coroValue = 0; // last value from co_yield
        auto yield_value(int val) { // reaction to co_yield
            coroValue = val; // - store value locally
            return std::suspend_always{}; // - suspend coroutine
        }

		void unhandled_exception() { // deal with exceptions
			std::terminate(); // - terminate the program
		}
		void return_void() { // deal with the end or co_return;
		}
		auto final_suspend() noexcept { // final suspend point
			return std::suspend_always{}; // - suspend immediately
		}
	};

	// APIs:
    // resume the coroutine
	// - returns whether there is still something to process
	bool resume() const {
		if (!hdl || hdl.done()) {
            // hdl.done() == true/false:
            //   true if the coroutine to which *this refers is suspended at its final suspend point
            //   or false if the coroutine is suspended at other suspend points.
			return false; // nothing (more) to process
		}
		hdl.resume(); // RESUME (blocks until suspended again or the end)
		return !hdl.done();
	}
};

CoroTask coro(const int& max)
{
    std::cout << " CORO " << max << " start\n"; // OOPS: value of max still valid?
    for (int val = 1; val <= max; ++val) { // OOPS: value of max still valid?
        std::cout << " CORO " << val << '/' << max << '\n';
        co_await std::suspend_always{}; // SUSPEND
    }
    std::cout << " CORO " << max << " end\n"; // OOPS: value of max still valid?
}

int main(int argc, const char *argv[])
{
    auto task = coro(10);
    std::cout << "Main: caller start" << '\n';
    while (task.resume()) {
        std::cout << "Main: coro suspend " << '\n';
    }
    std::cout << "Main: caller end" << '\n';
    return 0;
} /* end of main */
