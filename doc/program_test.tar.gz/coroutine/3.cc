#include <coroutine>
#include <iostream>
#include <queue>
#include <thread>
#include <chrono>

// Task structure
struct Task {
    int id;
};

// Coroutine promise type for producers and consumers
struct TaskPromise {
    Task& get_return_object() {
        return task;
    }
    std::suspend_never initial_suspend() {
        // Coroutine will not suspend initially
        return {};
    }
    std::suspend_never final_suspend() noexcept {
        // Coroutine will not suspend at the end
        return {};
    }
    void return_void() {}
    void unhandled_exception() {
        std::terminate();
    }

    Task task;
};

// Producer coroutine
struct Producer {
    struct promise_type : TaskPromise {};
    using handle_type = std::coroutine_handle<promise_type>;

    Producer(handle_type h) : handle(h) {}
    handle_type handle;

    static Producer create_producer(std::queue<Task>& queue, int& id) {
        while (true) {
            Task task{++id};
            queue.push(task);
            std::cout << "Produced task with id: " << task.id << '\n';
            co_await std::suspend_always{};
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
    }
};

// Consumer coroutine
struct Consumer {
    struct promise_type : TaskPromise {};
    using handle_type = std::coroutine_handle<promise_type>;

    Consumer(handle_type h) : handle(h) {}
    handle_type handle;

    static Consumer create_consumer(std::queue<Task>& queue) {
        while (true) {
            if (!queue.empty()) {
                Task task = queue.front();
                queue.pop();
                std::cout << "Consumed task with id: " << task.id << '\n';
            }
            co_await std::suspend_always{};
        }
    }
};

int main() {
    std::queue<Task> taskQueue;
    int taskId = 0;

    // Create producer and consumer coroutines
    auto producer = Producer::create_producer(taskQueue, taskId);
    auto consumer = Consumer::create_consumer(taskQueue);

    while (true) {
        if (!producer.handle.done()) {
            producer.handle.resume();
        }
        if (!consumer.handle.done()) {
            consumer.handle.resume();
        }
    }

    return 0;
}
