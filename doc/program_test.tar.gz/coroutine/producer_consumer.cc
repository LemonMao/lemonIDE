#include <iostream>
#include <queue>
#include <thread>
#include <chrono>
#include <coroutine>

// Task structure
struct Task {
    int id;
};

// Global task queue
std::queue<Task> taskQueue;
bool wakeConsumer = false;
bool wakeProducer = false;

// Coroutine for producer
struct Producer {
    struct promise_type {
        int taskId = 0;
        int sleepSec = 0;

        Producer get_return_object() { return Producer{std::coroutine_handle<promise_type>::from_promise(*this)}; }
        std::suspend_never initial_suspend() { return {}; }
        std::suspend_always final_suspend() noexcept { return {}; }
        auto yield_value(int sec) {
            sleepSec = sec;
            return std::suspend_always{};
        }
        void return_void() {}
        void unhandled_exception() { std::terminate(); }
    };

/*
 *    bool await_ready() const noexcept {
 *        return false; // do suspend
 *    }
 *    void await_suspend(auto hdl) const noexcept {
 *        hdl.
 *    }
 *    void await_resume() const noexcept {
 *        std::cout << " await_resume()\n";
 *    }
 *
 */
    using handle_type = std::coroutine_handle<promise_type>;
    handle_type coro;

    Producer(handle_type h) : coro(h) {}
    Producer(const Producer&) = delete;
    Producer& operator=(const Producer&) = delete;
    Producer(Producer&& other) noexcept : coro(other.coro) { other.coro = nullptr; }
    ~Producer() { if (coro) coro.destroy(); }

/*
 *    Producer corosleep(std::chrono::seconds duration) {
 *        setSleepSec(duration);
 *        co_await 
 *    }
 *
 */
    int get_sleep_time() {
        // return the promise_type sleepSec
        return coro.promise().sleepSec;
    }
    static Producer create() {
        Task task;
        int id = 1;

        while (true) {
            task.id = id++;
            taskQueue.push(task);
            std::cout << " = Producer: Produced task with id: " << task.id << '\n';
            // wakeup consumer and sleep 1 sec
            wakeConsumer = true;
            co_yield 1;
        }
    }
};

// Coroutine for consumer
struct Consumer {
    struct promise_type {
        Consumer get_return_object() { return Consumer{std::coroutine_handle<promise_type>::from_promise(*this)}; }
        std::suspend_never initial_suspend() { return {}; }
        std::suspend_always final_suspend() noexcept { return {}; }
        void return_void() {}
        void unhandled_exception() { std::terminate(); }
    };

    using handle_type = std::coroutine_handle<promise_type>;
    handle_type coro;

    Consumer(handle_type h) : coro(h) {}
    Consumer(const Consumer&) = delete;
    Consumer& operator=(const Consumer&) = delete;
    Consumer(Consumer&& other) noexcept : coro(other.coro) { other.coro = nullptr; }
    ~Consumer() { if (coro) coro.destroy(); }

    static Consumer create() {
        while (true) {
            if (taskQueue.empty()) {
                // empty queue, wait for producer
                co_await std::suspend_always{};
                continue;
            }
            Task task = taskQueue.front();
            taskQueue.pop();
            std::cout << " -Consumer: Consumed task with id: " << task.id << '\n';
        }
    }
};

int main() {
    auto producer = Producer::create();
    auto consumer = Consumer::create();

    // main loop to control all the coroutines
    while (true) {
        if (wakeConsumer && !consumer.coro.done()) {
            consumer.coro.resume();
            wakeConsumer = false;
        }
        else if (wakeProducer && !producer.coro.done()) {
            producer.coro.resume();
            wakeProducer = false;
        }
        else {
            auto sleep_sec = producer.get_sleep_time();
            std::cout << "Main: sleep for " << sleep_sec << std::endl;
            // sleep 0.1 sec
            std::this_thread::sleep_for(std::chrono::seconds(sleep_sec));
            wakeProducer = true;
        }
    }
    return 0;
}
