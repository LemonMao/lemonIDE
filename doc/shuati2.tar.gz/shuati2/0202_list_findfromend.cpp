
#include "prepare.hpp"
using namespace std;

//=============================================================================
// Cate-List
// question:
// 从前往后寻找单链表的第 k 个节点很简单，一个 for 循环遍历过去就找到了，但是如何寻找从后往前数的第 k 个节点呢？
//
// 那你可能说，假设链表有 n 个节点，倒数第 k 个节点就是正数第 n - k + 1 个节点，不也是一个 for 循环的事儿吗？
//
// 是的，但是算法题一般只给你一个 ListNode 头结点代表一条单链表，你不能直接得出这条链表的长度 n，而需要先遍历一遍链表算出 n 的值，然后再遍历链表计算第 n - k + 1 个节点。
//
// 也就是说，这个解法需要遍历两次链表才能得到出倒数第 k 个节点。
//
// 那么，我们能不能只遍历一次链表，就算出倒数第 k 个节点？可以做到的，如果是面试问到这道题，面试官肯定也是希望你给出只需遍历一次链表的解法。
//
// 这个解法就比较巧妙了，假设 k = 2，思路如下：
//=============================================================================
class Solution {
public:
    ListNode* findFromEnd(ListNode* head, int k)
    {
        int idx = 1;
        ListNode* tp = head;
        while (head->next != nullptr)
        {
            if (idx >= k)
            {
                tp = tp->next;
            }
            idx++;
            head = head->next;
        }
        return tp;
    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********" << endl;
    ListNode* input = createList({1,2,3,4,5});
    printList(input);

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    ListNode* result = sol.findFromEnd(input, 3);

    // 3. Print the result
    cout << "*********" << endl;
    printNode(result);

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
