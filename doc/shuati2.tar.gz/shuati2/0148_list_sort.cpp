#include "prepare.hpp"
using namespace std;

//=============================================================================
// Cate-list
// question: 给你链表的头结点 head ，请将其按 升序 排列并返回 排序后的链表 。
//
//=============================================================================
class Solution {
public:
    ListNode* sortList(ListNode* head) {
        if (!head || !(head->next)) {
            return head;
        }

        ListNode* sorted = new ListNode();
        ListNode* cur = head;

        while (cur)
        {
            ListNode* s = sorted;
            ListNode* ncur = cur->next;

            while (s->next && s->next->val < cur->val)
            {
                s = s->next;
            }

            cur->next = s->next;
            s->next = cur;
            cur = ncur;
        }
        return sorted->next;
    }
};

int main(int argc, const char *argv[])
{
    cout << "********* Input" << endl;
    ListNode* input = createList({4,2,1,3});
    printList(input);

    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    ListNode* result = sol.sortList(input);
    printResult(result);

    cout << "*********" << endl;
    return 0;
} /* end of main */
