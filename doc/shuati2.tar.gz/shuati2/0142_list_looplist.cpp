#include "prepare.hpp"
using namespace std;

// Cate-List
//=============================================================================
// question: 环形链表 II
//
// 给定一个链表的头节点  head ，返回链表开始入环的第一个节点。 如果链表无环，则返回 null。
//
// 如果链表中有某个节点，可以通过连续跟踪 next 指针再次到达，则链表中存在环。 为了表示给定链表中的环，
// 评测系统内部使用整数 pos 来表示链表尾连接到链表中的位置（索引从 0 开始）。
// 如果 pos 是 -1，则在该链表中没有环。注意：pos 不作为参数进行传递，仅仅是为了标识链表的实际情况。
//
// 不允许修改 链表。
//
// 输入：head = [3,2,0,-4], pos = 1
// 输出：返回索引为 1 的链表节点
// 解释：链表中有一个环，其尾部连接到第二个节点。
//
// 输入：head = [1,2], pos = 0
// 输出：返回索引为 0 的链表节点
// 解释：链表中有一个环，其尾部连接到第一个节点。
//=============================================================================
class Solution {
public:
#define movestep(x) (x=x->next)
    ListNode* getLoopNode(ListNode* head)
    {
        ListNode* slow = head;
        ListNode* fast = head;
        int fi = 0;
        bool loop = false;

        if (head == nullptr)
        {
            return nullptr;
        }

        while (fast->next != nullptr)
        {
            fast = fast->next;
            fi++;
            if (fi % 2 == 0)
            {
                slow = slow->next;
            }
            if (slow == fast)
            {
                loop = true;
                slow = head;
                break;
            }
        }

        if (fi % 2 != 0)
        {
            fast = fast->next;
        }

        if (loop == false)
        {
            return nullptr;
        }

        while (slow != fast)
        {
            movestep(slow);
            movestep(fast);
        }

        return slow;
    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********" << endl;
    ListNode* input = createList({1,2,3,4});
    printList(input);
    input->next->next->next = input;

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    ListNode* result = sol.getLoopNode(input);

    // 3. Print the result
    cout << "*********" << endl;
    printNode(result);

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
