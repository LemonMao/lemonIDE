#include "prepare.hpp"
#include <algorithm>
#include <stack>
#include <vector>
using namespace std;

//=============================================================================
// Cate-arr
// Question:
// 给定一个循环数组 nums （ nums[nums.length - 1] 的下一个元素是 nums[0] ），返回 nums 中每个元素的 下一个更大元素 。
//
// 数字 x 的 下一个更大的元素 是按数组遍历顺序，这个数字之后的第一个比它更大的数，这意味着你应该循环地搜索它的下一个更大的数。如果不存在，则输出 -1 。
//
//
//
// 示例 1:
//
// 输入: nums = [1,2,1]
// 输出: [2,-1,2]
// 解释: 第一个 1 的下一个更大的数是 2；
// 数字 2 找不到下一个更大的数；
// 第二个 1 的下一个最大的数需要循环搜索，结果也是 2。
//=============================================================================
class Solution {
public:
    vector<int> nextGreaterElement2(vector<int>& nums) {
        int maxi=0, maxv=nums[0];
        for (int i=0; i < nums.size(); i++) {
            if (nums[i] >= maxv) {
                maxi = i;
                maxv = nums[i];
            }
        }

        vector<int> res(nums.size());
        stack<int> s;
        while (maxi >= 0)
        {
            while (!s.empty() && nums[maxi] >= s.top())
            {
                s.pop();
            }
            res[maxi] = s.empty() ? -1 : s.top();
            s.push(nums[maxi]);
            maxi--;
        }

        for (int r=nums.size()-1; r > maxi; r--) {
            while (!s.empty() && nums[r] >= s.top())
            {
                s.pop();
            }
            res[r] = s.empty() ? -1 : s.top();
            s.push(nums[r]);
        }

        return res;
    }

    vector<int> nextGreaterElements(vector<int>& nums) {
        vector<int> res(nums.size());
        stack<int> s;

        s.push(nums[0]);
        for (int i=nums.size()-1; i >= 0 ; i--) {
            int n = nums[i];
            while (!s.empty() && n >= s.top())
            {
                s.pop();
            }
            s.push(n);
        }

        for (int j=nums.size()-1; j >= 0; j--) {
            int v = nums[j];
            while (!s.empty() && v >= s.top())
            {
                s.pop();
            }
            res[j] = s.empty() ? -1 : s.top();
            s.push(v);
        }
        return res;
    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********" << endl;
    std::vector<int> input1{4,1,2};
    printArray(input1);
    std::vector<int> input2{1,3,4,2};
    printArray(input2);

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.nextGreaterElement(input1, input2);

    // 3. Print the result
    cout << "*********" << endl;
    printResult(result);

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
