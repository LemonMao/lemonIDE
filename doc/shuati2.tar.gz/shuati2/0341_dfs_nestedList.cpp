#include "prepare.hpp"
#include <vector>
using namespace std;

//=============================================================================
// question:
//
// 给你一个嵌套的整数列表 nestedList 。每个元素要么是一个整数，要么是一个列表；该列表的元素也可能是整数或者是其他列表。
// 请你实现一个迭代器将其扁平化，使之能够遍历这个列表中的所有整数。
/*
 * 实现扁平迭代器类 NestedIterator ：
 *
 * NestedIterator(List<NestedInteger> nestedList) 用嵌套列表 nestedList 初始化迭代器。
 * int next() 返回嵌套列表的下一个整数。
 * boolean hasNext() 如果仍然存在待迭代的整数，返回 true ；否则，返回 false 。
 * 你的代码将会用下述伪代码检测：
 *
 * initialize iterator with nestedList
 * res = []
 * while iterator.hasNext()
 *     append iterator.next() to the end of res
 * return res
 * 如果 res 与预期的扁平化列表匹配，那么你的代码将会被判为正确。
 *
 *
 *
 * 示例 1：
 *
 * 输入：nestedList = [[1,1],2,[1,1]]
 * 输出：[1,1,2,1,1]
 * 解释：通过重复调用 next 直到 hasNext 返回 false，next 返回的元素的顺序应该是: [1,1,2,1,1]。 */
//=============================================================================
class Solution {
public:
    ListNode* foo()
    {

    }
};

class NestedIterator {
public:
    std::vector<int> res;
    vector<int>::iterator it;
    NestedIterator(vector<NestedInteger> &nestedList) {
        for (auto& node : nestedList) {
            traverse(node);
        }
        it = res.begin();
    }

    int next() {
        int cur = *it;
        it++;
        return cur;
    }

    bool hasNext() {
        return it != res.end();
    }
private:
    void
    traverse(NestedInteger &node)
    {
        if (node.isInteger()) {
            res.push_back(node.getInteger());
            return;
        }

        for (auto& n : node.getList()) {
            traverse(n);
        }
        return;
    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********" << endl;
    ListNode* input = createList({1,2,3});
    printList(input);

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    ListNode* result = sol.foo(input);

    // 3. Print the result
    cout << "*********" << endl;
    printResult(result);

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
