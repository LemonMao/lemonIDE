#include "prepare.hpp"
#include <algorithm>
#include <unordered_map>
#include <unordered_set>
using namespace std;

//=============================================================================
// Cate-str
// Question:
// 给你一个字符串 s 、一个字符串 t 。返回 s 中涵盖 t 所有字符的最小子串。如果 s 中不存在涵盖 t 所有字符的子串，则返回空字符串 "" 。
// 对于 t 中重复字符，我们寻找的子字符串中该字符数量必须不少于 t 中该字符数量。
// 如果 s 中存在这样的子串，我们保证它是唯一的答案。
//
// 示例 1：
// 输入：s = "ADOBECODEBANC", t = "ABC"
// 输出："BANC"
// 解释：最小覆盖子串 "BANC" 包含来自字符串 t 的 'A'、'B' 和 'C'。
//
// 示例 2：
// 输入：s = "a", t = "a"
// 输出："a"
// 解释：整个字符串 s 是最小覆盖子串。
//=============================================================================
class Solution {
public:
    string foo(string_view s, string_view t)
    {
        int l=0, r=0;
        int valid=0;
        int len=0, start=0;
        string res{};
        unordered_map<char, int> need, window;

        for (auto c : t){
            need[c]++;
        }

        while (r < s.size())
        {
            char c = s[r];
            r++;
            if (need.count(c))
            {
                window[c]++;
                if (window[c] == need[c])
                {
                    valid++;
                }
            }

            while (valid == need.size())
            {
                if (len == 0 || r - l < len)
                {
                    start = l;
                    len = r - l;
                }

                char lc = s[l];
                l++;
                if (need.count(lc)) {
                    if (window[lc] == need[lc])
                    {
                        valid--;
                    }
                    window[lc]--;
                }
            }
        }
        return string(s.substr(start, len));
    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********" << endl;
    string input = "cabwefgewcwaefgcf";
    std::cout << "Input: " << input << std::endl;

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.foo(input, "cae");

    // 3. Print the result
    cout << "*********" << endl;
    std::cout << "Result: " << result << std::endl;

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
