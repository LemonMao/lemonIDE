#include "prepare.hpp"
#include <unordered_map>
#include <unordered_set>
using namespace std;

//=============================================================================
// Cate-array
// Question:
// 给定一个未排序的整数数组 nums ，找出数字连续的最长序列（不要求序列元素在原数组中连续）的长度。
// 请你设计并实现时间复杂度为 O(n) 的算法解决此问题。
//
// 示例 1：
// 输入：nums = [100,4,200,1,3,2]
// 输出：4
// 解释：最长数字连续序列是 [1, 2, 3, 4]。它的长度为 4。
//
// 示例 2：
// 输入：nums = [0,3,7,2,5,8,4,6,0,1]
// 输出：9
//
//=============================================================================
class Solution {
public:
    int longestConsecutive(vector<int>& nums) {
        int res = 0;
        unordered_map<int, int> cnt;
        for (auto num : nums) {
            cnt[num]++;
        }

        for (auto& num : nums) {
            int len = 0;
            if (cnt.contains(num-1)) {
                continue;
            }
            while (cnt.contains(num)) {
                len++;
                num++;
            }
            res = max(len, res);
        }
        return res;
    }
};

int main(int argc, const char *argv[])
{
    cout << "********* Input" << endl;
    std::vector<int> input{1,1,3};
    printResult(input);

    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.longestConsecutive(input);
    printResult(result);

    cout << "*********" << endl;
    return 0;
} /* end of main */
