#include "prepare.hpp"
#include <algorithm>
#include <cassert>
#include <climits>
#include <string>
#include <vector>
using namespace std;

class Solution {
public:
    vector<vector<int>> mem;
    int minimumDeleteSum(string s1, string s2) {
        int i = s1.size()-1;
        int j = s2.size()-1;
        mem.resize(i+1, vector<int>(j+1, -1));
        return dp(i, j, s1, s2);
    }

    int dp(int i, int j, string& s1, string& s2) {
        if (i < 0 && j < 0) {
            return 0;
        }
        if (i < 0 && j >= 0) {
            int sum = 0;
            for (; j >=0; j--) {
                sum += s2[j];
            }
            return sum;
        }
        if (j < 0 && i >= 0) {
            int sum = 0;
            for (; i >= 0; i--) {
                sum += s1[i];
            }
            return sum;
        }
        if (mem[i][j] != -1) {
            return mem[i][j];
        }

        int res = 0;
        if (s1[i] == s2[j]) {
            res = dp(i-1, j-1, s1, s2);
        }
        else {
            res = min(dp(i-1, j, s1, s2) + s1[i], dp(i, j-1, s1, s2) + s2[j]);
        }
        mem[i][j] = res;
        return res;
    }

    vector<int> mem2;
    int maxsub = INT_MIN;
    int maxSubArray(vector<int>& nums) {
        mem2.resize(nums.size(), INT_MIN);
        mem2[0] = nums[0];
        maxsub = nums[0];
        for (int i=1; i < nums.size(); i++) {
            maxsub = max(maxsub, dp(nums, i));
        }
        return maxsub;
    }
    int dp(vector<int>& nums, int i) {
        if (mem2[i] != INT_MIN) {
            return mem2[i];
        }
        int res = max(nums[i], dp(nums, i-1)+nums[i]);
        mem2[i] = res;
        return res;
    }

};

class Solution2 {
public:
    vector<vector<string>> res;
    vector<string> strList;

    vector<vector<string>> solveNQueens(int n) {
        vector<std::string> path;
        strList.resize(n, string(n, '.'));
        int i = 0;
        for (auto& str : strList) {
            str[i++] = 'Q';
        }
        backtrace(path, n);
        return res;
    }

    void backtrace(vector<string>& path, int n) {
        if (path.size() == n) {
            res.push_back(path);
            return;
        }

        for (int i=0; i < strList.size(); i++) {
            if (isValidInsert(path, i)) {
                continue;
            }
            path.push_back(strList[i]);
            backtrace(path, n);
            path.pop_back();
        }
    }

    bool isValidInsert(vector<string>& path, int col) {
        int n = path.size();
        for (int i = n-1; n >= 0; i--) {
            if (path[i][col] == 'Q' || path[i][col-(n-i)] == 'Q') {
                return false;
            }
        }
        return true;
    }

    ListNode* getLoopNode(ListNode* head)
    {
        ListNode* l = head;
        ListNode* r = head;

        while (r != nullptr && r->next != nullptr)
        {
            r = r->next->next;
            l = l->next;
            if (r == l) {
                l = head;
                break;
            }
        }
        if (l != head) {
            return nullptr;
        }

        while (r != l)
        {
            r = r->next;
            l = l->next;
        }
        return r;
    }
}

int main(int argc, const char *argv[])
{
} /* end of main */
