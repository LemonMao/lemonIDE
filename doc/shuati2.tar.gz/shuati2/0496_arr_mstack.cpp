#include "prepare.hpp"
#include <algorithm>
#include <stack>
#include <unordered_map>
#include <unordered_set>
#include <vector>
using namespace std;

//=============================================================================
// Cate-arr
// Question:
// nums1 中数字 x 的 下一个更大元素 是指 x 在 nums2 中对应位置 右侧 的 第一个 比 x 大的元素。
// 给你两个 没有重复元素 的数组 nums1 和 nums2 ，下标从 0 开始计数，其中nums1 是 nums2 的子集。
// 对于每个 0 <= i < nums1.length ，找出满足 nums1[i] == nums2[j] 的下标 j ，并且在 nums2 确定 nums2[j]
//  的 下一个更大元素 。如果不存在下一个更大元素，那么本次查询的答案是 -1 。
// 返回一个长度为 nums1.length 的数组 ans 作为答案，满足 ans[i] 是如上所述的 下一个更大元素 。
//
// 示例 1：
//
// 输入：nums1 = [4,1,2], nums2 = [1,3,4,2].
// 输出：[-1,3,-1]
// 解释：nums1 中每个值的下一个更大元素如下所述：
// - 4 ，用加粗斜体标识，nums2 = [1,3,4,2]。不存在下一个更大元素，所以答案是 -1 。
// - 1 ，用加粗斜体标识，nums2 = [1,3,4,2]。下一个更大元素是 3 。
// - 2 ，用加粗斜体标识，nums2 = [1,3,4,2]。不存在下一个更大元素，所以答案是 -1 。
//=============================================================================
class Solution {
public:
    vector<int> nextGreaterElement(vector<int>& nums1, vector<int>& nums2) {
        vector<int> res(nums1.size());
        unordered_map<int, int> map1;
        for (int i = 0; i < nums1.size(); i++) {
            map1[nums1[i]] = i;
        }

        stack<int> stk2;
        for (int i = nums2.size()-1; i >= 0; i--) {
            int v = nums2[i];
            while (!stk2.empty() && v >= stk2.top())
            {
                stk2.pop();
            }
            if (map1.count(v)) {
                res[map1[v]] = stk2.empty() ? -1 : stk2.top();
            }
            stk2.push(v);
        }
        return res;
    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********" << endl;
    std::vector<int> input1{4,1,2};
    printArray(input1);
    std::vector<int> input2{1,3,4,2};
    printArray(input2);

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.nextGreaterElement(input1, input2);

    // 3. Print the result
    cout << "*********" << endl;
    printResult(result);

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
