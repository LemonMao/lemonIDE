#include "../prepare.hpp"
#include <algorithm>
#include <vector>
using namespace std;

//=============================================================================
// Cate-array
// Question:
// 给定一个区间的集合 intervals ，其中 intervals[i] = [starti, endi] 。返回 需要移除区间的最小数量，使剩余区间互不重叠 。
// 注意 只在一点上接触的区间是 不重叠的。例如 [1, 2] 和 [2, 3] 是不重叠的。
// 示例 1:
// 输入: intervals = [[1,2],[2,3],[3,4],[1,3]]
// 输出: 1
// 解释: 移除 [1,3] 后，剩下的区间没有重叠。
//=============================================================================
class Solution {
public:
    int eraseOverlapIntervals(vector<vector<int>>& intervals) {
        return intervals.size() - intervalScheduling(intervals);
    }

    // 算出这些区间中最多有几个互不相交的区间。
    int intervalScheduling(vector<vector<int>>& intervals) {
        if (intervals.size() <= 1) {
            return intervals.size();
        }
        sort(intervals.begin(), intervals.end(), [](auto& v1, auto& v2){
            return v1[1] < v2[1];
        });

        vector<int>* iv = &intervals[0];
        int cnt = 1;
        for (auto& iv2 : intervals) {
            if ((*iv)[1] <= iv2[0]) {
                cnt++;
                iv = &iv2;
            }
        }
        return cnt;
    }
};

int main(int argc, const char *argv[])
{
    cout << "********* Input" << endl;
    std::vector<vector<int>> input{{1,2},{2,3},{3,4},{1,3}};
    printResult(input);

    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    // auto result = sol.eraseOverlapIntervals(input);
    auto result = sol.intervalScheduling(input);
    printResult(result);

    cout << "*********" << endl;
    return 0;
} /* end of main */
