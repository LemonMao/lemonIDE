#include <cstddef> // for size_t

// Forward declarations
void* my_memcpy(void* dest, const void* src, size_t n);
char* my_strcpy(char* dest, const char* src);

/**
 * @brief Copies n bytes from memory area src to memory area dest.
 * The memory areas must not overlap.
 *
 * @param dest Pointer to the destination array where the content is to be copied.
 * @param src Pointer to the source of data to be copied.
 * @param n Number of bytes to copy.
 * @return A pointer to the destination, which is dest.
 */
void* my_memcpy(void* dest, const void* src, size_t n) {
    // According to the C standard, the behavior is undefined if dest or src are null pointers.
    // A robust implementation should check for this.
    if (dest == nullptr || src == nullptr) {
        return dest;
    }

    char* p_dest = static_cast<char*>(dest);
    const char* p_src = static_cast<const char*>(src);

    // A simple byte-by-byte copy.
    // This is the most straightforward and portable implementation.
    for (size_t i = 0; i < n; ++i) {
        p_dest[i] = p_src[i];
    }

    return dest;
}

/**
 * @brief Copies the C string pointed by src to the array pointed by dest,
 * including the terminating null character.
 *
 * The behavior is undefined if the destination buffer is not large enough,
 * or if the strings overlap.
 *
 * @param dest Pointer to the destination array where the content is to be copied.
 * @param src C string to be copied.
 * @return A pointer to the destination, which is dest.
 */
char* my_strcpy(char* dest, const char* src) {
    // Check for null pointers, although standard strcpy has undefined behavior.
    if (dest == nullptr || src == nullptr) {
        return dest;
    }

    char* saved_dest = dest;
    while (*src != '\0') {
        *dest++ = *src++;
    }
    *dest = '\0'; // Don't forget the null terminator

    return saved_dest;
}

/*
// An alternative, more "classic C" implementation of strcpy.
// It's concise but might be considered less readable by some.
char* my_strcpy_oneliner(char* dest, const char* src) {
    if (dest == nullptr || src == nullptr) {
        return dest;
    }
    char* saved_dest = dest;
    while ((*dest++ = *src++)); // The loop condition becomes false after the null terminator is copied.
    return saved_dest;
}
*/


/*
 * =====================================================================================
 * |                                                                                   |
 * |                  INTERVIEW QUESTIONS AND CONSIDERATIONS                           |
 * |                                                                                   |
 * =====================================================================================
 *
 * ### Questions about `memcpy`
 *
 * 1.  **What is the difference between `memcpy` and `memmove`?**
 *     - `memcpy` has undefined behavior if the source and destination memory regions overlap.
 *     - `memmove` is guaranteed to work correctly even if the regions overlap. It does this by checking for overlap and copying direction (forward or backward) to prevent overwriting data that is yet to be copied.
 *
 * 2.  **How would you implement `memmove`?**
 *     - You would cast pointers to `char*`. Then check if `dest` is in the range `[src, src + n)`.
 *     - If `dest < src` (or no overlap), you can copy from start to end (forward).
 *     - If `dest > src` and there is an overlap, you must copy from end to start (backward) to avoid overwriting source bytes before they are read.
 *
 * 3.  **How can this `memcpy` implementation be optimized?**
 *     - The byte-by-byte copy can be slow. A common optimization is to copy data in larger chunks, like `long` or `long long` (word size).
 *     - This involves copying as many full words as possible, then handling any remaining bytes at the beginning or end.
 *
 * 4.  **What are the challenges with the word-by-word copy optimization?**
 *     - **Alignment**: If the `src` or `dest` pointers are not aligned to the word boundary (e.g., a `long*` that doesn't point to an address divisible by `sizeof(long)`), dereferencing them can cause a performance penalty or even a hardware exception (bus error) on some architectures (like older ARM, SPARC).
 *     - A robust implementation would handle unaligned pointers by copying bytes until the destination pointer is aligned, then copying words, and finally copying any remaining bytes.
 *
 * 5.  **What happens if `src` or `dest` is `NULL`?**
 *     - The C/C++ standard says the behavior is undefined.
 *     - A production-quality implementation might check for `NULL` and return immediately, or set `errno` and return `NULL`, or even crash (assert in debug builds). My implementation returns `dest` as is, which is a common behavior.
 *
 * 6.  **Why does `memcpy` return a `void*` to `dest`?**
 *     - It allows for function chaining. For example: `foo(memcpy(dest, src, n));`.
 *
 * ### Questions about `strcpy`
 *
 * 1.  **What is the biggest danger of using `strcpy`?**
 *     - **Buffer Overflows**. `strcpy` does no bounds checking. If the source string is longer than the destination buffer, it will write past the end of the buffer, corrupting adjacent memory, which can lead to crashes and serious security vulnerabilities (e.g., stack smashing).
 *
 * 2.  **What are safer alternatives to `strcpy`?**
 *     - `strncpy(dest, src, n)`: Copies at most `n` characters. However, it has its own problems.
 *     - `snprintf(dest, size, "%s", src)`: A very safe and recommended alternative in C.
 *     - `strlcpy(dest, src, size)`: A safer alternative popular on BSD systems, but not part of the C standard. It guarantees null-termination.
 *     - In C++, `std::string` should be used instead of C-style strings to avoid these issues entirely.
 *
 * 3.  **What are the pitfalls of `strncpy`?**
 *     - If the source string's length is `n` or more, the destination string `dest` will **not** be null-terminated. The programmer must manually add the null terminator.
 *     - If the source string is shorter than `n`, `strncpy` pads the rest of the destination buffer with null characters up to `n` bytes, which can be a performance hit if `n` is large.
 *
 * 4.  **Explain the one-liner implementation: `while ((*dest++ = *src++));`**
 *     - It's a common C idiom that combines copying, pointer incrementing, and checking for the end of the string.
 *     - `*src++`: Reads the character from `src` and then increments `src`.
 *     - `*dest++ = ...`: Assigns that character to where `dest` points, and then increments `dest`.
 *     - `while(...)`: The value of the assignment expression is the character that was copied. The loop continues as long as this character is not `\0` (which has a value of 0, evaluating to false). When `\0` is copied, the loop terminates.
 *
 * 5.  **What if the `src` and `dest` strings for `strcpy` overlap?**
 *     - Like `memcpy`, the behavior is undefined. `memmove` should be used if overlap is possible (though `memmove` doesn't handle null terminators, you'd need to calculate the length first).
 *
 */

