#include "prepare.hpp"
using namespace std;

//=============================================================================
// Cate-string
// Question:
//
//=============================================================================
class Solution {
public:
    foo()
    {

    }
};

int main(int argc, const char *argv[])
{
    cout << "********* Input" << endl;
    string input = "abcbdbdb";
    std::cout << "Input: " << input << std::endl;

    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.foo(input);
    std::cout << "Result: " << result << std::endl;

    cout << "*********" << endl;
    return 0;
} /* end of main */
