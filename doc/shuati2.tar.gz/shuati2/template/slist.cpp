#include "prepare.hpp"
using namespace std;

//=============================================================================
// Cate-list
// question:
//
//=============================================================================
class Solution {
public:
    ListNode* foo()
    {

    }
};

int main(int argc, const char *argv[])
{
    cout << "********* Input" << endl;
    ListNode* input = createList({1,2,3});
    printList(input);

    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    ListNode* result = sol.foo(input);
    printResult(result);

    cout << "*********" << endl;
    return 0;
} /* end of main */
