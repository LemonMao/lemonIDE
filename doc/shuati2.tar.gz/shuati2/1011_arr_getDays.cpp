#include "prepare.hpp"
#include <algorithm>
#include <cstdint>
#include <vector>
using namespace std;

//=============================================================================
// Question: 在 D 天内送达包裹的能力
// 传送带上的包裹必须在 days 天内从一个港口运送到另一个港口。
//
// 传送带上的第 i 个包裹的重量为 weights[i]。每一天，我们都会按给出重量（weights）的顺序往传送带上装载包裹。我们装载的重量不会超过船的最大运载重量。
//
// 返回能在 days 天内将传送带上的所有包裹送达的船的最低运载能力。
//
//
//
// 示例 1：
//
// 输入：weights = [1,2,3,4,5,6,7,8,9,10], days = 5
// 输出：15
// 船舶最低载重 15 就能够在 5 天内送达所有包裹，如下所示：
// 第 1 天：1, 2, 3, 4, 5
// 第 2 天：6, 7
// 第 3 天：8
// 第 4 天：9
// 第 5 天：10
//
// 请注意，货物必须按照给定的顺序装运，因此使用载重能力为 14 的船舶并将包装分成 (2, 3, 4, 5), (1, 6, 7), (8), (9), (10) 是不允许的。
//=============================================================================
class Solution {
public:
    int getDays(int x, vector<int>& weights)
    {
        int days = 0, t = x;

        for (auto w : weights) {
            t = t - w;
            if (t <= 0) {
                days++;
                t = t == 0 ? x : x - w;
            }
        }

        if (t < x) {
            days++;
        }
        return days;
    }

    int shipWithinDays(vector<int>& weights, int days)
    {
        int l=0, r=0;
        for (int w : weights) {
            l = std::max(l, w);
            r += w;
        }

        while (l < r)
        {
            int mid = l + (r-l)/2;
            if (getDays(mid, weights) > days)
            {
                l = mid + 1;
            }
            else if (getDays(mid, weights) < days)
            {
                r = mid;
            }
            else
            {
                r = mid;
            }
        }
        return l;
    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********" << endl;
    std::vector<int> input{1,2,3,4,5,6,7,8,9,10};
    printArray(input);

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.shipWithinDays(input, 5);

    // 3. Print the result
    cout << "*********" << endl;
    printResult(result);

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
