#include "prepare.hpp"
#include <unordered_map>
using namespace std;

//=============================================================================
// Question:
//
// 给你两个字符串 s1 和 s2 ，写一个函数来判断 s2 是否包含 s1 的排列。如果是，返回 true ；否则，返回 false 。
//
// 换句话说，s1 的排列之一是 s2 的 子串 。
//
// 示例 1：
//
// 输入：s1 = "ab" s2 = "eidbaooo"
// 输出：true
// 解释：s2 包含 s1 的排列之一 ("ba").
// 示例 2：
//
// 输入：s1= "ab" s2 = "eidboaoo"
// 输出：false
// 提示：
//
// 1 <= s1.length, s2.length <= 104
// s1 和 s2 仅包含小写字母
//=============================================================================
class Solution {
public:
    bool isIncluded(string_view s1, string_view s2)
    {
        unordered_map<char, int> need, window;
        for (auto c : s1) {
            need[c]++;
        }

        int l=0, r=0, valid=0;
        while (r < s2.size())
        {
            char rc = s2[r];
            if (need.count(rc))
            {
                window[rc]++;
                if (window[rc] == need[rc])
                    valid++;
            }
            r++;

            while (r-l >= s1.size())
            {
                if (valid == need.size())
                    return true;
                char lc = s2[l];
                if (need.count(lc))
                {
                    if (window[lc] == need[lc])
                    {
                        valid--;
                    }
                    window[lc]--;
                }
                l++;
            }
        }
        return false;
    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********" << endl;
    string input = "dcda";
    std::cout << "Input: " << input << std::endl;

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.isIncluded("adc", input);

    // 3. Print the result
    cout << "*********" << endl;
    std::cout << "Result: " << result << std::endl;

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
