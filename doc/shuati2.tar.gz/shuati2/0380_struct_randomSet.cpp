#include "prepare.hpp"
#include <cstdlib>
#include <unordered_map>
#include <vector>
using namespace std;

//=============================================================================
// Question:
// 实现RandomizedSet 类：
//
// RandomizedSet() 初始化 RandomizedSet 对象
// bool insert(int val) 当元素 val 不存在时，向集合中插入该项，并返回 true ；否则，返回 false 。
// bool remove(int val) 当元素 val 存在时，从集合中移除该项，并返回 true ；否则，返回 false 。
// int getRandom() 随机返回现有集合中的一项（测试用例保证调用此方法时集合中至少存在一个元素）。每个元素应该有 相同的概率 被返回。
// 你必须实现类的所有函数，并满足每个函数的 平均 时间复杂度为 O(1) 。
// 输入
// ["RandomizedSet", "insert", "remove", "insert", "getRandom", "remove", "insert", "getRandom"]
// [[], [1], [2], [2], [], [1], [2], []]
// 输出
// [null, true, false, true, 2, true, false, 2]
//=============================================================================
class RandomizedSet {
private:
    vector<int> list_;
    unordered_map<int, int> maps_;
public:
    RandomizedSet() {
        srand(time(0));
    }

    bool insert(int val) {
        if (maps_.count(val)) {
            return false;
        }
        maps_[val] = list_.size();
        list_.push_back(val);
        return true;
    }

    bool remove(int val) {
        if (maps_.count(val)) {
            int idx = maps_[val];
            list_[idx] = list_.back();
            list_.pop_back();
            maps_.erase(val);
            maps_[list_[idx]] = idx;
            return true;
        }
        return false;
    }

    int getRandom() {
        int randidx = rand() % maps_.size();
        std::cout << "Size: " << maps_.size() << ", ridx: " << randidx << ", rand: " <<  rand() << std::endl;
        return list_[randidx];
    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********" << endl;

    RandomizedSet set;
    set.insert(3);
    set.insert(4);
    set.insert(5);
    std::cout
        << "Insert 1: " << set.insert(1) << std::endl
        << "Insert 2: " << set.insert(2) << std::endl
        << "Insert 1: " << set.insert(1) << std::endl
        << "Remove 1: " << set.remove(1) << std::endl
        << "Remove 1: " << set.remove(1) << std::endl
        << "Random : " << set.getRandom() << std::endl;


    cout << "*********" << endl;
    return 0;
} /* end of main */
