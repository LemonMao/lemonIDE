#include "prepare.hpp"
using namespace std;

//=============================================================================
// question:
// 给你一个链表，删除链表的倒数第 n 个结点，并且返回链表的头结点。
// 示例 1：
// 输入：head = [1,2,3,4,5], n = 2
// 输出：[1,2,3,5]
// 示例 2：
//
// 输入：head = [1], n = 1
// 输出：[]
// 示例 3：
//
// 输入：head = [1,2], n = 1
// 输出：[1]
// 提示：
//
// 链表中结点的数目为 sz
// 1 <= sz <= 30
// 0 <= Node.val <= 100
// 1 <= n <= sz
// 进阶：你能尝试使用一趟扫描实现吗？
//=============================================================================
class Solution {
public:
    ListNode* removeFromEnd(ListNode* head, int k)
    {
        ListNode* tp = head, *thead = head;
        ListNode *pretp=nullptr;
        int idx = 1;
        while (head->next != nullptr)
        {
            if (idx++ >= k)
            {
                pretp = tp;
                tp = tp->next;
            }
            head = head->next;
        }

        // if idx < k { error ;}
        if (idx == k)
        {
            return thead->next;
        }

        pretp->next = tp->next;
        // free tp
        return thead;
    }

    ListNode* removeFromEnd2(ListNode* head, int k)
    {
        if (k == 0) {
            return head;
        }
        ListNode* l = nullptr;
        ListNode* r = head;

        int idx = 0;
        while (r->next != nullptr)
        {
            r = r->next;
            idx++;
            if (idx == k) {
                l = head;
            }
            if (idx > k) {
                l = l->next;
            }
        }

        int delptr = nullptr;
        if (l) {
            delptr = l->next;
            l->next = l->next->next;
        }

        if (delptr) {
            delete delptr;
        }

        return head;
    }

};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********" << endl;
    ListNode* input = createList({1,2,3,4,5});
    printList(input);

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    ListNode* result = sol.removeFromEnd(input, 1);

    // 3. Print the result
    cout << "*********" << endl;
    printList(result);

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
