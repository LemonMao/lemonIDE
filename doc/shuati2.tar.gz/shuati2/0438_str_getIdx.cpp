#include "prepare.hpp"
#include <unordered_map>
#include <vector>
using namespace std;

//=============================================================================
// Question:
//
// 给定两个字符串 s 和 p，找到 s 中所有 p 的 异位词 的子串，返回这些子串的起始索引。不考虑答案输出的顺序。
//
// 异位词 指由相同字母重排列形成的字符串（包括相同的字符串）。
//
// 输入: s = "abab", p = "ab"
// 输出: [0,1,2]
// 解释:
// 起始索引等于 0 的子串是 "ab", 它是 "ab" 的异位词。
// 起始索引等于 1 的子串是 "ba", 它是 "ab" 的异位词。
// 起始索引等于 2 的子串是 "ab", 它是 "ab" 的异位词。
// 提示:
//=============================================================================
class Solution {
public:
    vector<int> getIdx(string_view s, string_view p)
    {
        vector<int> res;
        unordered_map<char, int> need, window;
        for (auto c : p) {
            need[c]++;
        }

        int l=0, r=0, valid=0;
        while (r < s.size())
        {
            char rc = s[r];
            r++;
            if (need.count(rc)) {
                window[rc]++;
                if (window[rc] == need[rc])
                    valid++;
            }

            if (r - l == p.size()) {
                if (valid == need.size()) {
                    res.push_back(l);
                }
                char lc = s[l];
                if (need.count(lc)) {
                    if (window[lc] == need[lc])
                        valid--;
                    window[lc]--;
                }
                l++;
            }
        }
        return res;
    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********" << endl;
    string input = "cbaebabacd";
    std::cout << "Input: " << input << std::endl;

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.getIdx(input, "abc");

    // 3. Print the result
    cout << "*********" << endl;
    std::cout << "[";
    for (auto idx : result) {
        std::cout << idx << ", ";
    }
    std::cout << "]" << std::endl;

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
