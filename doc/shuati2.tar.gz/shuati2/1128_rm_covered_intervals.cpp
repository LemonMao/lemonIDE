#include "prepare.hpp"
#include <vector>
using namespace std;

//=============================================================================
// Cate-array
// Question:
// 给你一个区间列表，请你删除列表中被其他区间所覆盖的区间。
// 只有当 c <= a 且 b <= d 时，我们才认为区间 [a,b) 被区间 [c,d) 覆盖。
// 在完成所有删除操作后，请你返回列表中剩余区间的数目。
// 示例：
// 输入：intervals = [[1,4],[3,6],[2,8]]
// 输出：2
// 解释：区间 [3,6] 被区间 [2,8] 覆盖，所以它被删除了。
// =============================================================================
class Solution {
public:
    int removeCoveredIntervals(vector<vector<int>>& intervals) {
        if (intervals.size() <= 1) {
            return intervals.size();
        }
        sort(intervals.begin(), intervals.end(), [](auto& a, auto& b){
            if (a[0] < b[0]) {
                return true;
            }
            else if (a[0] == b[0]) {
                return a[1] > b[1];
            }
            return false;
        });

        int cnt = 0;
        for (int i=0, j=1; i < intervals.size() && j < intervals.size();) {
            if (intervals[i][1] >= intervals[j][1]) {
                cnt++;
                j++;
            }
            else {
                i = j;
                j++;
            }
        }
        return intervals.size()-cnt;
    };

    vector<vector<int>> merge(vector<vector<int>>& intervals) {
        vector<vector<int>> res;
        sort(intervals.begin(), intervals.end(), [](auto& a, auto& b){
            if (a[0] < b[0]) {
                return true;
            }
            else if (a[0] == b[0]) {
                return a[1] > b[1];
            }
            return false;
        });

        int start = intervals[0][0];
        int end = intervals[0][1];

        for (int i = 1; i < intervals.size(); i++) {
            if (end >= intervals[i][1]) {
                continue;
            }
            else if (end < intervals[i][1]) {
                if (end >= intervals[i][0]) {
                    end = intervals[i][1];
                }
                else {
                    res.push_back({start, end});
                    start = intervals[i][0];
                    end = intervals[i][1];
                }
            }
        }
        res.push_back({start, end});
        return res;
    }
};

int main(int argc, const char *argv[])
{
    cout << "********* Input" << endl;
    std::vector<vector<int>> input{{1,4},{3,6},{2,8}};
    printResult(input);

    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.removeCoveredIntervals(input);
    printResult(result);

    cout << "*********" << endl;
    return 0;
} /* end of main */
