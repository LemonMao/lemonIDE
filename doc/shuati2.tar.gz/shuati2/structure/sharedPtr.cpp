#include <atomic>

template <typename T>
class shared_ptr {
private:
    T* ptr;
    std::atomic<long>* count;   // Reference counter

    // Helper function to clean up resources
    void cleanup() {
        if (count) {
            (*count)--; // Decrement atomic counter
            if (count->load() == 0) { // Check if count is zero
                delete ptr;
                delete count;
                ptr = nullptr; // Reset pointers after deletion
                count = nullptr;
            }
        }
    }

public:
    // Constructor
    explicit shared_ptr(T* p = nullptr) : ptr(p), count(new std::atomic<long>(1)) {
        if (p == nullptr) {
            count->store(0);
        }
    }

    // Copy constructor
    shared_ptr(const shared_ptr& other) : ptr(other.ptr), count(other.count) {
        if (count) (*count)++;
    }

    // Assignment operator
    shared_ptr& operator=(const shared_ptr& other) {
        if (this != &other) {
            cleanup();
            ptr = other.ptr;
            count = other.count;
            if (count) (*count)++;
        }
        return *this;
    }

    // Destructor
    ~shared_ptr() {
        cleanup();
    }

    // Get the raw pointer
    T* get() const {
        return ptr;
    }

    // Get reference count
    long use_count() const {
        // Safely load the atomic value
        return count ? count->load() : 0;
    }

    // Reset the pointer
    void reset(T* p = nullptr) {
        cleanup();
        ptr = p;
        // Correctly initialize the atomic counter
        count = new std::atomic<long>(1);
        if (p == nullptr) count->store(0);
    }

    // Pointer operators
    T& operator*() const { return *ptr; }
    T* operator->() const { return ptr; }
};
