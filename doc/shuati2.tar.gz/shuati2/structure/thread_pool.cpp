#include <iostream>
#include <utility>
#include <vector>
#include <queue>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <functional>
#include <future>
#include <stdexcept>

// C++11/14/17 风格的线程池
class ThreadPool {
public:
    // 构造函数：创建指定数量的线程
    ThreadPool(size_t threads);
    // 析构函数：停止并销毁所有线程
    ~ThreadPool();

    // 任务入队函数
    // 使用可变参数模板和完美转发，接受任意函数和参数
    // 返回一个 std::future，以便调用者可以等待任务完成并获取返回值
    template<class F, class... Args>
    auto enqueue(F&& f, Args&&... args)
        -> std::future<typename std::result_of<F(Args...)>::type>;

    template<class F>
    void enqueue(F&& f);

private:
    // 工作线程的集合
    std::vector<std::thread> workers;
    // 任务队列
    std::queue<std::function<void()>> tasks;

    // 同步机制
    std::mutex queue_mutex; // 互斥锁，用于保护任务队列
    std::condition_variable condition; // 条件变量，用于线程间的等待和唤醒
    bool stop; // 停止标志

    // 工作线程执行的循环函数
    void worker_loop();
};

// 构造函数实现
inline ThreadPool::ThreadPool(size_t threads) : stop(false) {
    // 创建并启动指定数量的工作线程
    for(size_t i = 0; i < threads; ++i) {
        // emplace_back 直接在 vector 的末尾构造对象，比 push_back 更高效
        // 每个线程都运行 worker_loop 成员函数
        workers.emplace_back([this] { this->worker_loop(); });
    }
}

// 工作线程的主循环
inline void ThreadPool::worker_loop() {
    // 无限循环，直到线程池被销毁
    for(;;) {
        std::function<void()> task;

        { // 这个大括号是 RAII 锁的作用域
            // 使用 unique_lock，因为它能与 condition_variable 配合使用
            std::unique_lock<std::mutex> lock(this->queue_mutex);

            // 等待条件：当任务队列不为空或线程池停止时，线程才会被唤醒
            // 这个 lambda 表达式是防止“伪唤醒”的关键
            this->condition.wait(lock, [this] { return this->stop || !this->tasks.empty(); });

            // 如果线程池已停止且任务队列为空，则工作线程可以安全退出
            if(this->stop && this->tasks.empty()) {
                return;
            }

            // 从队列中取出一个任务
            task = std::move(this->tasks.front());
            this->tasks.pop();
        } // 锁在这里被释放，允许其他线程访问队列

        // 执行任务。注意：任务执行时锁已经被释放，这是为了提高并发性。
        task();
    }
}

template<class F>
void ThreadPool::enqueue(F&& f) {
    std::unique_lock<std::mutex> lock(queue_mutex);
    tasks.emplace([task = std::forward<F>(f)](){ task();});
    condition.notify_one();
}

// 任务入队函数的实现 (模板函数必须在头文件或使用它的地方可见)
template<class F, class... Args>
auto ThreadPool::enqueue(F&& f, Args&&... args)
    -> std::future<typename std::result_of<F(Args...)>::type> {

    // 获取函数 F 在给定参数 Args... 下的返回类型
    using return_type = typename std::result_of<F(Args...)>::type;

    // 使用 std::packaged_task 将函数和参数打包，它提供了一个 future
    // std::make_shared 是为了安全地在堆上创建对象
    auto task = std::make_shared<std::packaged_task<return_type()>>(
        std::bind(std::forward<F>(f), std::forward<Args>(args)...)
    );

    // 获取与 packaged_task 关联的 future
    std::future<return_type> res = task->get_future();

    { // RAII 锁作用域
        std::unique_lock<std::mutex> lock(queue_mutex);

        // 不允许在线程池停止后继续添加任务
        if(stop) {
            throw std::runtime_error("enqueue on stopped ThreadPool");
        }

        // 将任务（一个 lambda）放入队列
        // 这个 lambda 会在工作线程中被执行，它调用了 packaged_task
        tasks.emplace([task](){ (*task)(); });
    } // 锁在这里释放

    // 唤醒一个等待中的工作线程来处理新任务
    condition.notify_one();
    return res;
}

// 析构函数实现
inline ThreadPool::~ThreadPool() {
    { // RAII 锁作用域
        std::unique_lock<std::mutex> lock(queue_mutex);
        stop = true; // 设置停止标志
    }

    // 唤醒所有等待的线程，以便它们能检查到 stop 标志并退出
    condition.notify_all();

    // 等待所有工作线程执行完毕
    for(std::thread &worker: workers) {
        worker.join();
    }
}

// 一个带多个参数的示例函数，用于演示 std::bind 的工作方式
int multiply(int a, int b) {
    std::cout << "  > Task multiply(" << a << ", " << b << ") started by thread " << std::this_thread::get_id() << std::endl;
    std::this_thread::sleep_for(std::chrono::seconds(1)); // 模拟耗时操作
    std::cout << "  < Task multiply(" << a << ", " << b << ") finished." << std::endl;
    return a * b;
}

// --- 主函数：演示如何使用线程池 ---
int main() {
    // 创建一个拥有 4 个工作线程的线程池
    ThreadPool pool(4);
    std::cout << "ThreadPool with 4 workers created." << std::endl;

    // 用于存储 future 的向量，以便稍后获取结果
    std::vector<std::future<int>> results;

    // 提交 8 个任务到线程池
    for(int i = 0; i < 8; ++i) {
        // 使用 enqueue 方法提交任务
        // 任务是一个 lambda 表达式
        results.emplace_back(
            pool.enqueue([i] {
                std::cout << "  > Task " << i << " started by thread " << std::this_thread::get_id() << std::endl;
                std::this_thread::sleep_for(std::chrono::seconds(1)); // 模拟耗时操作
                std::cout << "  < Task " << i << " finished." << std::endl;
                return i * i; // 返回一个结果
            })
        );
    }

    std::cout << "\nAll tasks enqueued. Waiting for results...\n" << std::endl;

    // 获取每个任务的结果
    // future.get() 会阻塞，直到任务完成并返回结果
    for(size_t i = 0; i < results.size(); ++i) {
        int res = results[i].get();
        std::cout << "Result of task " << i << " is " << res << std::endl;
    }

    // --- 新增示例：演示如何提交一个带多个参数的普通函数 ---
    // 这个例子展示了 enqueue 如何通过 std::bind 和完美转发来接受任意函数和参数
    std::cout << "\n--- 演示任务入队：一个带多参数的函数 ---\n" << std::endl;
    auto multiply_future = pool.enqueue(multiply, 5, 6);
    std::cout << "任务 multiply(5, 6) 已入队." << std::endl;
    std::cout << "multiply(5, 6) 的结果是 " << multiply_future.get() << std::endl;

    std::cout << "\nAll tasks finished. ThreadPool will be destroyed." << std::endl;
    // 当 main 函数结束时，pool 对象会被销毁，其析构函数会自动被调用
    // 析构函数会确保所有线程都已安全退出
    return 0;
}
