/* 请你为 最不经常使用（LFU）缓存算法设计并实现数据结构。
 *
 * 实现 LFUCache 类：
 *
 * LFUCache(int capacity) - 用数据结构的容量 capacity 初始化对象
 * int get(int key) - 如果键 key 存在于缓存中，则获取键的值，否则返回 -1 。
 * void put(int key, int value) - 如果键 key 已存在，则变更其值；如果键不存在，请插入键值对。
 * 当缓存达到其容量 capacity 时，则应该在插入新项之前，移除最不经常使用的项。
 * 在此问题中，当存在平局（即两个或更多个键具有相同使用频率）时，应该去除 最久未使用 的键。
 * 为了确定最不常使用的键，可以为缓存中的每个键维护一个 使用计数器 。使用计数最小的键是最久未使用的键。
 *
 * 当一个键首次插入到缓存中时，它的使用计数器被设置为 1 (由于 put 操作)。对缓存中的键执行 get 或 put 操作，使用计数器的值将会递增。
 *
 * 函数 get 和 put 必须以 O(1) 的平均时间复杂度运行。
 *
 *
 *
 * 示例：
 *
 * 输入：
 * ["LFUCache", "put", "put", "get", "put", "get", "get", "put", "get", "get", "get"]
 * [[2], [1, 1], [2, 2], [1], [3, 3], [2], [3], [4, 4], [1], [3], [4]]
 * 输出：
 * [null, null, null, 1, null, -1, 3, null, -1, 3, 4]
 *
 * 解释：
 * // cnt(x) = 键 x 的使用计数
 * // cache=[] 将显示最后一次使用的顺序（最左边的元素是最近的）
 * LFUCache lfu = new LFUCache(2);
 * lfu.put(1, 1);   // cache=[1,_], cnt(1)=1
 * lfu.put(2, 2);   // cache=[2,1], cnt(2)=1, cnt(1)=1
 * lfu.get(1);      // 返回 1
 *                  // cache=[1,2], cnt(2)=1, cnt(1)=2
 * lfu.put(3, 3);   // 去除键 2 ，因为 cnt(2)=1 ，使用计数最小
 *                  // cache=[3,1], cnt(3)=1, cnt(1)=2
 * lfu.get(2);      // 返回 -1（未找到）
 * lfu.get(3);      // 返回 3
 *                  // cache=[3,1], cnt(3)=2, cnt(1)=2
 * lfu.put(4, 4);   // 去除键 1 ，1 和 3 的 cnt 相同，但 1 最久未使用
 *                  // cache=[4,3], cnt(4)=1, cnt(3)=2
 * lfu.get(1);      // 返回 -1（未找到）
 * lfu.get(3);      // 返回 3
 *                  // cache=[3,4], cnt(4)=1, cnt(3)=3
 * lfu.get(4);      // 返回 4
 *                  // cache=[3,4], cnt(4)=2, cnt(3)=3 */

#include <iostream>
#include <iterator>
#include <unordered_map>
#include <list>
#include <vector>
#include <algorithm> // for sort in show()

using namespace std;

// 定义节点结构
struct Node {
    int key, value, freq;
};

class LFUCache {
private:
    int capacity_; // 缓存容量
    int min_freq_; // 当前缓存中存在的最小频率
    unordered_map<int, list<Node>::iterator> key_to_node_; // key 到 节点迭代器 的映射
    unordered_map<int, list<Node>> freq_to_list_; // 频率 到 节点列表 的映射

    // 辅助函数：增加节点的频率，并将其移动到新频率列表的末尾
    void increase_frequency2(list<Node>::iterator& it) {
        int old_freq = it->freq++;
        auto& old_list = freq_to_list_[old_freq];
        auto& new_list = freq_to_list_[it->freq];

        new_list.splice(new_list.end(), old_list, it);

        if (old_list.empty() && old_freq == min_freq_) {
            min_freq_ = it->freq;
        }
    }

    void increase_frequency(list<Node>::iterator& it) {
        Node node = *it; // 复制一份节点信息
        int old_freq = node.freq;


        // 从旧频率列表中删除节点
        freq_to_list_[old_freq].erase(it);

        // 如果旧频率列表变空，并且该频率是最小频率，则更新最小频率
        // 因为这个节点是旧频率列表的最后一个节点，它被移走后，
        // 如果 old_freq == min_freq_，那么新的最小频率必然是 old_freq + 1
        if (freq_to_list_[old_freq].empty() && old_freq == min_freq_) {
            min_freq_++;
        }

        // 更新节点频率
        node.freq++;
        int new_freq = node.freq;

        // 将节点添加到新频率列表的末尾
        freq_to_list_[new_freq].push_back(node);
        // 获取节点在新列表中的迭代器 (指向最后一个元素)
        auto new_it = std::prev(freq_to_list_[new_freq].end());
        // 更新 key_to_node_ 中的迭代器，指向新位置
        key_to_node_[node.key] = new_it;
    }


public:
    LFUCache(int capacity) : capacity_(capacity), min_freq_(0) {}

    int get(int key) {
        // 如果容量为 0，直接返回 -1
        if (capacity_ == 0) return -1;

        auto it_map = key_to_node_.find(key);
        if (it_map == key_to_node_.end()) {
            return -1;
        }

        // key 存在
        auto& node_it = it_map->second; // 获取节点在 list 中的迭代器

        increase_frequency2(node_it);

        return node_it->value;
    }

    void put(int key, int value) {
        // 如果容量为 0，直接返回
        if (capacity_ == 0) return;

        auto it_map = key_to_node_.find(key);

        // key 已存在
        if (it_map != key_to_node_.end()) {
            auto& node_it = it_map->second; // 获取节点迭代器
            node_it->value = value;
            increase_frequency2(node_it);
        } else { // key 不存在
            // 缓存已满，需要淘汰最不经常使用且最久未使用的节点
            if (key_to_node_.size() >= capacity_) {
                // 找到最小频率对应的列表, 从频率列表中移除该节点 (移除第一个元素)
                auto& min_freq_list = freq_to_list_[min_freq_];
                key_to_node_.erase(min_freq_list.front().key);
                min_freq_list.pop_front();
            }

            // 插入新节点
            Node new_node = {key, value, 1}; // 新节点的频率初始为 1
            freq_to_list_[1].push_back(new_node); // [1] 如果没有会返回新构建的list对象，可以直接 push_back
            key_to_node_[key] = std::prev(freq_to_list_[1].end());
            min_freq_ = 1;
        }
    }

    // (可选) 增加一个用于调试的 show 方法
    void show() {
        cout << "--- Cache Status ---" << endl;
        cout << "Capacity: " << capacity_ << endl;
        cout << "Size: " << key_to_node_.size() << endl;
        cout << "Min Freq: " << min_freq_ << endl;
        cout << "Key to Node Map:" << endl;
         for(const auto& pair : key_to_node_) {
             // 打印 key 指向的节点信息 (值和频率)
             cout << "  Key: " << pair.first << " -> [val:" << pair.second->value << ", freq:" << pair.second->freq << "]" << endl;
         }

        cout << "Freq to List Map:" << endl;
        // 为了更清晰地展示，按频率排序后输出
        vector<int> freqs;
        for(const auto& pair : freq_to_list_) {
            if (!pair.second.empty()) { // 只显示包含节点的频率列表
                 freqs.push_back(pair.first);
            }
        }
        sort(freqs.begin(), freqs.end()); // 对频率进行排序

        for(int freq : freqs) {
            cout << "  Freq " << freq << ": ";
            // 遍历该频率对应的 list，打印每个节点的 key 和 value
            for (const auto& node : freq_to_list_[freq]) {
                cout << "[" << node.key << ":" << node.value << "] ";
            }
            cout << endl;
        }
         cout << "--------------------" << endl;
    }
};

int main(int argc, const char *argv[])
{
    // 使用示例中的测试用例
    cout << "Initializing LFUCache with capacity 2" << endl;
    LFUCache lfu(2);
    cout << "put(1, 1)" << endl; lfu.put(1, 1);   lfu.show();
    cout << "put(2, 2)" << endl; lfu.put(2, 2);   lfu.show();
    cout << "get(1): " << lfu.get(1) << endl; lfu.show(); // 返回 1, 节点1频率增加
    cout << "put(3, 3)" << endl; lfu.put(3, 3);   lfu.show(); // 缓存满，淘汰频率最低(1)且最久未使用(节点2)
    cout << "get(2): " << lfu.get(2) << endl; lfu.show(); // 返回 -1 (已被淘汰)
    cout << "get(3): " << lfu.get(3) << endl; lfu.show(); // 返回 3, 节点3频率增加
    cout << "put(4, 4)" << endl; lfu.put(4, 4);   lfu.show(); // 缓存满，淘汰频率最低(1)且最久未使用(节点1，因为节点3刚被访问频率为2)
    cout << "get(1): " << lfu.get(1) << endl; lfu.show(); // 返回 -1 (已被淘汰)
    cout << "get(3): " << lfu.get(3) << endl; lfu.show(); // 返回 3, 节点3频率增加
    cout << "get(4): " << lfu.get(4) << endl; lfu.show(); // 返回 4, 节点4频率增加

    cout << "\nTesting capacity 0:" << endl;
    LFUCache lfu0(0);
    cout << "put(1, 1)" << endl; lfu0.put(1, 1); lfu0.show(); // 容量为0，无操作
    cout << "get(1): " << lfu0.get(1) << endl; lfu0.show(); // 容量为0，返回-1


    cout << "\nTesting capacity 1:" << endl;
    LFUCache lfu1(1);
    cout << "put(2, 1)" << endl; lfu1.put(2, 1); lfu1.show();
    cout << "get(2): " << lfu1.get(2) << endl; lfu1.show(); // 访问节点2，频率增加
    cout << "put(3, 2)" << endl; lfu1.put(3, 2); lfu1.show(); // 缓存满，淘汰节点2 (因为它是唯一的元素)
    cout << "get(2): " << lfu1.get(2) << endl; lfu1.show(); // 返回 -1
    cout << "get(3): " << lfu1.get(3) << endl; lfu1.show(); // 访问节点3，频率增加


    return 0;
}
