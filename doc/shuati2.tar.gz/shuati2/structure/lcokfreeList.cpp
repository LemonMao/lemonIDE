#include <atomic>
#include <iostream>
#include <thread>
#include <vector>

template <typename T>
class LockFreeQueue {
private:
    // 节点结构
    struct Node {
        T value;
        std::atomic<Node*> next;

        Node(T val) : value(val), next(nullptr) {}
    };

    // 头指针：指向哨兵节点，消费者从 head->next 获取元素
    std::atomic<Node*> head;
    // 尾指针：指向最后一个真实节点，生产者将新元素链接到 tail->next
    std::atomic<Node*> tail;

public:
    LockFreeQueue() {
        // 1. 初始化时，创建一个哨兵节点（dummy node）
        // 2. head 和 tail 都指向这个哨兵节点
        // 3. 队列为空的条件是 head == tail
        Node* dummyNode = new Node(T{});
        head.store(dummyNode);
        tail.store(dummyNode);
    }

    ~LockFreeQueue() {
        // 简单的析构，非线程安全
        // 在实际应用中，需要确保没有其他线程在操作队列
        T value;
        while (dequeue(value)) {
            // 循环出队以释放所有节点
        }
        delete head.load(); // 删除最后的哨兵节点
    }

    // 禁止拷贝和赋值
    LockFreeQueue(const LockFreeQueue&) = delete;
    LockFreeQueue& operator=(const LockFreeQueue&) = delete;

    /**
     * @brief 入队操作（生产者）
     */
    void enqueue(T value) {
        // 1. 创建一个包含值的新节点
        Node* newNode = new Node(std::move(value));

        // 2. 循环尝试，直到成功将新节点添加到链表尾部
        while (true) {
            // 读取当前的尾指针
            Node* last = tail.load();

            // 尝试将新节点链接到尾节点的 next 指针上
            // 如果 last->next 是 nullptr，则用 newNode 替换它
            // 这是一个 CAS 操作，确保只有一个线程可以成功链接节点
            Node* expected = nullptr;
            if (last->next.compare_exchange_weak(expected, newNode)) {
                // 3. 链接成功后，尝试更新 tail 指针指向新的尾节点
                // 如果 tail 仍然是 last，就把它更新为 newNode
                tail.store(newNode);
                return;
            }
        }
    }

    /**
     * @brief 出队操作（消费者）
     * @param value 用于接收出队元素的引用
     * @return 如果成功出队则返回 true，队列为空则返回 false
     */
    bool dequeue(T& value) {
        // 1. 循环尝试，直到成功取出一个节点或确认队列为空
        while (true) {
            // 读取当前的头、尾指针
            Node* first = head.load();
            Node* last = tail.load();
            Node* next = first->next.load();

            if (first == last) { // head 和 tail 指向同一个节点，说明队列确定为空
                return false;
            } else { // head 和 tail 指向不同节点，队列中有数据
                // 3. 尝试移动 head 指针，将其指向下一个节点 (first->next)
                // 这是一个 CAS 操作，确保只有一个消费者能成功
                if (head.compare_exchange_weak(first, next)) {
                    // 4. 成功！我们已经“声明”了对 `next` 节点的所有权
                    value = std::move(next->value); // 获取数据
                    delete first; // 释放旧的哨兵节点
                    return true;
                }
            }
        }
    }
};

// --- 测试代码 ---
void producer(LockFreeQueue<int>& q, int id) {
    for (int i = 0; i < 100; ++i) {
        q.enqueue(id * 1000 + i);
    }
}

void consumer(LockFreeQueue<int>& q, std::atomic<int>& count) {
    int value;
    while (count.load() > 0) {
        if (q.dequeue(value)) {
            // std::cout << "Dequeued: " << value << std::endl;
            count--;
        } else {
            std::this_thread::yield(); // 队列为空时，让出CPU
        }
    }
}

int main() {
    LockFreeQueue<int> q;
    int num_producers = 4;
    int num_consumers = 4;
    int items_to_process = num_producers * 100;

    std::vector<std::thread> producers;
    for (int i = 0; i < num_producers; ++i) {
        producers.emplace_back(producer, std::ref(q), i);
    }

    std::atomic<int> counter(items_to_process);
    std::vector<std::thread> consumers;
    for (int i = 0; i < num_consumers; ++i) {
        consumers.emplace_back(consumer, std::ref(q), std::ref(counter));
    }

    for (auto& t : producers) {
        t.join();
    }

    for (auto& t : consumers) {
        t.join();
    }

    std::cout << "Test finished. All items processed." << std::endl;

    // 验证队列是否为空
    int val;
    if (!q.dequeue(val)) {
        std::cout << "Queue is correctly empty." << std::endl;
    } else {
        std::cout << "Error: Queue is not empty." << std::endl;
    }

    return 0;
}
