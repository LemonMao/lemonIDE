//////////////////////////////////////////////////////////////////////////
// BlockQueue.h
//
//////////////////////////////////////////////////////////////////////////

#ifndef _BLOCKQUEUE_H_
#define _BLOCKQUEUE_H_


#include <mutex>
#include <list>
#include <condition_variable>

template<typename T>
class BlockQueue {
public:
    BlockQueue()
        : mMutex(),
          mNotEmpty(),
          mList(),
          mIsTimeOut(false)
    {
    }

    // left-value push
    void push(const T& x)
    {
        std::unique_lock<std::mutex> lock(mMutex);
        mList.push_back(x);
        mNotEmpty.notify_one();
    }

    // block wait
    T pop()
    {
        std::unique_lock<std::mutex> lock(mMutex);
        // block if queue is empty
        mNotEmpty.wait(lock, [&](){!mList.empty();});
        T front(std::move(mList.front()));
        mList.pop_front();
        return front;
    }

    size_t size() const
    {
        std::unique_lock<std::mutex> lock(mMutex);
        return mList.size();
    }

    bool IsTimeout() const
    {
        return mIsTimeOut;
    }

private:
    std::mutex mMutex;
    std::condition_variable mNotEmpty;
    std::list<T> mList;
    bool mIsTimeOut;
};


#endif /* end of include guard: _BLOCKQUEUE_H_ */
