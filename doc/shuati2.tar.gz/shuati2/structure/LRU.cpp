#include <iostream>
#include <unordered_map>
#include <list>
#include <utility>
#include <iterator> // For std::prev
using namespace std;

// 请你设计并实现一个满足  LRU (最近最少使用) 缓存 约束的数据结构。
// 实现 LRUCache 类：
// LRUCache(int capacity) 以 正整数 作为容量 capacity 初始化 LRU 缓存
// int get(int key) 如果关键字 key 存在于缓存中，则返回关键字的值，否则返回 -1 。
// void put(int key, int value) 如果关键字 key 已经存在，则变更其数据值 value ；如果不存在，则向缓存中插入该组 key-value 。如果插入操作导致关键字数量超过 capacity ，则应该 逐出 最久未使用的关键字。
// 函数 get 和 put 必须以 O(1) 的平均时间复杂度运行。
//
//
//
// 示例：
//
// 输入
// ["LRUCache", "put", "put", "get", "put", "get", "put", "get", "get", "get"]
// [[2], [1, 1], [2, 2], [1], [3, 3], [2], [4, 4], [1], [3], [4]]
// 输出
// [null, null, null, 1, null, -1, null, -1, 3, 4]

class LRUCache {
private:
    int cap;
    std::list<pair<int, int>> list;
    std::unordered_map<int, std::list<pair<int, int>>::iterator> map;
public:
    LRUCache(int capacity) {
        cap = capacity;
    }

    int get(int key) {
        if (map.count(key)) {
            auto& it = map[key];
            list.splice(list.end(), list, it);
            return it->second;
        }
        return -1;
    }

    void put(int key, int value) {
        if (map.count(key)) {
            auto& it = map[key];
            it->second = value;
            list.splice(list.end(), list, it);
        }
        else {
            if (list.size() >= cap) {
                auto [k, v] = list.front();
                list.pop_front();
                map.erase(k);
            }
            list.push_back(pair(key, value));
            map[key] = std::prev(list.end());
        }
    }

    void show() {
        std::cout << "LRU: " << std::endl;
        for (auto [k, v] : list) {
            std::cout << k << "-" << v << std::endl;
        }
    }
};

int main(int argc, const char *argv[])
{
    LRUCache cache(10);
    cache.put(1, 11);
    cache.put(2, 22);
    cache.put(3, 33);
    cache.show();

    std::cout << "Get 2:" << cache.get(2) << std::endl;

    cache.show();
    return 0;
} /* end of main */
