#include <vector>
#include <stdexcept> // For std::runtime_error
#include <cstddef>   // For size_t
#include <utility>   // For std::move
#include <iostream>
#include <string>
#include <mutex>     // For std::mutex and std::lock_guard
#include <thread>    // For std::thread (in main example)
#include <vector>    // For std::vector (in main example)
#include <chrono>    // For std::chrono::milliseconds (in main example)

/**
 * @brief A generic Ring Buffer (Circular Buffer) data structure.
 *
 * This buffer has a fixed capacity. When full, pushing a new element
 * overwrites the oldest element.
 *
 * @tparam T The type of elements stored in the buffer.
 */
template <typename T>
class RingBuffer {
public:
    /**
     * @brief Constructs a RingBuffer with the specified capacity.
     * @param capacity The maximum number of elements the buffer can hold.
     * @throws std::invalid_argument if capacity is 0.
     */
    explicit RingBuffer(size_t capacity) : capacity_(capacity), buffer_(capacity) {
        if (capacity == 0) {
            throw std::invalid_argument("RingBuffer capacity cannot be zero.");
        }
    }

    // Default destructor is sufficient as std::vector manages its memory.
    ~RingBuffer() = default;

    // Disable copy constructor and assignment operator
    RingBuffer(const RingBuffer&) = delete;
    RingBuffer& operator=(const RingBuffer&) = delete;

    // Enable move constructor and assignment operator (optional but good practice)
    RingBuffer(RingBuffer&&) = default;
    RingBuffer& operator=(RingBuffer&&) = default;

    /**
     * @brief Pushes an element into the buffer by copying.
     * If the buffer is full, the oldest element is overwritten.
     * @param value The value to push.
     */
    void push(const T& value) {
        std::lock_guard<std::mutex> lock(mutex_); // Lock the mutex
        if (capacity_ == 0) return; // Should not happen due to constructor check, but defensive

        buffer_[head_] = value;

        if (size == capacity_) {
            tail_ = (tail_ + 1) % capacity_;
        }
        else {
            size_++;
            head_ = (head_ + 1) % capacity_;
        }
    }

    /**
     * @brief Removes and returns the oldest element from the buffer.
     * @return The oldest element.
     * @throws std::runtime_error if the buffer is empty.
     */
    T pop() {
        std::lock_guard<std::mutex> lock(mutex_); // Lock the mutex
        if (empty_unsafe()) { // Use helper without lock
            throw std::runtime_error("Cannot pop from an empty RingBuffer.");
        }

        T value = std::move(buffer_[tail_]); // Move out the value
        tail_ = (tail_ + 1) % capacity_;
        size_--;

        return value;
    }

    /**
     * @brief Returns a const reference to the oldest element without removing it.
     * @return Const reference to the oldest element.
     * @throws std::runtime_error if the buffer is empty.
     */
    const T& front() const {
        std::lock_guard<std::mutex> lock(mutex_); // Lock the mutex
        if (empty_unsafe()) { // Use helper without lock
            throw std::runtime_error("Cannot access front of an empty RingBuffer.");
        }
        return buffer_[tail_];
    }

    /**
     * @brief Returns a reference to the oldest element without removing it.
     * @return Reference to the oldest element.
     * @throws std::runtime_error if the buffer is empty.
     */
    T& front() {
        std::lock_guard<std::mutex> lock(mutex_); // Lock the mutex
        if (empty_unsafe()) { // Use helper without lock
            throw std::runtime_error("Cannot access front of an empty RingBuffer.");
        }
        return buffer_[tail_];
    }

    /**
     * @brief Checks if the buffer is empty.
     * @return true if the buffer is empty, false otherwise.
     */
    bool empty() const {
        std::lock_guard<std::mutex> lock(mutex_); // Lock the mutex
        return empty_unsafe();
    }

    // Helper function to check emptiness without locking (for internal use)
    bool empty_unsafe() const {
         return size_ == 0;
    }

    /**
     * @brief Returns the current number of elements in the buffer.
     * @return The number of elements.
     */
    size_t size() const {
        std::lock_guard<std::mutex> lock(mutex_); // Lock the mutex
        return size_;
    }

    /**
     * @brief Returns the maximum capacity of the buffer.
     * @return The capacity.
     */
    size_t capacity() const {
        // Capacity is immutable after construction, no lock needed theoretically,
        // but locking for consistency with other methods.
        std::lock_guard<std::mutex> lock(mutex_);
        return capacity_;
    }

    /**
     * @brief Resets the buffer to an empty state.
     */
    void reset() {
        std::lock_guard<std::mutex> lock(mutex_); // Lock the mutex
        head_ = 0;
        tail_ = 0;
        size_ = 0;
        // Optional: Clear the underlying vector elements if T is complex
        // for (size_t i = 0; i < capacity_; ++i) {
        //     buffer_[i] = T{}; // Requires T to be default constructible
        // }
    }


private:
    // Mutex to protect shared data access in a multithreaded environment
    // `mutable` allows locking in const member functions like front(), empty(), etc.
    mutable std::mutex mutex_;

    size_t size_ = 0;      // Current number of elements in the buffer
    size_t capacity_ = 0;
    std::vector<T> buffer_;

    size_t head_ = 0;      // Index of the next slot to write to
    size_t tail_ = 0;      // Index of the oldest element to read from
};



// --- Multi-threaded Example ---

// Global buffer instance (for simplicity in example)
// In a real application, pass by reference or pointer to threads
RingBuffer<int> shared_buffer(10); // Capacity of 10
std::atomic<bool> producers_done(false);
std::atomic<int> items_produced(0);
std::atomic<int> items_consumed(0);
std::mutex cout_mutex; // To prevent garbled output from multiple threads

void producer(int id, int num_items) {
    for (int i = 0; i < num_items; ++i) {
        int value = id * 1000 + i;
        shared_buffer.push(value);
        items_produced++;
        {
            std::lock_guard<std::mutex> lock(cout_mutex);
            std::cout << "Producer " << id << " pushed " << value
                      << " (Buffer size: " << shared_buffer.size() << ")" << std::endl;
        }
        // Simulate some work
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
    {
        std::lock_guard<std::mutex> lock(cout_mutex);
        std::cout << "Producer " << id << " finished." << std::endl;
    }
}

void consumer(int id) {
    while (!producers_done || !shared_buffer.empty()) {
        try {
            // Use a loop with a timeout/check to avoid busy-waiting on pop
            // when buffer might be temporarily empty but producers still running.
            int value = -1;
            bool popped = false;
            { // Scope for lock guard
                std::lock_guard<std::mutex> lock(shared_buffer.mutex_); // Access internal mutex directly or add try_pop
                if (!shared_buffer.empty_unsafe()) {
                    value = shared_buffer.pop(); // pop already locks, but we need atomicity check+pop
                    popped = true;
                }
            } // Release lock before potentially sleeping

            if (popped) {
                items_consumed++;
                 {
                    std::lock_guard<std::mutex> lock(cout_mutex);
                    std::cout << "Consumer " << id << " popped " << value
                              << " (Buffer size: " << shared_buffer.size() << ")" << std::endl;
                 }
                // Simulate processing
                std::this_thread::sleep_for(std::chrono::milliseconds(20));
            } else if (!producers_done) {
                // Buffer is empty, but producers might add more. Wait a bit.
                std::this_thread::sleep_for(std::chrono::milliseconds(5));
            }
            // If producers are done and buffer is empty, the loop condition will terminate.

        } catch (const std::runtime_error& e) {
            // This might happen if multiple consumers race and one finds it empty
            // after another checked but before popping. The loop structure handles this.
             if (!producers_done) { // Only log if producers are still active
                 std::lock_guard<std::mutex> lock(cout_mutex);
                 // std::cerr << "Consumer " << id << " tried to pop from empty buffer." << std::endl;
             }
             std::this_thread::sleep_for(std::chrono::milliseconds(5)); // Wait before retrying
        }
    }
     {
        std::lock_guard<std::mutex> lock(cout_mutex);
        std::cout << "Consumer " << id << " finished." << std::endl;
    }
}


int main() {
    const int num_producers = 2;
    const int num_consumers = 3;
    const int items_per_producer = 15;

    std::vector<std::thread> producers;
    std::vector<std::thread> consumers;

    std::cout << "Starting " << num_producers << " producers and "
              << num_consumers << " consumers..." << std::endl;
    std::cout << "Buffer capacity: " << shared_buffer.capacity() << std::endl;


    // Start producer threads
    for (int i = 0; i < num_producers; ++i) {
        producers.emplace_back(producer, i + 1, items_per_producer);
    }

    // Start consumer threads
    for (int i = 0; i < num_consumers; ++i) {
        consumers.emplace_back(consumer, i + 1);
    }

    // Wait for producers to finish
    for (auto& t : producers) {
        t.join();
    }

    std::cout << "\n--- All producers finished. ---" << std::endl;
    producers_done = true; // Signal consumers that no more items will be produced

    // Wait for consumers to finish processing remaining items
    for (auto& t : consumers) {
        t.join();
    }

    std::cout << "\n--- All consumers finished. ---" << std::endl;
    std::cout << "Total items produced: " << items_produced << std::endl;
    std::cout << "Total items consumed: " << items_consumed << std::endl;
    std::cout << "Final buffer size: " << shared_buffer.size() << std::endl;
    std::cout << "Buffer empty? " << std::boolalpha << shared_buffer.empty() << std::endl;


    // Example of potential error if popping from empty buffer after threads finish
    try {
        if (!shared_buffer.empty()) {
             std::cout << "Remaining item: " << shared_buffer.pop() << std::endl;
        } else {
             std::cout << "Attempting to pop from empty buffer (should throw)..." << std::endl;
             shared_buffer.pop(); // This should throw
        }
    } catch (const std::exception& e) {
        std::cerr << "Caught expected exception: " << e.what() << std::endl;
    }


    return 0;
}

// Note: The consumer logic directly accesses the mutex and uses empty_unsafe
// for a slightly more efficient check-then-pop pattern. A cleaner way would be
// to add a `try_pop(T& value)` method to the RingBuffer class itself, which
// would encapsulate this logic.

```
