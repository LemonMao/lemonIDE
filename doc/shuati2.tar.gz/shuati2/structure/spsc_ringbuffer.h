#ifndef SPSC_RINGBUFFER_H
#define SPSC_RINGBUFFER_H

/* 这个文件 `shuati2/structure/spsc_ringbuffer.h` 包含了 `SPSCRingBuffer` 类的完整实现。
 * 它使用了 `std::atomic` 和适当的内存序来确保在单个生产者和单个消费者场景下的线程安全和无锁操作。
 * 我还添加了 `alignas(64)` 来建议编译器将 `head_` 和 `tail_` 原子变量对齐到缓存行边界，这有助于防止伪共享（false sharing），
 * 从而提高性能，尽管对于“简单”实现这不是必需的，但这是一个好的实践。
 * 好的，我将为您实现一个简单的单生产者单消费者（SPSC）无锁环形缓冲区。
 * 它将使用C++的`std::atomic`和内存序（memory order）来实现内存屏障同步，确保线程安全。这个实现将放在一个新的头文件中。
 *  */

/* 这个SPSC环形缓冲区的设计要点如下：
 * 1.  **固定容量**：创建时指定容量，之后不可更改。
 * 2.  **无锁操作**：生产者和消费者线程通过原子操作更新各自的头部（`head_`）和尾部（`tail_`）索引，无需互斥锁。
 * 3.  **内存序**：使用 `std::memory_order_acquire` 和 `std::memory_order_release` 等内存序来保证数据在线程间的可见性和操作的顺序性。
 * 4.  **一个空槽位**：为了区分缓冲区是满还是空，内部实际分配的存储会比用户请求的容量多一个槽位。当 `(head_ + 1) % internal_capacity == tail_` 时，缓冲区为满。当 `head_ == tail_` 时，缓冲区为空。
 * 5.  **API设计**：
 *     *   `try_push()`: 生产者尝试向缓冲区中放入元素。如果缓冲区已满，则操作失败并返回 `false`。
 *     *   `try_pop()`: 消费者尝试从缓冲区中取出元素。如果缓冲区为空，则操作失败并返回 `false`。
 *     *   `capacity()`: 返回用户指定的缓冲区容量。
 *     *   `size()`: 返回当前缓冲区中元素的近似数量。
 *     *   `empty()` / `full()`: 检查缓冲区是否为空或满。
 *
 *  */


#include <vector>
#include <atomic>
#include <stdexcept> // For std::invalid_argument
#include <cstddef>   // For std::size_t
#include <utility>   // For std::move

/**
 * @brief A simple Single-Producer Single-Consumer (SPSC) lock-free Ring Buffer.
 *
 * This buffer has a fixed capacity. It uses atomic operations and memory ordering
 * to ensure thread safety between one producer thread and one consumer thread.
 * One slot in the buffer is kept empty to distinguish between a full and empty state.
 * Thus, the internal buffer size is capacity + 1.
 *
 * @tparam T The type of elements stored in the buffer.
 */
template <typename T>
class SPSCRingBuffer {
public:
    /**
     * @brief Constructs an SPSCRingBuffer with the specified capacity.
     * @param capacity The maximum number of elements the buffer can hold.
     * @throws std::invalid_argument if capacity is 0.
     */
    explicit SPSCRingBuffer(std::size_t capacity)
        : capacity_(capacity),
          buffer_(capacity + 1) {
        if (capacity == 0) {
            throw std::invalid_argument("SPSCRingBuffer capacity cannot be zero.");
        }
        head_.store(0, std::memory_order_relaxed);
        tail_.store(0, std::memory_order_relaxed);
    }

    // Default destructor is sufficient as std::vector manages its memory,
    // and T's destructor will be called if T is stored by value and has one.
    ~SPSCRingBuffer() = default;

    // Disable copy constructor and assignment operator.
    // SPSC queues are typically not meant to be copied.
    SPSCRingBuffer(const SPSCRingBuffer&) = delete;
    SPSCRingBuffer& operator=(const SPSCRingBuffer&) = delete;

    // Disable move constructor and assignment operator for simplicity.
    // While movable SPSC queues can be implemented, they add complexity.
    SPSCRingBuffer(SPSCRingBuffer&&) = delete;
    SPSCRingBuffer& operator=(SPSCRingBuffer&&) = delete;

    /**
     * @brief Tries to push an element into the buffer by copying.
     * Only callable by the producer thread.
     * @param value The value to push.
     * @return true if the element was successfully pushed, false if the buffer was full.
     */
    bool try_push(const T& value) {
        const std::size_t current_head = head_.load(std::memory_order_relaxed);
        const std::size_t next_head = (current_head + 1) % (capacity_ + 1);

        if (next_head == tail_.load(std::memory_order_acquire)) {
            return false; // Buffer is full
        }

        buffer_[current_head] = value;

        // Store the new head position with release semantics.
        // This ensures that the write to buffer_[current_head] is visible
        // to the consumer before the consumer sees the updated head_.
        head_.store(next_head, std::memory_order_release);
        return true;
    }

    /**
     * @brief Tries to pop an element from the buffer.
     * Only callable by the consumer thread.
     * @param value Output parameter where the popped element will be stored (moved into).
     * @return true if an element was successfully popped, false if the buffer was empty.
     */
    bool try_pop(T& value) {
        const std::size_t current_tail = tail_.load(std::memory_order_relaxed);

        // Check if the buffer is empty.
        // Acquire semantics for reading head_ ensures that we see the latest update
        // from the producer thread, including the written data.
        if (current_tail == head_.load(std::memory_order_acquire)) {
            return false; // Buffer is empty
        }

        value = std::move(buffer_[current_tail]);

        // Store the new tail position with release semantics.
        // This ensures that the read from buffer_[current_tail] (conceptually making the slot free)
        // is visible to the producer before the producer sees the updated tail_.
        tail_.store((current_tail + 1) % (capacity_ + 1), std::memory_order_release);
        return true;
    }

    /**
     * @brief Returns the maximum number of elements the buffer can hold (user-specified capacity).
     * @return The capacity.
     */
    std::size_t capacity() const {
        return capacity_;
    }

    /**
     * @brief Returns the approximate current number of elements in the buffer.
     * This value can be stale immediately after the call in a concurrent environment.
     * @return The approximate number of elements.
     */
    std::size_t size() const {
        // Use acquire semantics to get consistent values of head and tail.
        std::size_t head_val = head_.load(std::memory_order_acquire);
        std::size_t tail_val = tail_.load(std::memory_order_acquire);

        if (head_val >= tail_val) {
            return head_val - tail_val;
        } else {
            return (capacity_ + 1) + head_val - tail_val;
        }
    }

    /**
     * @brief Checks if the buffer is empty.
     * This value can be stale immediately after the call in a concurrent environment.
     * @return true if the buffer is empty, false otherwise.
     */
    bool empty() const {
        // Acquire semantics ensure we get the latest values.
        return head_.load(std::memory_order_acquire) == tail_.load(std::memory_order_acquire);
    }

    /**
     * @brief Checks if the buffer is full (from the producer's perspective).
     * This value can be stale immediately after the call in a concurrent environment.
     * @return true if the buffer is full, false otherwise.
     */
    bool full() const {
        // Acquire semantics ensure we get the latest values.
        const std::size_t current_head = head_.load(std::memory_order_acquire);
        const std::size_t next_head = (current_head + 1) % (capacity_ + 1);
        return next_head == tail_.load(std::memory_order_acquire);
    }

private:
    const std::size_t capacity_;          // User-defined capacity
    std::vector<T> buffer_;

    alignas(64) std::atomic<std::size_t> head_; // Index for the producer to write to
    alignas(64) std::atomic<std::size_t> tail_; // Index for the consumer to read from
};

#endif // SPSC_RINGBUFFER_H

