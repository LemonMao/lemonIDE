/* 主要思路：
 * 1.  **存储**：使用 `std::vector<int>`，索引 0 留空，从索引 1 开始存储堆元素。
 * 2.  **上浮 (swim)**：当插入新元素或某个元素的值增加时，将其与其父节点比较，如果大于父节点则交换，直到满足堆的性质或到达堆顶。
 * 3.  **下沉 (sink)**：当删除最大元素（堆顶）或某个元素的值减小时，将其与其子节点中较大的那个比较，如果小于子节点则交换，直到满足堆的性质或到达堆底。
 * 4.  **插入 (insert)**：将新元素添加到 `vector` 末尾，然后对其执行 `swim` 操作。
 * 5.  **删除最大值 (delMax)**：将堆顶元素（最大值）与 `vector` 末尾元素交换，移除末尾元素，然后对新的堆顶元素执行 `sink` 操作。
 *  */
// 下面是 C++ 实现代码：

#include <iostream>
#include <vector>
#include <stdexcept>
#include <algorithm> // for std::swap

class MaxPriorityQueue {
private:
    // 使用 vector 存储堆元素，索引 0 不使用
    std::vector<int> pq;
    // 当前优先级队列中的元素个数
    int N = 0;

private:
    // 返回父节点的索引
    int parent(int k) {
        return k / 2;
    }

    // 返回左子节点的索引
    int left(int k) {
        return k * 2;
    }

    // 返回右子节点的索引
    int right(int k) {
        return k * 2 + 1;
    }

    // 上浮操作：将索引 k 的元素在堆中上浮以维持最大堆性质
    void swim(int k) {
        // 如果 k 不是根节点，并且 k 的值大于其父节点的值
        while (k > 1 && pq[parent(k)] < pq[k]) {
            // 交换 k 和其父节点
            std::swap(pq[parent(k)], pq[k]);
            // 更新 k 为其父节点的索引，继续上浮
            k = parent(k);
        }
    }

    // 下沉操作：将索引 k 的元素在堆中下沉以维持最大堆性质
    void sink(int k) {
        // 只要 k 存在子节点 (至少有左子节点)
        while (left(k) <= N) {
            // 假设左子节点是较大的那个
            int olderChild = left(k);
            // 如果右子节点存在，并且比左子节点更大
            if (right(k) <= N && pq[left(k)] < pq[right(k)]) {
                olderChild = right(k);
            }
            // 如果 k 节点的值已经大于等于其子节点中的较大者，则满足堆性质，停止下沉
            if (pq[k] >= pq[olderChild]) {
                break;
            }
            // 否则，将 k 与较大的子节点交换
            std::swap(pq[k], pq[olderChild]);
            // 更新 k 为交换后的子节点的索引，继续下沉
            k = olderChild;
        }
    }

public:
    // 构造函数，初始化 pq 大小为 capacity + 1 (因为索引 0 不用)
    MaxPriorityQueue(int capacity = 10) { // 默认容量为 10
        pq.resize(capacity + 1);
    }

    // 返回队列是否为空
    bool isEmpty() const {
        return N == 0;
    }

    // 返回队列中的元素数量
    int size() const {
        return N;
    }

    // 获取但不删除最大元素 (堆顶)
    int getMax() const {
        if (isEmpty()) {
            throw std::out_of_range("Priority queue underflow");
        }
        return pq[1];
    }

    // 插入一个元素
    void insert(int value) {
        // 如果 vector 容量不足，可以进行扩容 (简单实现，每次加倍)
        if (N + 1 >= pq.size()) {
            pq.resize(pq.size() * 2);
        }
        // 元素数量加 1
        N++;
        // 将新元素添加到最后
        pq[N] = value;
        // 对新元素执行上浮操作
        swim(N);
    }

    // 删除并返回最大元素
    int delMax() {
        if (isEmpty()) {
            throw std::out_of_range("Priority queue underflow");
        }
        // 获取最大元素 (堆顶)
        int maxVal = pq[1];
        // 将堆顶元素与最后一个元素交换
        std::swap(pq[1], pq[N]);
        // 元素数量减 1 (逻辑上删除了原来的最大元素)
        N--;
        // 对新的堆顶元素执行下沉操作
        sink(1);
        // 可选：清理交换到末尾的元素 (非必需，因为 N 控制访问范围)
        // pq[N + 1] = 0; // 或者其他默认值

        // 可选：如果元素过少，可以缩小 vector 容量 (简单实现)
        if (N > 0 && N == (pq.size() - 1) / 4) {
             pq.resize(pq.size() / 2);
        }

        return maxVal;
    }

    // (调试用) 打印堆内部数组
    void printHeap() const {
        std::cout << "Heap array (1-based): ";
        for (int i = 1; i <= N; ++i) {
            std::cout << pq[i] << " ";
        }
        std::cout << std::endl;
    }
};

// 主函数：演示优先级队列的使用
int main() {
    MaxPriorityQueue mpq(5); // 初始容量为 5

    mpq.insert(5);
    mpq.insert(3);
    mpq.insert(17);
    mpq.insert(10);
    mpq.insert(84);
    mpq.insert(19);
    mpq.insert(6);
    mpq.insert(22);
    mpq.insert(9);

    std::cout << "Initial heap state:" << std::endl;
    mpq.printHeap(); // 打印内部堆结构
    std::cout << "Size: " << mpq.size() << std::endl;
    std::cout << "Max element: " << mpq.getMax() << std::endl;

    std::cout << "\nDeleting max elements:" << std::endl;
    while (!mpq.isEmpty()) {
        std::cout << "Deleted max: " << mpq.delMax();
        std::cout << " | New size: " << mpq.size();
        if (!mpq.isEmpty()) {
             std::cout << " | New max: " << mpq.getMax();
        }
         std::cout << std::endl;
        // mpq.printHeap(); // 可以取消注释查看每次删除后的堆状态
    }

    try {
        mpq.getMax(); // 尝试在空队列上获取最大值
    } catch (const std::out_of_range& e) {
        std::cerr << "\nError: " << e.what() << std::endl;
    }

    try {
        mpq.delMax(); // 尝试在空队列上删除最大值
    } catch (const std::out_of_range& e) {
        std::cerr << "Error: " << e.what() << std::endl;
    }


    return 0;
}

