#include "prepare.hpp"
#include <algorithm>
#include <unordered_map>
#include <unordered_set>
using namespace std;

//=============================================================================
// Question: 无重复字符的最长子串
// 给定一个字符串 s ，请你找出其中不含有重复字符的 最长 子串 的长度。
//
// 示例 1:
//
// 输入: s = "abcabcbb"
// 输出: 3
// 解释: 因为无重复字符的最长子串是 "abc"，所以其长度为 3。
// 示例 2:
//
// 输入: s = "bbbbb"
// 输出: 1
// 解释: 因为无重复字符的最长子串是 "b"，所以其长度为 1。
//=============================================================================
class Solution {
public:
    int lengthOfLongestSubstring2(string_view s)
    {
        int maxlen = 0;
        unordered_set<char> window;

        int l=0, r=0;
        while (r < s.size())
        {
            char rc = s[r];
            if (window.count(rc)) {
                while (window.count(rc)) {
                    window.erase(s[l]);
                    l++;
                }
            }
            window.insert(rc);
            r++;
            maxlen = max(maxlen, r-l);
        }
        return maxlen;
    }
    int lengthOfLongestSubstring(string_view s)
    {
        int maxlen = 0;
        unordered_set<char> window;

        int l=0, r=0;
        while (r < s.size())
        {
            char rc = s[r];
            if (!window.count(rc)) {
                maxlen = max(maxlen, r-l+1);
            }

            while (window.count(rc)) {
                window.erase(s[l]);
                l++;
            }
            window.insert(rc);
            r++;
        }
        return maxlen;
    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********" << endl;
    string input = "abcabcef";
    std::cout << "Input: " << input << std::endl;

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.lengthOfLongestSubstring(input);

    // 3. Print the result
    cout << "*********" << endl;
    std::cout << "Result: " << result << std::endl;

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
