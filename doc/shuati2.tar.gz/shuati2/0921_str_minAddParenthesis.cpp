#include "prepare.hpp"
#include <algorithm>
#include <queue>
#include <stack>
using namespace std;

//=============================================================================
// Cate-string
// Question:
// 给定一个括号字符串 s ，在每一次操作中，你都可以在字符串的任何位置插入一个括号
// 例如，如果 s = "()))" ，你可以插入一个开始括号为 "(()))" 或结束括号为 "())))" 。
// 返回 为使结果字符串 s 有效而必须添加的最少括号数。
// 示例 1：
// 输入：s = "())"
// 输出：1
//=============================================================================
class Solution {
public:
    int minAddToMakeValid(string s) {
        stack<char> left;
        int right;

        for (auto c : s) {
            if (c == '(') {
                left.push(c);
            }
            else {
                if (!left.empty()) {
                    left.pop();
                }
                else {
                    right++;
                }
            }
        }

        return left.size() + right;
    }
};

int main(int argc, const char *argv[])
{
    cout << "********* Input" << endl;
    string input = "))())(";
    std::cout << "Input: " << input << std::endl;

    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.minAddToMakeValid(input);
    std::cout << "Result: " << result << std::endl;

    std::cout << "Result2: " << sol.minInsertions("(()))(()))()())))") << std::endl;

    cout << "*********" << endl;
    return 0;
} /* end of main */
