#include "prepare.hpp"
using namespace std;

//=============================================================================
// Cate-arr
// Question: 删除有序数组中的重复项
//
// 给你一个 非严格递增排列 的数组 nums ，请你 原地 删除重复出现的元素，使每个元素 只出现一次 ，
// 返回删除后数组的新长度。元素的 相对顺序 应该保持 一致 。然后返回 nums 中唯一元素的个数。
//
// 考虑 nums 的唯一元素的数量为 k ，你需要做以下事情确保你的题解可以被通过：
//
// 更改数组 nums ，使 nums 的前 k 个元素包含唯一元素，并按照它们最初在 nums 中出现的顺序排列。nums 的其余元素与 nums 的大小不重要。
// 返回 k 。
//
// 输入：nums = [1,1,2]
// 输出：2, nums = [1,2,_]
// 解释：函数应该返回新的长度 2 ，并且原数组 nums 的前两个元素被修改为 1, 2 。不需要考虑
//=============================================================================
class Solution {
public:
    int removeDuplicates(vector<int>& nums)
    {
        if (nums.empty())
        {
            return 0;
        }

        int target = nums[0];
        int idx = 1;

        for (auto obj : nums) {
            if (obj != target)
            {
                nums[idx++] = obj;
                target = obj;
            }
        }
        return idx;
    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********" << endl;
    std::vector<int> input{1,1,3,4,4,4,5,6};
    printArray(input);

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.removeDuplicates(input);

    // 3. Print the result
    cout << "*********" << endl;
    std::cout << "Return: " << result << std::endl;
    printArray(input);

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
