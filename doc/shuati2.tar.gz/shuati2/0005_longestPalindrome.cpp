#include "prepare.hpp"
#include <string_view>
using namespace std;

//=============================================================================
// Question:
// 给你一个字符串 s，找到 s 中最长的 回文 子串。

// 示例 1：
//
// 输入：s = "babad"
// 输出："bab"
// 解释："aba" 同样是符合题意的答案。
// 示例 2：
//
// 输入：s = "cbbd"
// 输出："bb"
//=============================================================================
class Solution {
public:
    bool isPalindrome(string_view s, int l, int r)
    {
        while (l < r && s[l] == s[r])
        {
            l++;
            r--;
        }

        return l >= r;
    }

    string longestPalindrome(std::string_view s)
    {
        if (s.empty() || s.size() == 1)
        {
            return string(s);
        }
        string_view res(s.data(), 1);


        for (int l =0; l < s.size() && res.size() < s.size() - l; l++) {
            for (int r = s.size()-1; r > l; r--) {
                if (isPalindrome(s, l ,r))
                {
                    string_view subs = s.substr(l, r-l+1);
                    if (res.size() < subs.size())
                    {
                        res = subs;
                    }
                    break;
                }
            }
        }
        return string(res);
    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********" << endl;
    string input = "ac";
    std::cout << "Input: " << input << std::endl;

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.longestPalindrome(input);

    // 3. Print the result
    cout << "*********" << endl;
    std::cout << "Result: " << result << std::endl;

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
