#include "prepare.hpp"
using namespace std;



// Cate-List
// 给你一个链表的头节点 head 和一个特定值 x ，请你对链表进行分隔，使得所有 小于 x 的节点都出现在 大于或等于 x 的节点之前。
//
// 你应当 保留 两个分区中每个节点的初始相对位置。
//
// Example1:
// 输入：head = [1,4,3,2,5,2], x = 3
// 输出：[1,2,2,4,3,5]
//
// Example2:
// 输入：head = [2,1], x = 2
// 输出：[1,2]
//

class Solution {
public:
/*     ListNode* splitList(ListNode* head, int x) {
 *         ListNode less_dummy(0); // Dummy head for the "less" list
 *         ListNode greater_equal_dummy(0); // Dummy head for the "greater or equal" list
 *
 *         ListNode* less_ptr = &less_dummy;
 *         ListNode* greater_equal_ptr = &greater_equal_dummy;
 *         ListNode* current = head;
 *
 *         while (current != nullptr) {
 *             if (current->val < x) {
 *                 less_ptr->next = current;
 *                 less_ptr = less_ptr->next;
 *             } else {
 *                 greater_equal_ptr->next = current;
 *                 greater_equal_ptr = greater_equal_ptr->next;
 *             }
 *             current = current->next;
 *         }
 *
 *         // Connect the two lists
 *         greater_equal_ptr->next = nullptr; // Important: terminate the second list
 *         less_ptr->next = greater_equal_dummy.next; // Connect less list to greater_equal list
 *
 *         return less_dummy.next; // Return the head of the merged list
 *     } */

    ListNode* splitList(ListNode* head, int x) {
        auto low = ListNode();
        auto high = ListNode();

        ListNode* lp = &low;
        ListNode* hp = &high;

        while (head != nullptr)
        {
            if (head->val < x)
            {
                lp->next = head;
                lp = lp->next;
                head = head->next;
                lp->next = nullptr;
            }
            else
            {
                hp->next = head;
                hp = hp->next;
                head = head->next;
                hp->next = nullptr;
            }
        }

        if (high.next != nullptr)
        {
            lp->next = high.next;
        }

        return low.next;
    }
};

int main(int argc, const char *argv[])
{
    cout << "*********" << endl;
    // 1. Construct input example structure and print them
    ListNode *head = new ListNode(1);
    head->next = new ListNode(4);
    head->next->next = new ListNode(3);
    head->next->next->next = new ListNode(2);
    head->next->next->next->next = new ListNode(5);
    head->next->next->next->next->next = new ListNode(2);
    int x = 3;

    std::cout << "Input List: ";
    printList(head);
    std::cout << "Partition value x: " << x << std::endl;

    cout << "*********" << endl;
    // 2. Print that we are going on Solution
    std::cout << "Going on Solution..." << std::endl;
    Solution sol;
    auto result = sol.splitList(head, x);

    cout << "*********" << endl;
    // 3. Print the result
    std::cout << "Result List: ";
    printList(result);

    cout << "*********" << endl;

    // Clean up memory (optional for LeetCode, good practice otherwise)
    // Note: Since splitList rearranges nodes, we only need to delete the list starting from the new head 'result'.
    // The original 'head' pointer might point to a node within the rearranged list or be the start itself.
    // Deleting 'result' will clean up all nodes.
    deleteList(result); // Be careful if original head is needed elsewhere. In this main, it's safe.

    return 0;
} /* end of main */
