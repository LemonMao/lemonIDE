#include "prepare.hpp"
#include <algorithm>
#include <deque>
#include <queue>
#include <vector>
using namespace std;

//=============================================================================
// Cate-arr, Hard
// Question:
// 给你一个整数数组 nums，有一个大小为 k 的滑动窗口从数组的最左侧移动到数组的最右侧。你只可以看到在滑动窗口内的 k 个数字。滑动窗口每次只向右移动一位。
// 返回 滑动窗口中的最大值 。
//
// 示例 1：
//
// 输入：nums = [1,3,-1,-3,5,3,6,7], k = 3
// 输出：[3,3,5,5,6,7]
// 解释：
// 滑动窗口的位置                最大值
// ---------------               -----
// [1  3  -1] -3  5  3  6  7       3
 // 1 [3  -1  -3] 5  3  6  7       3
 // 1  3 [-1  -3  5] 3  6  7       5
 // 1  3  -1 [-3  5  3] 6  7       5
 // 1  3  j1  -3 [5  3  6] 7       6
 // 1  3  -1  -3  5 [3  6  7]      7
//=============================================================================
class Solution {
public:
    vector<int> maxSlidingWindow(vector<int>& nums, int k) {
        int l=0, r=0, n=nums.size();
        deque<int> q;
        vector<int> res;

        while (r < n)
        {
            while (!q.empty() && nums[q.back()] < nums[r])
            {
                q.pop_back();
            }
            q.push_back(r);
            r++;

            if (r-l == k) {
                res.push_back(nums[q.front()]);
                if (q.front() == l) {
                    q.pop_front();
                }
                l++;
            }
        }

        return res;
    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********" << endl;
    std::vector<int> input{1,3,-1,-3,5,3,6,7};
    printArray(input);

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.maxSlidingWindow(input, 3);

    // 3. Print the result
    cout << "*********" << endl;
    printResult(result);

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
