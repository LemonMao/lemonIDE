#include "prepare.hpp"
#include <vector>
using namespace std;

//=============================================================================
// Question:
// 按照国际象棋的规则，皇后可以攻击与之处在同一行或同一列或同一斜线上的棋子。
//
// n 皇后问题 研究的是如何将 n 个皇后放置在 n×n 的棋盘上，并且使皇后彼此之间不能相互攻击。
//
// 给你一个整数 n ，返回所有不同的 n 皇后问题 的解决方案。
//
// 每一种解法包含一个不同的 n 皇后问题 的棋子放置方案，该方案中 'Q' 和 '.' 分别代表了皇后和空位。
// 输入：n = 4
// 输出：[[".Q..","...Q","Q...","..Q."],["..Q.","Q...","...Q",".Q.."]]
// 解释：如上图所示，4 皇后问题存在两个不同的解法。
//=============================================================================)
class Solution {
public:
    vector<vector<string>> res;
    vector<vector<string>> solveNQueens(int n)
    {
        vector<string> path;
        if (n == 1) {
            path.push_back("Q");
            res.push_back(path);
            return res;
        }
        backtrace(path, n);
        return res;
    }

    bool isValid(vector<string> &path, int col, int n)
    {
        for (int row=path.size()-1, col2=col+1, col3=col-1; row >= 0; row--, col2++, col3--) {
            if (path[row][col] == 'Q'
                || (col2 < n && path[row][col2] == 'Q')
                || (col3 >= 0 && path[row][col3] == 'Q')){
                return false;
            }
        }
        return true;
    }

    void backtrace(vector<std::string> &path, int n)
    {
        if (path.size() == n) {
            res.push_back(path);
            return;
        }

        string rstr(n, '.');
        for (int col = 0; col < n; ++col) {
            if (!isValid(path, col, n)) {
                continue;
            }
            rstr[col] = 'Q';
            path.push_back(rstr);
            backtrace(path, n);
            path.pop_back();
            rstr[col] = '.';
        }

        return;
    }
};

int main(int argc, const char *argv[])
{
    cout << "********* Input" << endl;
    int input = 4;
    std::cout << "Input: " << input << std::endl;

    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.solveNQueens(input);
    printResult(result);

    cout << "*********" << endl;
    return 0;
} /* end of main */
