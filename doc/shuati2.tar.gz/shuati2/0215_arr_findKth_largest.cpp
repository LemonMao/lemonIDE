#include "prepare.hpp"
#include <vector>
#include <algorithm> // For std::swap
#include <random>    // For std::default_random_engine, std::uniform_int_distribution
#include <chrono>    // For std::chrono::system_clock
using namespace std;

//=============================================================================
// Cate-array
// Question:
// 给定整数数组 nums 和整数 k，请返回数组中第 k 个最大的元素。
// 请注意，你需要找的是数组排序后的第 k 个最大的元素，而不是第 k 个不同的元素。
// 你必须设计并实现时间复杂度为 O(n) 的算法解决此问题。
// 示例 1:
// 输入: [3,2,1,5,6,4], k = 2
// 输出: 5
//
//=============================================================================
class Solution {
public:
    // 方法1： 优先级队列
    int findKthLargest(vector<int>& nums, int k) {
        auto greater2 = [](int p, int c){ return p > c; };
        priority_queue<int, vector<int>, decltype(greater2)> que;
        for (auto i : nums) {
            que.push(i);
            if (que.size() > k) {
                que.pop();
            }
        }
        return que.top();
    }

    // 方法2：快速选择
    int findKthLargest2(vector<int>& nums, int k) {
        int n = nums.size();
        return quickSelect(nums, 0, n - 1, n - k);
    }

    // QuickSelect function
    int quickSelect(vector<int>& nums, int left, int right, int kIdx) {
        if (left == right) {
            return nums[left];
        }

        int pivot_index = partition(nums, left, right);

        // The pivot is in its final sorted position
        if (kIdx == pivot_index) {
            return nums[kIdx];
        } else if (kIdx < pivot_index) {
            return quickSelect(nums, left, pivot_index - 1, kIdx);
        } else {
            return quickSelect(nums, pivot_index + 1, right, kIdx);
        }
    }

    // Partition function for QuickSelect
    int partition(vector<int>& nums, int left, int right) {
        // Use the rightmost element as pivot
        int pivot_value = nums[right];

        int store_index = left;
        for (int i = left; i < right; ++i) {
            if (nums[i] < pivot_value) {
                swap(nums[store_index], nums[i]);
                store_index++;
            }
        }
        // Move pivot to its final sorted position
        swap(nums[right], nums[store_index]);
        return store_index;
    }

};

int main(int argc, const char *argv[])
{
    cout << "********* Input" << endl;
    std::vector<int> input{3,2,1,5,6,4};
    printArray(input);

    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.findKthLargest(input, 2);
    printResult(result);

    cout << "*********" << endl;
    return 0;
} /* end of main */
