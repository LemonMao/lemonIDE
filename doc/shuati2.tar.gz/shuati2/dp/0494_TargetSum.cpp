#include "../prepare.hpp"
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;

//=============================================================================
// Cate-dp
// Question:
// 给你一个非负整数数组 nums 和一个整数 target 。
// 向数组中的每个整数前添加 '+' 或 '-' ，然后串联起所有整数，可以构造一个 表达式 ：
// 例如，nums = [2, 1] ，可以在 2 之前添加 '+' ，在 1 之前添加 '-' ，然后串联起来得到表达式 "+2-1" 。
// 返回可以通过上述方法构造的、运算结果等于 target 的不同 表达式 的数目。
// 示例 1：
// 输入：nums = [1,1,1,1,1], target = 3
// 输出：5
// 解释：一共有 5 种方法让最终目标和为 3 。
// -1 + 1 + 1 + 1 + 1 = 3
// +1 - 1 + 1 + 1 + 1 = 3
// +1 + 1 - 1 + 1 + 1 = 3
// +1 + 1 + 1 - 1 + 1 = 3
// +1 + 1 + 1 + 1 - 1 = 3
//=============================================================================
class Solution {
public:
    // vector<vector<int>> mem;
    unordered_map<string, int> mem;
    int findTargetSumWays(vector<int>& nums, int target) {
        int i = nums.size()-1;
        return dp(i, target, nums);
    }

    int dp(int i, int t, vector<int>& nums) {
        if (i < 0 && t == 0) {
            return 1;
        }
        else if (i < 0 && t != 0) {
            return 0;
        }

        string s = to_string(i) + "," + to_string(t);
        auto it = mem.find(s);
        if (it != mem.end()) {
            return it->second;
        }
        int res = dp(i-1, t+nums[i], nums) + dp(i-1, t-nums[i], nums);
        mem.insert({s, res});
        return res;
    }

    int cnt = 0;
    int findTargetSumWays2(vector<int>& nums, int target) {
        dfs(0, target, nums);
        return cnt;
    }
    void dfs(int i, int t, vector<int>& nums) {
        if (i == nums.size()) {
            if (t == 0) {
                cnt++;
            }
            return;
        }

        dfs(i+1, t-nums[i], nums);
        dfs(i+1, t+nums[i], nums);
        return;
    }
};

int main(int argc, const char *argv[])
{
    cout << "********* Input" << endl;
    std::vector<int> input{1,1,1,1,1};
    printArray(input);

    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.findTargetSumWays2(input, 3);
    printResult(result);

    cout << "*********" << endl;
    return 0;
} /* end of main */
