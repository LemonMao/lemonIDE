#include "../prepare.hpp"
using namespace std;

//=============================================================================
// Cate-dp
// Question:
//
//=============================================================================
class Solution {
public:
    void foo()
    {

    }
};

int main(int argc, const char *argv[])
{
    cout << "********* Input" << endl;
    std::vector<int> input{1,1,3};
    printResult(input);

    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.foo(input);
    printResult(result);

    cout << "*********" << endl;
    return 0;
} /* end of main */
