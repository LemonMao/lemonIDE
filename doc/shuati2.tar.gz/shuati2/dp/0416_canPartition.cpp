#include "../prepare.hpp"
#include <cstdio>
#include <vector>
using namespace std;

//=============================================================================
// Cate-dp
// Question:
//
// 给你一个 只包含正整数 的 非空 数组 nums 。请你判断是否可以将这个数组分割成两个子集，使得两个子集的元素和相等。
// 示例 1：
// 输入：nums = [1,5,11,5]
// 输出：true
// 解释：数组可以分割成 [1, 5, 5] 和 [11] 。
//=============================================================================
class Solution {
public:
    vector<vector<int>> mem;
    bool canPartition(vector<int>& nums) {
        int sum=0;
        for (auto i : nums) {
            sum += i;
        }
        if (sum%2 != 0) {
            return false;
        }
        mem.assign(nums.size()+1, vector<int>(sum+1, -1));
        return dp2(nums, 0, sum/2);
    }

    bool dp2(vector<int>& nums, int i, int val) {
        if (i == nums.size()) {
            return val == 0 ? true : false;
        }
        if (val == 0) {
            return true;
        }
        if (mem[i][val] != -1) {
            return (mem[i][val] == 0 ? false : true);
        }

        bool res=false;
        if (nums[i] > val) {
            res = dp(nums, i+1, val);
        }
        else {
            res = dp2(nums, i+1, val-nums[i]) || dp2(nums, i+1, val);
        }
        mem[i][val] = (res == true ? 1 : 0);
        return res;
    }
};

int main(int argc, const char *argv[])
{
    cout << "********* Input" << endl;
    std::vector<int> input{1,5,11,5};
    printArray(input);

    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.canPartition(input);
    printResult(result);

    cout << "*********" << endl;
    return 0;
} /* end of main */
