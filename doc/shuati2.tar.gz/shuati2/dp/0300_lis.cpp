#include "../prepare.hpp"
#include <algorithm>
#include <vector>
using namespace std;

//=============================================================================
// Question:
// 给你一个整数数组 nums ，找到其中最长严格递增子序列的长度。
//
// 子序列 是由数组派生而来的序列，删除（或不删除）数组中的元素而不改变其余元素的顺序。例如，[3,6,2,7] 是数组 [0,3,1,6,2,2,7] 的子序列。
//
// 示例 1：
//
// 输入：nums = [10,9,2,5,3,7,101,18]
// 输出：4
// 解释：最长递增子序列是 [2,3,7,101]，因此长度为 4 。
// 示例 2：
//
// 输入：nums = [0,1,0,3,2,3]
// 输出：4
//
//=============================================================================
class Solution {
public:
    int res = 0;
    int* cache = nullptr;
    // DP table
    int lengthOfLIS2(vector<int>& nums) {
        vector<int> dp(nums.size(), 0);
        dp[nums.size()-1] = 1;

        for (int i=nums.size()-2; i >= 0; i--) {
            int maxlen = 0;
            for (int j=i+1; j < nums.size(); j++) {
                maxlen = max(maxlen, nums[i] < nums[j] ? dp[j] + 1 : 1);
            }
            dp[i] = maxlen;
        }
        return dp[0];
    }

    // DFS Dp
    int lengthOfLIS(vector<int>& nums) {
        // traverse(nums, 0, 0);
        if (nums.size() == 0) {
            return 0;
        }
        cache = new int[nums.size()]{0};
        cache[nums.size()-1] = 1;
        res = max(res, dp(nums, 0));
        return res;
    }

    int dp(vector<int>& nums, int i) {
        if (cache[i] != 0) {
            return cache[i];
        }

        int maxlen = 0;
        for (int idx=i+1; idx < nums.size(); idx++) {
            int nlen = dp(nums, idx);
            maxlen = max(maxlen, (nums[i] < nums[idx] ? 1 + nlen : 1));
        }
        res = max(res, maxlen);
        cache[i] = maxlen;
        return maxlen;
    }

    // DFS
    void traverse(vector<int>& nums, int idx, int sslen) {
        if (idx == nums.size()) {
            return;
        }

        int prev = idx == 0 ? INT_MIN : nums[idx-1];
        for (; idx < nums.size(); idx++) {
            if (nums[idx] <= prev) {
                continue;
            }
            res = max(res, ++sslen);
            traverse(nums, idx+1, sslen);
            sslen--;
        }
        return;
    }
};

int main(int argc, const char *argv[])
{
    cout << "********* Input" << endl;
    // std::vector<int> input{4,4};
    std::vector<int> input{4,10,4,3,8,9};
    // std::vector<int> input{0,1,0,3,2,3};
    printArray(input);

    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.lengthOfLIS2(input);
    printResult(result);

    cout << "*********" << endl;
    return 0;
} /* end of main */
