#include "../prepare.hpp"
#include <vector>
using namespace std;

//=============================================================================
// Cate-dp
// Question:
// 给你一个字符串 s ，找出其中最长的回文子序列，并返回该序列的长度。
// 子序列定义为：不改变剩余字符顺序的情况下，删除某些字符或者不删除任何字符形成的一个序列。
// 示例 1：
// 输入：s = "bbbab"
// 输出：4
// 解释：一个可能的最长回文子序列为 "bbbb" 。
//=============================================================================
class Solution {
public:
    vector<vector<int>> mem;
    int longestPalindromeSubseq(string s) {
        int j = s.size()-1;
        mem.resize(j+1, vector<int>(j+1, -1));
        return dp(0, j, s);
    }
    int dp(int i, int j, string& s) {
        if (i > j) {
            return 0;
        }
        if (i == j) {
            return 1;
        }
        if (mem[i][j] != -1) {
            return mem[i][j];
        }

        int res = 0;
        if (s[i] == s[j]) {
            res = dp(i+1, j-1, s) + 2;
        }
        else {
            res = max(dp(i+1, j, s), dp(i, j-1, s));
        }
        mem[i][j] = res;
        return res;
    }
};

int main(int argc, const char *argv[])
{
    cout << "********* Input" << endl;
    std::string input = "bbbab";
    printResult(input);

    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.longestPalindromeSubseq(input);
    printResult(result);

    cout << "*********" << endl;
    return 0;
} /* end of main */
