#include "../prepare.hpp"
#include <vector>
using namespace std;

//=============================================================================
// Cate-dp
// Question:
// 你是一个专业的小偷，计划偷窃沿街的房屋。每间房内都藏有一定的现金，
// 影响你偷窃的唯一制约因素就是相邻的房屋装有相互连通的防盗系统，
// 如果两间相邻的房屋在同一晚上被小偷闯入，系统会自动报警。
// 给定一个代表每个房屋存放金额的非负整数数组，计算你 不触动警报装置的情况下 ，一夜之内能够偷窃到的最高金额。
// 示例 1：
// 输入：[1,2,3,1]
// 输出：4
// 解释：偷窃 1 号房屋 (金额 = 1) ，然后偷窃 3 号房屋 (金额 = 3)。
// 偷窃到的最高金额 = 1 + 3 = 4 。
//=============================================================================
class Solution {
public:
    // -- rob1
    vector<int> mem;
    int rob(vector<int>& nums) {
        mem.resize(nums.size()+1, -1);
        return dp(0, nums);
    }

    int dp(int i, vector<int>& nums) {
        int l = nums.size();
        if (i == l-1) {
            return nums[i];
        }
        if (i >= l) {
            return 0;
        }
        if (mem[i] != -1) {
            return mem[i];
        }
        int res = 0;
        res = max(nums[i]+dp(i+2, nums), nums[i+1]+dp(i+3, nums));
        mem[i] = res;
        return res;
    }

    // -- rob2
    // 这个地方所有的房屋都 围成一圈 ，这意味着第一个房屋和最后一个房屋是紧挨着的。
    vector<vector<int>> mem2;
    int rob2(vector<int>& nums) {
        int len = nums.size();
        if (len == 0) {
            return 0;
        }
        else if (len == 1) {
            return nums[0];
        }
        else if (len == 2) {
            return max(nums[0], nums[1]);
        }
        mem2.resize(2, vector<int>(nums.size()+1, -1));
        return max(dp2(0, len-2, nums), dp2(1, len-1, nums));
    }
    int dp2(int i, int j, vector<int>& nums) {
        int idx = nums.size()-j-1;
        if (i == j) {
            return nums[i];
        }
        if (i > j) {
            return 0;
        }
        if (mem2[idx][i] != -1) {
            return mem2[j-1][i];
        }

        int res = 0;
        res = max(nums[i]+dp2(i+2, j, nums), nums[i+1]+dp2(i+3, j, nums));
        mem2[idx][i] = res;
        return res;
    }

};

int main(int argc, const char *argv[])
{
    cout << "********* Input" << endl;
    std::vector<int> input{1,2,3,1};
    printArray(input);

    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.rob2(input);
    printResult(result);

    cout << "*********" << endl;
    return 0;
} /* end of main */
