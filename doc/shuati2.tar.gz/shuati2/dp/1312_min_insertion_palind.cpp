#include "../prepare.hpp"
#include <vector>
using namespace std;

//=============================================================================
// Cate-dp
// Question:
// 给你一个字符串 s ，每一次操作你都可以在字符串的任意位置插入任意字符。
// 请你返回让 s 成为回文串的 最少操作次数 。
// 「回文串」是正读和反读都相同的字符串。
// 示例 1：
// 输入：s = "zzazz"
// 输出：0
// 解释：字符串 "zzazz" 已经是回文串了，所以不需要做任何插入操作。
//=============================================================================
class Solution {
public:
    vector<vector<int>> mem;
    int minInsertions(string s) {
        int j = s.size()-1;
        mem.resize(j+2, vector<int>(j+2, -1));
        return dp(0, j, s);
    }

    int dp(int i, int j, string& s) {
        if (i >= j) {
            return 0;
        }
        if (mem[i][j] != -1) {
            return mem[i][j];
        }

        int res = 0;
        if (s[i] == s[j]) {
            res = dp(i+1, j-1, s);
        }
        else {
            res = min(dp(i+1, j, s), dp(i, j-1, s)) + 1;
        }
        mem[i][j] = res;
        return res;
    }
};

int main(int argc, const char *argv[])
{
    cout << "********* Input" << endl;
    std::string input = "zzazz";
    printResult(input);
    std::string input2 = "leetcode";
    printResult(input2);

    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    /* auto result = sol.minInsertions(input);
     * printResult(result); */
    auto result = sol.minInsertions(input2);
    printResult(result);

    cout << "*********" << endl;
    return 0;
} /* end of main */
