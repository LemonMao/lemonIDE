#include "../prepare.hpp"
#include <queue>
#include <vector>
using namespace std;

//=============================================================================
// Cate-dp
// Question: maxprofix
//
//
//=============================================================================
class Solution {
    int maxProfit13(vector<int>& prices) {
        int ret=0, buy=prices[0];
        for (int i=0; i < prices.size(); i++) {
            ret = max(prices[i] - buy, ret);
        }
    }
public:
    // --- 股票1
    // 给定一个数组 prices ，它的第 i 个元素 prices[i] 表示一支给定股票第 i 天的价格。
    // 你只能选择 某一天 买入这只股票，并选择在 未来的某一个不同的日子 卖出该股票。设计一个算法来计算你所能获取的最大利润。
    // 返回你可以从这笔交易中获取的最大利润。如果你不能获取任何利润，返回 0 。
    // 示例 1：
    // 输入：[7,1,5,3,6,4]
    // 输出：5
    // 解释：在第 2 天（股票价格 = 1）的时候买入，在第 5 天（股票价格 = 6）的时候卖出，最大利润 = 6-1 = 5 。
    // 注意利润不能是 7-1 = 6, 因为卖出价格需要大于买入价格；同时，你不能在买入前卖出股票。
    int maxProfit1(vector<int>& prices) {
        int res = 0, num=prices.size();
        for (int i=0; i < num; i++) {
            for (int j=i+1; j < num; j++) {
                int profit = prices[j] - prices[i];
                res = max(res, profit);
            }
        }
        return res;
    }

    int maxProfit12(vector<int>& prices) {
        int res = 0, num=prices.size();

        int minv = prices[0];
        for (int i = 1; i < num; i++) {
            int profit = prices[i] - minv;
            res = max(res, profit);
            minv = min(prices[i], minv);
        }
        return res;
    }

    // --- 股票2
    // 给你一个整数数组 prices ，其中 prices[i] 表示某支股票第 i 天的价格。
    // 在每一天，你可以决定是否购买和/或出售股票。你在任何时候 最多 只能持有 一股 股票。你也可以先购买，然后在 同一天 出售。
    // 返回 你能获得的 最大 利润 。
    // 示例 1：
    // 输入：prices = [7,1,5,3,6,4]
    // 输出：7
    // 解释：在第 2 天（股票价格 = 1）的时候买入，在第 3 天（股票价格 = 5）的时候卖出, 这笔交易所能获得利润 = 5 - 1 = 4。
    // 随后，在第 4 天（股票价格 = 3）的时候买入，在第 5 天（股票价格 = 6）的时候卖出, 这笔交易所能获得利润 = 6 - 3 = 3。
    // 最大总利润为 4 + 3 = 7 。
    int maxProfit2(vector<int>& prices) {
        vector<int> mem(prices.size(), -1);
        mem[prices.size()-1] = 0;
        return dp(prices, 0, mem);
    }
    int dp(vector<int>& p, int i, vector<int>& mem) {
        if (mem[i] != -1) {
            return mem[i];
        }

        int minv = p[i];
        int res = 0;
        for (int j=i+1; j < p.size(); j++) {
            int profit = p[j] - minv;
            res = max(res, profit + dp(p, j, mem));
            minv = min(minv, p[j]);
        }
        mem[i] = res;
        return res;
    }

    // --- 股票3
    // 给定一个数组，它的第 i 个元素是一支给定的股票在第 i 天的价格。设计一个算法来计算你所能获取的最大利润。你最多可以完成 两笔 交易。
    // 注意：你不能同时参与多笔交易（你必须在再次购买前出售掉之前的股票）。
    // 示例 1: 输入：prices = [3,3,5,0,0,3,1,4]  , 输出：6
    // 解释：在第 4 天（股票价格 = 0）的时候买入，在第 6 天（股票价格 = 3）的时候卖出，这笔交易所能获得利润 = 3-0 = 3 。
    // 随后，在第 7 天（股票价格 = 1）的时候买入，在第 8 天 （股票价格 = 4）的时候卖出，这笔交易所能获得利润 = 4-1 = 3 。
    int maxProfit3(vector<int>& prices) {
        int minv = prices[0];
        int res = 0;
        int num = prices.size();

        vector<int> mem(num, -1);
        mem[num-1] = 0;

        for (int i = 1; i < num; i++) {
            res = max(res, dp2(prices, i, mem) + prices[i] - minv);
            minv = min(minv, prices[i]);
        }
        return res;
    }
    int dp2(vector<int>& p, int i, vector<int>& mem) {
        if (mem[i] != -1) {
            return mem[i];
        }

        int res = 0;
        int minv = p[i];
        for (int j=i+1; j < p.size(); j++) {
            res = max(res, p[j] - minv);
            minv = min(minv, p[j]);
        }
        return res;
    }

    // 基金交易
    // 题目描述
    // 拟定一个整数数组 prices,prices［表示第i天的基金产品价格行情；整数fee代表了交易基金的手续费用。
    // 可以无限次数地完成交易，但是你每笔交易都需要付手续费。如果你已经购买了一个基金产品，在卖出它之前你就不能再继续购买基金产品。
    // 返回获得利润的最大值。
    // 注意：这里的一笔交易指买入持有并卖出基金产品的整个过程，每笔交易你只需要为支付一次手续费。
    // 不例1：
    // 输入：prices = ［1, 3, 2, 8, 4, 9］， fee = 2
    // 输出：8
    // 解释：能够达到的最大利润：
    // 在此处买入 prices［0］ = 1
    // 在此处卖出 prices［3］ = 8
    // 在此处买入 prices［4］=4
    // 在此处卖出 prices［5］ = 9
    // 总利润：（（8 - 1）- 2） + （（9-4） - 2） =8
    int maxProfit3(vector<int>& prices) {
    }
};

int main(int argc, const char *argv[])
{
    cout << "********* Input" << endl;
    std::vector<int> input{7,1,5,3,6,4};
    std::vector<int> input2{1,2,3,4};
    printArray(input);
    printArray(input2);

    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.maxProfit3(input);
    printResult(result);
    result = sol.maxProfit3(input2);
    printResult(result);

    cout << "*********" << endl;
    return 0;
} /* end of main */
