#include "../prepare.hpp"
#include <vector>
using namespace std;

//=============================================================================
// Cate-dp
// Question:
// 给你一个整数数组 coins 表示不同面额的硬币，另给一个整数 amount 表示总金额。
// 请你计算并返回可以凑成总金额的硬币组合数。如果任何硬币组合都无法凑出总金额，返回 0 。
// 假设每一种面额的硬币有无限个 , 题目数据保证结果符合 32 位带符号整数。
// 示例 1：
// 输入：amount = 5, coins = [1, 2, 5]
// 输出：4
// 解释：有四种方式可以凑成总金额：
// 5=5
// 5=2+2+1
// 5=2+1+1+1
// 5=1+1+1+1+1
//=============================================================================
class Solution {
public:
    vector<vector<int>> mem;
    int change(int amount, vector<int>& coins) {
        mem.resize(coins.size()+1, vector<int>(amount+1, -1));
        return dfs(amount, coins, 0);
    }

    int dfs(int amount, vector<int>& coins, int i) {
        if (amount == 0) {
            return 1;
        }
        if (i == coins.size()) {
            return 0;
        }
        if (mem[i][amount] != -1) {
            return mem[i][amount];
        }

        int cnt = 0;
        if (coins[i] > amount) {
            cnt = dfs(amount, coins, i+1);
        }
        else {
            cnt = dfs(amount-coins[i], coins, i) + dfs(amount, coins, i+1);
        }

        mem[i][amount] = cnt;
        return cnt;
    }
};

int main(int argc, const char *argv[])
{
    cout << "********* Input" << endl;
    std::vector<int> input{1,2,5};
    printArray(input);

    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.change(5, input);
    printResult(result);

    cout << "*********" << endl;
    return 0;
} /* end of main */
