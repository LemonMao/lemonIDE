#include "../prepare.hpp"
#include <vector>
using namespace std;

//=============================================================================
// Cate-dp
// Question:
// 给你一个 n x n 的 方形 整数数组 matrix ，请你找出并返回通过 matrix 的下降路径 的 最小和 。
// 下降路径 可以从第一行中的任何元素开始，并从每一行中选择一个元素。在下一行选择的元素和当前行所选元素最多相隔一列
// （即位于正下方或者沿对角线向左或者向右的第一个元素）。
// 具体来说，位置 (row, col) 的下一个元素应当是 (row + 1, col - 1)、(row + 1, col) 或者 (row + 1, col + 1) 。
//
// 输入：matrix = [[2,1,3],[6,5,4],[7,8,9]]
// 输出：13
// 解释：如图所示，为和最小的两条下降路径
//=============================================================================
class Solution {
public:
    vector<vector<int>> mem;
    int res = INT_MAX;
    int minFallingPathSum(vector<vector<int>>& matrix) {
        int rl = matrix.size();
        int cl = matrix[0].size();
        mem.resize(rl+1, vector<int>(cl+1, INT_MAX));
        for (int j = cl -1; j >= 0; j--) {
            res = min(dp(rl-1, j, matrix), res);
        }
        return res;
    }

    int dp(int i, int j, vector<vector<int>>& matrix) {
        if (i < 0 ) {
            return 0;
        }
        if (j < 0 || j >= matrix[0].size()) {
            return INT_MAX;
        }
        if (mem[i][j] != INT_MAX) {
            return mem[i][j];
        }

        int res = min(dp(i-1, j-1, matrix), min(dp(i-1, j, matrix), dp(i-1, j+1, matrix))) + matrix[i][j];
        mem[i][j] = res;
        return res;
    }
};

int main(int argc, const char *argv[])
{
    cout << "********* Input" << endl;
    // std::vector<vector<int>> input{{2,1,3},{6,5,4},{7,8,9}};
    std::vector<vector<int>> input{{100,-42,-46,-41},{31,97,10,-10},{-58,-51,82,89},{51,81,69,-51}};
    printResult(input);

    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.minFallingPathSum(input);
    printResult(result);

    cout << "*********" << endl;
    return 0;
} /* end of main */
