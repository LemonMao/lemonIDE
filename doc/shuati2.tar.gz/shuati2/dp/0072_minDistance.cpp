#include "../prepare.hpp"
#include <string>
#include <typeinfo>
#include <vector>
using namespace std;

//=============================================================================
// Cate-dp
// Question:
// 给你两个单词 word1 和 word2， 请返回将 word1 转换成 word2 所使用的最少操作数  。
//
// 你可以对一个单词进行如下三种操作：
//
// 插入一个字符
// 删除一个字符
// 替换一个字符
//
//
// 示例 1：
//
// 输入：word1 = "horse", word2 = "ros"
// 输出：3
// 解释：
// horse -> rorse (将 'h' 替换为 'r')
// rorse -> rose (删除 'r')
// rose -> ros (删除 'e')
//=============================================================================
class Solution {
public:
    int minDistance(string word1, string word2) {
        vector<vector<int>> mem = {word1.size(), vector<int>(word2.size(), 0)};
        return dp(word1, word1.size()-1, word2, word2.size()-1, mem);
    }

    int dp(string_view s1, int i, string_view s2, int j, vector<vector<int>>& mem) {
        if (i == -1) {
            return j+1;
        }
        if (j == -1) {
            return i+1;
        }

        if (mem[i][j] != 0) {
            return mem[i][j];
        }

        int cnt=0;
        if (s1[i] == s2[j]) {
            cnt = dp(s1, i-1, s2, j-1, mem);
        }
        else {

            cnt = min(dp(s1, i, s2, j-1, mem) + 1,
                       min (dp(s1, i-1, s2, j, mem) + 1, dp(s1, i-1, s2, j-1, mem) + 1));
        }
        mem[i][j] = cnt;
        return cnt;
    }
};

int main(int argc, const char *argv[])
{
    cout << "********* Input" << endl;
    string s1 = "horse";
    string s2 = "ros";
    std::cout << "S1: "<< s1 << ", S2:" << s2 << std::endl;

    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.minDistance(s1, s2);
    printResult(result);

    cout << "*********" << endl;
    return 0;
} /* end of main */
