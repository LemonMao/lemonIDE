#include "../prepare.hpp"
#include <vector>
using namespace std;

//=============================================================================
// Cate-dp
// Question:
//给定一个包含非负整数的 m x n 网格 grid ，请找出一条从左上角到右下角的路径，使得路径上的数字总和为最小。
// 说明：每次只能向下或者向右移动一步。
// 示例 2：
// 输入：grid = [[1,2,3],[4,5,6]]
// 输出：12
//=============================================================================
class Solution {
public:
    vector<vector<int>> mem;
    int minPathSum(vector<vector<int>>& grid) {
        int i = grid.size()-1;
        int j = grid[0].size()-1;
        mem.resize(i+1, vector<int>(j+1, -1));
        return dp(i, j, grid);
    }

    int dp(int i, int j, vector<vector<int>>& grid) {
        if (i < 0 || j < 0) {
            return INT_MAX;
        }
        if (i == 0 && j == 0) {
            return grid[0][0];
        }
        if (mem[i][j] != -1) {
            return mem[i][j];
        }

        int res = min(dp(i-1, j, grid), dp(i, j-1, grid)) + grid[i][j];
        mem[i][j] = res;
        return res;
    }
};

int main(int argc, const char *argv[])
{
    cout << "********* Input" << endl;
    std::vector<vector<int>> input{{1,2,3}, {4,5,6}};
    printResult(input);

    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.minPathSum(input);
    printResult(result);

    cout << "*********" << endl;
    return 0;
} /* end of main */
