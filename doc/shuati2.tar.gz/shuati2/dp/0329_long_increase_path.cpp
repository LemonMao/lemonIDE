#include "../prepare.hpp"
#include <utility>
#include <vector>
using namespace std;

//=============================================================================
// Cate-dp
// Question:
// 给定一个 m x n 整数矩阵 matrix ，找出其中 最长递增路径 的长度。
//
// 对于每个单元格，你可以往上，下，左，右四个方向移动。 你 不能 在 对角线 方向上移动或移动到 边界外（即不允许环绕）。
// 输入：matrix = [[9,9,4],[6,6,8],[2,1,1]]
// 输出：4
// 解释：最长递增路径为 [1, 2, 6, 9]。
//=============================================================================
class Solution {
public:
    vector<vector<int>> mem;
    int longestIncreasingPath(vector<vector<int>>& matrix) {
        int r = matrix.size();
        int c = matrix[0].size();
        int res = 0;
        mem.resize(r, vector<int>(c, 0));
        for (int i=0; i < r; i++) {
            for (int j=0; j < c; j++) {
                res = max(dfs(matrix, i, j), res);
            }
        }
        return res;
    }

    int dfs(vector<vector<int>>& matrix, int i, int j) {
        int r = matrix.size();
        int c = matrix[0].size();
        int res = 1;

        if (mem[i][j] != 0) {
            return mem[i][j];
        }

        for (auto [ix, jx] : vector<pair<int, int>>{{0,-1}, {0, 1}, {1, 0}, {-1, 0}}) {
            if (i+ix < r && i+ix >=0 && j+jx < c && j+jx >= 0) {
                if (matrix[i+ix][j+jx] > matrix[i][j]) {
                    res = max(res, dfs(matrix, i+ix, j+jx)+1);
                }
            }
        }
        mem[i][j] = res;
        return res;
    }
};

int main(int argc, const char *argv[])
{
    cout << "********* Input" << endl;
    vector<vector<int>> input{{9,9,4},{6,6,8},{2,1,1}};
    printResult(input);

    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.longestIncreasingPath(input);
    printResult(result);

    cout << "*********" << endl;
    return 0;
} /* end of main */
