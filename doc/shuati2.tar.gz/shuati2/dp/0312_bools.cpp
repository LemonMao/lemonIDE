#include "../prepare.hpp"
#include <vector>
#include <algorithm>
#include <map> // For memoization
using namespace std;

//=============================================================================
// Cate-dp
// Question:
// 有 n 个气球，编号为0 到 n - 1，每个气球上都标有一个数字，这些数字存在数组 nums 中。
// 现在要求你戳破所有的气球。戳破第 i 个气球，你可以获得 nums[i - 1] * nums[i] * nums[i + 1] 枚硬币。
// 这里的 i - 1 和 i + 1 代表和 i 相邻的两个气球的序号。如果 i - 1或 i + 1 超出了数组的边界，那么就当它是一个数字为 1 的气球。
// 求所能获得硬币的最大数量。
// 示例 1：
// 输入：nums = [3,1,5,8]
// 输出：167
// 解释：
// nums = [3,1,5,8] --> [3,5,8] --> [3,8] --> [8] --> []
// coins =  3*1*5    +   3*5*8   +  1*3*8  + 1*8*1 = 167
//=============================================================================
class Solution {
public:
    // Memoization table to store results of subproblems
    map<pair<int, int>, int> memo;

    int maxCoins(vector<int>& nums) {
        // Pad the original array with 1s at both ends to handle boundary conditions
        vector<int> padded_nums;
        padded_nums.push_back(1);
        for (int num : nums) {
            padded_nums.push_back(num);
        }
        padded_nums.push_back(1);

        return calculateMaxCoins(padded_nums, 0, padded_nums.size() - 1);
    }

private:
    int calculateMaxCoins(const vector<int>& p_nums, int left, int right) {
        if (left + 1 == right) {
            return 0;
        }

        if (memo.count({left, right})) {
            return memo[{left, right}];
        }

        int max_coins = 0;
        // Iterate through all possible balloons 'k' that could be the last one burst
        // in the interval (left, right)
        for (int k = left + 1; k < right; ++k) {
            int current_burst_coins = p_nums[left] * p_nums[k] * p_nums[right];
            int left_subproblem_coins = calculateMaxCoins(p_nums, left, k);
            int right_subproblem_coins = calculateMaxCoins(p_nums, k, right);

            max_coins = max(max_coins, current_burst_coins + left_subproblem_coins + right_subproblem_coins);
            // std::cout << left << ":" << right << ", max:" << max_coins << std::endl;
        }

        memo[{left, right}] = max_coins;
        return max_coins;
    }
};

int main(int argc, const char *argv[])
{
    cout << "********* Input" << endl;
    std::vector<int> input{3,1,5,8};
    printArray(input);

    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.maxCoins(input);
    printResult(result);

    cout << "*********" << endl;
    return 0;
} /* end of main */
