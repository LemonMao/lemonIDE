#ifndef _PREPARE_H_
#define _PREPARE_H_

#include <list>
#include <cmath>
#include <iostream>
#include <vector>
#include <map>
#include <string>
#include <memory>
#include <unordered_map>
#include <unordered_set>
#include <algorithm>

using namespace std;

//=============================================================================
// Binary tree
//=============================================================================
struct TreeNode
{
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};

// Function to create a binary tree from a level-order vector representation
// Uses -1 to represent null nodes
#include <vector>
#include <queue>

TreeNode* createTree(const std::vector<int>& arr) {
    if (arr.empty() || arr[0] == -1) {
        return nullptr;
    }

    TreeNode* root = new TreeNode(arr[0]);
    std::queue<TreeNode*> q;
    q.push(root);
    int i = 1;
    while (i < arr.size() && !q.empty()) {
        TreeNode* current = q.front();
        q.pop();

        // Process left child
        if (arr[i] != -1) {
            current->left = new TreeNode(arr[i]);
            q.push(current->left);
        }
        i++;

        if (i >= arr.size()) break;

        // Process right child
        if (arr[i] != -1) {
            current->right = new TreeNode(arr[i]);
            q.push(current->right);
        }
        i++;
    }
    return root;
}

// Function to print a binary tree (Level Order Traversal)
void printTree(TreeNode* root) {
    if (!root) {
        std::cout << "[]" << std::endl;
        return;
    }

    std::cout << "[ ";
    std::queue<TreeNode*> q;
    q.push(root);
    int nodesInLevel = 1;
    int nextLevelNodes = 0;
    bool first = true;

    while (!q.empty()) {
        TreeNode* current = q.front();
        q.pop();
        nodesInLevel--;

        if (current) {
             if (!first) std::cout << ", ";
             std::cout << current->val;
             first = false;

            if (current->left) {
                q.push(current->left);
                nextLevelNodes++;
            } else {
                 q.push(nullptr); // Push null marker for structure
            }
            if (current->right) {
                q.push(current->right);
                nextLevelNodes++;
            } else {
                 q.push(nullptr); // Push null marker for structure
            }
        } else {
             if (!first) std::cout << ", ";
             std::cout << "null";
             first = false;
        }

        if (nodesInLevel == 0) {
            nodesInLevel = nextLevelNodes;
            nextLevelNodes = 0;
            // Check if remaining nodes are all nulls to avoid trailing nulls
            bool allNulls = true;
            std::queue<TreeNode*> tempQ = q; // Use a temporary queue for checking
            while(!tempQ.empty()){
                if(tempQ.front() != nullptr){
                    allNulls = false;
                    break;
                }
                tempQ.pop();
            }
            if(allNulls) break; // Stop if only nulls are left
        }
    }
     // Clean up trailing nulls if any were printed unnecessarily
    std::cout << " ]" << std::endl;
}


// Function to delete a binary tree
void deleteTree(TreeNode* root) {
    if (root == nullptr) {
        return;
    }
    deleteTree(root->left);
    deleteTree(root->right);
    delete root;
}

//=============================================================================
// singly-linked list.
//=============================================================================
struct ListNode {
    int val;
    ListNode *next;
    ListNode() : val(0), next(nullptr) {}
    ListNode(int x) : val(x), next(nullptr) {}
    ListNode(int x, ListNode *next) : val(x), next(next) {}
};

ListNode* createList(const std::vector<int>& arr)
{
    if (arr.empty()) {
        return nullptr;
    }
    ListNode* head = new ListNode(arr[0]);
    ListNode* cur = head;
    for (int i = 1; i < arr.size(); i++) {
        cur->next = new ListNode(arr[i]);
        cur = cur->next;
    }
    return head;
}

void printList(ListNode* head)
{
    std::cout << "[ ";
    ListNode* p = head;
    while (p != nullptr) {
        std::cout << p->val;
        if (p->next != nullptr) {
            std::cout << ", ";
        }
        p = p->next;
    }
    std::cout << " ]" << std::endl;
}

void
printNode(ListNode* node)
{
    std::cout << "Node val: " << node->val << std::endl;
}

// Helper function to delete a linked list
void deleteList(ListNode* head)
{
    ListNode* current = head;
    ListNode* next = nullptr;
    while (current != nullptr) {
        next = current->next;
        delete current;
        current = next;
    }
}

// Helper to convert initializer_list to ListNode*
ListNode* createListFromInitializerList(std::initializer_list<int> il) {
    return createList(std::vector<int>(il));
}

std::vector<ListNode*> createLists(std::initializer_list<std::initializer_list<int>> lists) {
    std::vector<ListNode*> result;
    for (const auto& il : lists) {
        result.push_back(createListFromInitializerList(il));
    }
    return result;
}

void printListOfLists(const std::vector<ListNode*>& lists) {
    std::cout << "[" << std::endl;
    for (size_t i = 0; i < lists.size(); ++i) {
        std::cout << "  ";
        printList(lists[i]);
    }
    std::cout << "]" << std::endl;
}


//=============================================================================
// Array
//=============================================================================
void printArray(const std::vector<int>& arr) {
    cout << "[";
    for (size_t i = 0; i < arr.size(); ++i) {
        cout << arr[i];
        if (i < arr.size() - 1) {
            cout << ", ";
        }
    }
    cout << "]" << endl;
}

void printStringArray(const std::vector<std::string>& arr) {
    cout << "[";
    for (size_t i = 0; i < arr.size(); ++i) {
        cout << "\"" << arr[i] << "\"";
        if (i < arr.size() - 1) {
            cout << ", ";
        }
    }
    cout << "]" << endl;
}

template <typename T>
void printResult(T obj)
{
    std::cout << "Result: " << std::endl;
    if constexpr (std::is_same_v<T, std::vector<int>>) {
        printArray(obj);
    } else if constexpr (std::is_same_v<T, std::vector<std::string>>) {
        printStringArray(obj);
    } else if constexpr (std::is_same_v<T, ListNode*>) {
        printList(obj);
    } else if constexpr (std::is_same_v<T, std::vector<ListNode*>>) {
        printListOfLists(obj);
    } else if constexpr (std::is_same_v<T, TreeNode*>) {
        printTree(obj);
    } else if constexpr (std::is_same_v<T, bool>) {
        std::cout << (obj ? "True" : "False") << std::endl;
    } else if constexpr (std::is_same_v<T, int> || std::is_same_v<T, std::string>) {
        std::cout << obj << std::endl;
    } else if constexpr (std::is_same_v<T, std::vector<std::vector<int>>>) {
        std::cout << "[" << std::endl;
        for (const auto& inner_vec : obj) {
            std::cout << "  ";
            printArray(inner_vec);
        }
        std::cout << "]" << std::endl;
    } else if constexpr (std::is_same_v<T, std::vector<std::vector<std::string>>>) {
        std::cout << "[" << std::endl;
        for (const auto& inner_vec : obj) {
            std::cout << "  ";
            printStringArray(inner_vec);
        }
        std::cout << "]" << std::endl;
    }
    else {
        // Optional: Handle other types or print a default message
        std::cout << "Unsupported type for printResult." << std::endl;
    }
}

#endif /* end of include guard: _PREPARE_H_ */
