#include "prepare.hpp"
using namespace std;

//=============================================================================
// Cate-list
// question:
// 给定一个单链表 L 的头节点 head ，单链表 L 表示为：
// L0 → L1 → … → Ln - 1 → Ln
// 请将其重新排列后变为：
// L0 → Ln → L1 → Ln - 1 → L2 → Ln - 2 → …
//
// 不能只是单纯的改变节点内部的值，而是需要实际的进行节点交换。
//
// 输入：head = [1,2,3,4]
// 输出：[1,4,2,3]
//
//=============================================================================
class Solution {
public:
    ListNode* reorderList(ListNode* head) {
        ListNode* l = head;
        ListNode* r = head;

        int cnt = 0;
        while (r->next != nullptr)
        {
            r = r->next;
            cnt++;
            if (cnt % 2 == 0) {
                l = l->next;
            }
        }

        ListNode* l1 = head;
        ListNode* l2 = l->next;
        l->next = nullptr;

        ListNode* rl2 = reverse(l2);
        ListNode* res = merge(l1, rl2);
        return res;
    }

    ListNode* reverse(ListNode* head) {
        ListNode* p = nullptr;
        ListNode* c = head;
        ListNode* n = nullptr;

        while (c != nullptr)
        {
            n = c->next;
            c->next = p;
            p = c;
            c = n;
        }
        return p;
    }

    ListNode* merge(ListNode* l1, ListNode* l2) {
        if (l1 == nullptr) {
            return l2;
        }
        else if (l2 == nullptr) {
            return l1;
        }

        ListNode* c = l1;
        ListNode* n = l2;
        ListNode* t = l2;

        while (c)
        {
            t = c->next;
            c->next = n;
            c = n;
            n = t;
        }
        return l1;
    }
};

int main(int argc, const char *argv[])
{
    cout << "********* Input" << endl;
    ListNode* input = createList({1,2,3,4});
    printList(input);

    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    ListNode* result = sol.reorderList(input);
    printResult(result);

    cout << "*********" << endl;
    return 0;
} /* end of main */
