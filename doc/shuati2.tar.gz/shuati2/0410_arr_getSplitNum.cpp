#include "prepare.hpp"
#include <vector>
using namespace std;

//=============================================================================
// Question: 分割数组的最大值
//
// 给定一个非负整数数组 nums 和一个整数 k ，你需要将这个数组分成 k 个非空的连续子数组，使得这 k 个子数组各自和的最大值 最小。
//
// 返回分割后最小的和的最大值。
//
// 子数组 是数组中连续的部份。
//
// 示例 1：
//
// 输入：nums = [7,2,5,10,8], k = 2
// 输出：18
// 解释：
// 一共有四种方法将 nums 分割为 2 个子数组。
// 其中最好的方式是将其分为 [7,2,5] 和 [10,8] 。
// 因为此时这两个子数组各自的和的最大值为18，在所有情况中最小。
//=============================================================================
class Solution {
public:
    int getMax(vector<int>& nums) {
        int max = 0;
        for (auto v : nums) {
            max = std::max(v, max);
        }
        return max;
    }

    int getSum(vector<int>& nums) {
        int sum = 0;
        for (auto v : nums) {
            sum += v;
        }
        return sum;
    }

    int getSplitNum(int ssum, vector<int>& nums) {
        int arrnum = 0;
        int cap = ssum;

        for (auto v : nums)
        {
            ssum -= v;
            if (ssum <= 0)
            {
                arrnum++;
                ssum = ssum < 0 ? cap - v : cap;
            }
        }
        if (ssum > 0 && ssum < cap)
        {
            arrnum++;
        }
        // std::cout << "ssum: " << ssum << ", arrnum: " << arrnum << std::endl;
        return arrnum;
    }

    int splitArray(vector<int>& nums, int k) {
        int left = getMax(nums);
        int right = getSum(nums) + 1;

        while (left < right)
        {
            int mid = (left + right) / 2;
            if (getSplitNum(mid, nums) > k)
            {
                left = mid + 1;
            }
            else if (getSplitNum(mid, nums) <= k)
            {
                right = mid;
            }
        }
        return left;
    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********" << endl;
    std::vector<int> input{7,2,5,10,8};
    printArray(input);

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.splitArray(input, 2);

    // 3. Print the result
    cout << "*********" << endl;
    printResult(result);

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
