#include "../prepare.hpp"
using namespace std;

//=============================================================================
// Question:
// 给定一个二叉树, 找到该树中两个指定节点的最近公共祖先。
//
// 百度百科中最近公共祖先的定义为：“对于有根树 T 的两个节点 p、q，最近公共祖先表示为一个节点 x，
// 满足 x 是 p、q 的祖先且 x 的深度尽可能大（一个节点也可以是它自己的祖先）。”
// 输入：root = [3,5,1,6,2,0,8,null,null,7,4], p = 5, q = 1
// 输出：3
// 解释：节点 5 和节点 1 的最近公共祖先是节点 3 。
//=============================================================================
class Solution {
public:
    TreeNode* res=nullptr;
    bool dfs(TreeNode* root, TreeNode* p, TreeNode* q) {
        if (root == nullptr) {
            return false;
        }
        bool fl = dfs(root->left, p, q);
        bool rl = dfs(root->right, p, q);
        if ((fl && rl) || ((fl || rl) && (root->val == p->val || root->val == q->val))) {
            res = root;
        }
        return ((root->val == p->val || root->val == q->val) || fl || rl);
    }

    TreeNode* lowestCommonAncestor(TreeNode* root, TreeNode* p, TreeNode* q) {
        dfs(root, p, q);
        return res;
    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********\n" << "Input Tree:" << endl;
    TreeNode* root = createTree({1,2,3,4,5,6,7});
    printTree(root);

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution...\n" << endl;
    Solution sol;
    auto result = sol.connect(root);
    printResult(result);

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
