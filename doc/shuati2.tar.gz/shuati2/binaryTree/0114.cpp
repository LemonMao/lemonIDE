#include "../prepare.hpp"
using namespace std;

//=============================================================================
// Question:
/**
  * 给你二叉树的根结点 root ，请你将它展开为一个单链表：
  *
  *     展开后的单链表应该同样使用 TreeNode ，其中 right 子指针指向链表中下一个结点，而左子指针始终为 null 。
  *     展开后的单链表应该与二叉树 先序遍历 顺序相同。
  * 输入：root = [1,2,5,3,4,null,6]
  * 输出：[1,null,2,null,3,null,4,null,5,null,6]
  */
//=============================================================================
class Solution {
public:
    void flatten(TreeNode* root) {
        flatten2(root);
    }

    TreeNode* flatten2(TreeNode* root)
    {
        if (root == nullptr) {
            return nullptr;
        }

        auto leftright  = flatten2(root->left);
        auto rightright = flatten2(root->right);

        if (leftright == nullptr && rightright == nullptr) {
            return root;
        }

        if (leftright) {
            leftright->right = root->right;
            root->right = root->left;
            root->left = nullptr;
        }

        return rightright ? rightright : leftright;
    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********\n" << "Input Tree:" << endl;
    TreeNode* root = createTree({1,2,5,3,4,-1,6});
    printTree(root);

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution...\n" << endl;
    Solution sol;
    sol.flatten(root);
    printResult(root);

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
