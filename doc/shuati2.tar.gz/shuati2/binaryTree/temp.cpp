#include "../prepare.hpp"
#include <string>
#include <vector>
using namespace std;

//=============================================================================
// Question:
//=============================================================================
class Solution {
public:
    vector<string> res;
    vector<string> traverse(TreeNode* root, int k) {
        traverse2(root, k);
        return res;
    }
    void traverse2(TreeNode* root, int k) {
        if (root == nullptr) {
            return;
        }

        std::string s;
        traverse3(root, k, s);
        res.push_back(s);

        traverse2(root->left, k);
        traverse2(root->right, k);
    }
    void traverse3(TreeNode* root, int k, string& s) {
        if (root == nullptr) {
            return;
        }
        if (k == 0) {
            return;
        }

        s.append(std::to_string(root->val));
        traverse3(root->left, k-1, s);
        traverse3(root->right, k-1, s);
    }
};

int main(int argc, const char *argv[])
{
    cout << "*********\n" << "Input Tree:" << endl;
    TreeNode* root = createTree({1,2,3,4,5,6,7,8});
    printTree(root);

    cout << "*********\n" << "Do solution...\n" << endl;
    Solution sol;
    auto result = sol.traverse(root, 2);
    printResult(result);

    cout << "*********" << endl;
    return 0;
} /* end of main */
