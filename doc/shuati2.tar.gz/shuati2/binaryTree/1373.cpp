#include "../prepare.hpp"
using namespace std;

//=============================================================================
// Question:
// 给你一棵以 root 为根的 二叉树 ，请你返回 任意 二叉搜索子树的最大键值和。
//
// 二叉搜索树的定义如下：
//
// 任意节点的左子树中的键值都 小于 此节点的键值。
// 任意节点的右子树中的键值都 大于 此节点的键值。
// 任意节点的左子树和右子树都是二叉搜索树。
// 输入：root = [1,4,3,2,4,2,5,null,null,null,null,null,null,4,6]
// 输出：20
// 解释：键值为 3 的子树是和最大的二叉搜索树
//=============================================================================
class Solution {
public:
    int res=0;
    int maxSumBST(TreeNode* root)
    {
        int sum=0, min=0, max=0;
        traverse(root, &sum, &min, &max);
        return res;
    }

    bool traverse(TreeNode* root, int* sum, int* min, int* max)
    {
        int rsum=0, rmin=0, rmax=0;
        auto isrtbst = traverse(root->right, &rsum, &rmin, &rmax);
        int lsum=0, lmin=0, lmax=0;
        auto isltbst = traverse(root->left, &lsum, &lmin, &lmax);

        if (isrtbst && isltbst && lmax < root->val && rmin > root->val) {
            int rsum = root->val + rsum + lsum;
            res = max(res, rsum);
            *sum = rsum;
            *min = lmin;
            *max = rmax;
            return true;
        }
        return false;

    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********\n" << "Input Tree:" << endl;
    TreeNode* root = createTree({1,4,3,2,4,2,5,-1,-1,-1,-1,-1,-1,4,6});
    printTree(root);

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution...\n" << endl;
    Solution sol;
    auto result = sol.maxSumBST(root);
    printResult(result);

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
