#include "../prepare.hpp"
#include <algorithm>
#include <deque>
#include <vector>
using namespace std;

//=============================================================================
// Question:
// 给你二叉树的根节点 root ，返回其节点值的 锯齿形层序遍历 。（即先从左往右，再从右往左进行下一层遍历，以此类推，层与层之间交替进行）。
// 输入：root = [3,9,20,null,null,15,7]
// 输出：[[3],[20,9],[15,7]]
//=============================================================================
class Solution {
public:
    vector<vector<int>> res;
    vector<vector<int>> zigzagLevelOrder(TreeNode* root) {
        if (!root) {
            return res;
        }
        deque<TreeNode*> q;
        q.push_back(root);
        bool right = false;

        while (!q.empty())
        {
            auto size = q.size();
            vector<int> vals;
            for (int i=0; i < size; i++) {
                auto node = q.front();
                q.pop_front();
                if (node->left) {
                    q.push_back(node->left);
                }
                if (node->right) {
                    q.push_back(node->right);
                }
                vals.push_back(node->val);
            }
            if (right) {
                reverse(vals.begin(), vals.end());
            }
            res.push_back(vals);
            right = !right;
        }

        return res;
    }
};

int main(int argc, const char *argv[])
{
    cout << "*********\n" << "Input Tree:" << endl;
    TreeNode* root = createTree({1,2,3,4,-1,-1,5});
    printTree(root);

    cout << "*********\n" << "Do solution...\n" << endl;
    Solution sol;
    auto result = sol.zigzagLevelOrder(root);
    printResult(result);

    cout << "*********" << endl;
    return 0;
} /* end of main */
