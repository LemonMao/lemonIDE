#include "../prepare.hpp"
using namespace std;

//=============================================================================
// Question: 转换累加树
// 给出二叉 搜索 树的根节点，该树的节点值各不相同，请你将其转换为累加树（Greater Sum Tree），
// 使每个节点 node 的新值等于原树中大于或等于 node.val 的值之和。
// 输入：[4,1,6,0,2,5,7,null,null,null,3,null,null,null,8]
// 输出：[30,36,21,36,35,26,15,null,null,null,33,null,null,null,8]
//=============================================================================
class Solution {
public:
    TreeNode* accumulate(TreeNode* root)
    {
        (void)accumulate2(root, 0);
        return root;
    }

    int accumulate2(TreeNode* root, int max)
    {
        if (root == nullptr) {
            return max;
        }
        auto rm = accumulate2(root->right, max);
        root->val = rm + root->val;
        auto lm = accumulate2(root->left, root->val);
        return lm;
    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********\n" << "Input Tree:" << endl;
    TreeNode* root = createTree({4,1,6,0,2,5,7,-1,-1,-1,3,-1,-1,-1,8});
    printTree(root);

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution...\n" << endl;
    Solution sol;
    TreeNode* result = sol.accumulate(root);
    printResult(result);

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
