#include "../prepare.hpp"
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;

//=============================================================================
// Question: 652 寻找重复的子树
// 给你一棵二叉树的根节点 root ，返回所有 重复的子树 。
// 对于同一类的重复子树，你只需要返回其中任意 一棵 的根结点即可。
// 如果两棵树具有 相同的结构 和 相同的结点值 ，则认为二者是 重复 的。
// 输入：root = [1,2,3,4,null,2,4,null,null,4]
// 输出：[[2,4],[4]]
//=============================================================================
class Solution {
public:
    vector<TreeNode*> res;
    unordered_map<string, int> map;

    vector<TreeNode*> findDuplicateSubtrees(TreeNode* root)
    {
        (void) traverse(root);
        return res;
    }

    string traverse(TreeNode* node)
    {
        if (node == nullptr) {
            return string("#");
        }

        auto ls = traverse(node->left);
        auto rs = traverse(node->right);

        auto key = ls + "," + rs + "," + to_string(node->val);
        map[key]++;
        // std::cout << "Insert key: " << key << std::endl;
        if (map[key] == 2) {
            res.push_back(node);
        }

        return key;
    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********\n" << "Input Tree:" << endl;
    TreeNode* root = createTree({10,2,22,1,12,1,1});
    printTree(root);

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution...\n" << endl;
    Solution sol;
    auto result = sol.findDuplicateSubtrees(root);
    for (auto tree : result) {
        printResult(tree);
    }

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
