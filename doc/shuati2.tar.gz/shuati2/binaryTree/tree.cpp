#include "../prepare.hpp"
using namespace std;

//=============================================================================
// Question:
//=============================================================================
class Solution {
public:
    TreeNode* connect(TreeNode* root)
    {
    }
};

int main(int argc, const char *argv[])
{
    cout << "*********\n" << "Input Tree:" << endl;
    TreeNode* root = createTree({1,2,3,4,5,6,7});
    printTree(root);

    cout << "*********\n" << "Do solution...\n" << endl;
    Solution sol;
    auto result = sol.connect(root);
    printResult(result);

    cout << "*********" << endl;
    return 0;
} /* end of main */
