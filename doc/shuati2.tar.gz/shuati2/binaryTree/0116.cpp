#include "../prepare.hpp"
using namespace std;

//=============================================================================
// Question: 把二叉树的每一层节点都用next指针连接起来
// 给定一个 完美二叉树 ，其所有叶子节点都在同一层，每个父节点都有两个子节点。二叉树定义如下：
/*
 *
 * struct Node {
 *   int val;
 *   Node *left;
 *   Node *right;
 *   Node *next;
 * }
 *
 * 填充它的每个 next 指针，让这个指针指向其下一个右侧节点。如果找不到下一个右侧节点，则将 next 指针设置为 NULL。
 *
 * 初始状态下，所有 next 指针都被设置为 NULL。
 * 输入：root = [1,2,3,4,5,6,7]
 * 输出：[1,#,2,3,#,4,5,6,7,#]
 * 解释：给定二叉树如图 A 所示，你的函数应该填充它的每个 next 指针，以指向其下一个右侧节点，如图 B 所示。序列化的输出按层序遍历排列，同一层节点由 next 指针连接，'#' 标志着每一层的结束。
 */
//=============================================================================
class Solution {
public:
    void connect(TreeNode* root)
    {
        connect2(root, nullptr);
        return;
    }

    void connect2(TreeNode* root, TreeNode* uncle)
    {
        if (root->left == nullptr && root->right == nullptr) {
            return;
        }
        root->left->next = root->right;
        root->right->next = uncle ? uncle->left : nullptr;
        connect2(root->left, root->right);
        connect2(root->right, uncle ? uncle->left : nullptr);
        return;
    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********\n" << "Input Tree:" << endl;
    TreeNode* root = createTree({-1,0,1,2,3,4,5,6,7,8,9,10,11,12,13});
    printTree(root);

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution...\n" << endl;
    // Solution sol;
    // TreeNode* result = sol.connect(root);
    // printResult(result);

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
