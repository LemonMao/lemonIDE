#include "../prepare.hpp"
#include <span>
#include <unordered_map>
#include <vector>
using namespace std;

//=============================================================================
// Question: 从前序与中序遍历序列构造二叉树
// 给定两个整数数组 preorder 和 inorder ，其中 preorder 是二叉树的先序遍历，
// inorder 是同一棵树的中序遍历，请构造二叉树并返回其根节点。
// 输入: preorder = [3,9,20,15,7], inorder = [9,3,15,20,7]
// 输出: [3,9,20,null,null,15,7]
//=============================================================================
class Solution {
public:
    span<int> getLeftTreeSpan(span<int> inorder, int rootval){
        for (int i=0; i < inorder.size(); i++) {
            if (inorder[i] == rootval) {
                return inorder.subspan(0, i);
            }
        }
        return span<int>();
    }

    span<int> getRightTreeSpan(span<int> inorder, int rootval){
        for (int i=0; i < inorder.size(); i++) {
            if (inorder[i] == rootval) {
                return inorder.subspan(i+1, inorder.size()-i-1);
            }
        }
        return span<int>();
    }

    TreeNode* buildTree(span<int> preorder, span<int> inorder)
    {
        if (preorder.empty() || inorder.empty()) {
            return nullptr;
        }

        TreeNode* node = new TreeNode(preorder.front());

        span<int> left_inorder_span = getLeftTreeSpan(inorder, preorder.front());
        auto left_preorder_span = preorder.subspan(1, left_inorder_span.size());
        node->left = buildTree(left_preorder_span, left_inorder_span);

        span<int> right_inorder_span = getRightTreeSpan(inorder, preorder.front());
        auto right_preorder_span = preorder.subspan(1+left_inorder_span.size(), right_inorder_span.size());
        node->right = buildTree(right_preorder_span, right_inorder_span);

        return node;
    }

    // normal impl
    unordered_map<int, int> maps;
    TreeNode* buildTree2(vector<int>& preorder, vector<int>& inorder) {
        for (int i=0; i < inorder.size(); i++) {
            maps[inorder[i]] = i;
        }

        return build(preorder, 0, preorder.size()-1, inorder, 0, inorder.size()-1);
    }

    TreeNode* build(vector<int>& po, int ps, int pe, vector<int>& io, int is, int ie) {
        if (ps > pe || is > ie) {
            return nullptr;
        }
        TreeNode* root = new TreeNode();
        root->val = po[ps];

        int io_root_idx = maps[po[ps]];
        int n = io_root_idx - is;

        root->left  = build(po, ps+1, ps+n, io, is, io_root_idx-1);
        root->right = build(po, ps+n+1, pe, io, io_root_idx+1, ie);
        return root;
    }

};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********\n" << "Input Tree:" << endl;
    vector<int> preorder {3,9,20,15,7};
    vector<int> inorder {9,3,15,20,7};

    printResult(preorder);
    printResult(inorder);

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution...\n" << endl;
    Solution sol;
    TreeNode* result = sol.buildTree(preorder, inorder);
    printResult(result);

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
