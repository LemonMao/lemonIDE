#include "../prepare.hpp"
#include <unordered_map>
#include <vector>
#include <span>

using namespace std;

//=============================================================================
// Question: 最大二叉树
// 给定一个不重复的整数数组 nums 。 最大二叉树 可以用下面的算法从 nums 递归地构建:
//
// 创建一个根节点，其值为 nums 中的最大值。
// 递归地在最大值 左边 的 子数组前缀上 构建左子树。
// 递归地在最大值 右边 的 子数组后缀上 构建右子树。
// 返回 nums 构建的 最大二叉树 。
// 输入：nums = [3,2,1,6,0,5]
// 输出：[6,3,5,null,2,0,null,null,1]
//=============================================================================
class Solution {
public:
    std::size_t findMaxIdx(std::span<int> nums)
    {
        auto max_it = std::max_element(nums.begin(), nums.end());
        return std::distance(nums.begin(), max_it);
    }

    TreeNode* constructMaximumBinaryTree(std::span<int> nums)
    {
        if (nums.empty()) {
            return nullptr;
        }

        int mi = findMaxIdx(nums);
        TreeNode* left  = constructMaximumBinaryTree(nums.subspan(0, mi));
        TreeNode* right = constructMaximumBinaryTree(nums.subspan(mi+1, nums.size()-mi-1));

        TreeNode* node = new TreeNode(nums[mi]);
        node->left = left;
        node->right = right;
        return node;
    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********\n" << "Input Tree:" << endl;
    vector<int> root {3,2,1,6,0,5};
    printArray(root);

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution...\n" << endl;
    Solution sol;
    TreeNode* result = sol.constructMaximumBinaryTree(root);
    printResult(result);

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
