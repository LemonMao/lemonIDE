#include "../prepare.hpp"
using namespace std;

//=============================================================================
// Question:
// 给你一个二叉树的根节点 root ，判断其是否是一个有效的二叉搜索树。
/*
 * 有效 二叉搜索树定义如下：
 *
 * 节点的左子树只包含 小于 当前节点的数。
 * 节点的右子树只包含 大于 当前节点的数。
 * 所有左子树和右子树自身必须也是二叉搜索树。
 * 输入：root = [5,1,4,null,null,3,6]
输出：false
解释：根节点的值是 5 ，但是右子节点的值是 4 。
 * */
//=============================================================================
class Solution {
public:
    bool isValidBST(TreeNode* root)
    {
        return isValidBST2(root, nullptr, nullptr);
    }

    bool isValidBST2(TreeNode* root, TreeNode* min, TreeNode* max)
    {
        if (root == nullptr) {
            return true;
        }

        if (min != nullptr && root->val < min->val) {
            return false;
        }

        if (max != nullptr && root->val > max->val) {
            return false;
        }

        return isValidBST2(root->left, min, root) && isValidBST2(root->right, root, max);
    }

};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********\n" << "Input Tree:" << endl;
    TreeNode* root = createTree({5,1,4,-1,-1,3,6});
    printTree(root);

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution...\n" << endl;
    Solution sol;
    auto result = sol.isValidBST(root);
    printResult(result);

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
