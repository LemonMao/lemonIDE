#include "prepare.hpp"
#include <algorithm>
#include <cassert>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;

class Solution {
public:
    int res = 0;
    int cv = 0;
    int knapsack(int W, int N, vector<int>& wt, vector<int>& val) {
        dfs(W, 0, wt, val);
        return res;
    }

    void dfs(int W, int start, vector<int>& wt, vector<int>& val) {
        int num = wt.size();

        if (start == wt.size()) {
            return;
        }

        for (int i = start; i < num; i++) {
            if (W - wt[i] < 0) {
                continue;
            }
            cv += val[i];
            res = max(res, cv);
            dfs(W-wt[i], i+1, wt, val);
            cv -= val[i];
        }
        return;
    }

    vector<vector<int>> mem;
    int knapsack2(int W, int N, vector<int>& wt, vector<int>& val) {
        mem.assign(N+1, vector<int>(W + 1, -1)); // Initialize mem table with -1
        return dp(W, 0, wt, val);
    }

    int dp(int W, int start, vector<int>& wt, vector<int>& val) {
        if (start == wt.size()) {
            return 0;
        }

        if (mem[start][W] != -1) {
            return mem[start][W];
        }

        int res = 0;
        if (wt[start] > W) {
            res = dp(W, start+1, wt, val);
        }
        else {
            res = max(val[start] + dp(W-wt[start], start+1, wt, val), dp(W, start+1, wt, val));
        }
        mem[start][W] = res;
        return res;
    }

};

int main(int argc, const char *argv[])
{
    vector<int> wt {2, 1, 3};
    printResult(wt);
    vector<int> val {4, 2, 3};
    printResult(val);

    Solution sol;
    auto res = sol.knapsack2(4, 3, wt, val);
    std::cout << "--- Do solution:" << std::endl;
    printResult(res);
    assert(res == 6);

    // New test case
    vector<int> wt2 {7, 3, 4};
    printResult(wt2);
    vector<int> val2 {10, 6, 9};
    printResult(val2);

    auto res2 = sol.knapsack2(14, 3, wt2, val2);
    std::cout << "--- Do solution 2:" << std::endl;
    printResult(res2);
    assert(res2 == 25);
} /* end of main */
