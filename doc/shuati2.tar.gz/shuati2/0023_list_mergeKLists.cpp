
#include "prepare.hpp"
using namespace std;



/* 给你一个链表数组，每个链表都已经按升序排列。
 * Cate-list
 *
 * 请你将所有链表合并到一个升序链表中，返回合并后的链表。
 *
 * 示例 1：
 *
 * 输入：lists = [[1,4,5],[1,3,4],[2,6]]
 * 输出：[1,1,2,3,4,4,5,6]
 * 解释：链表数组如下：
 * [
 *   1->4->5,
 *   1->3->4,
 *   2->6
 * ]
 * 将它们合并到一个有序链表中得到。
 * 1->1->2->3->4->4->5->6
 * 示例 2：
 *
 * 输入：lists = []
 * 输出：[]
 * 示例 3：
 *
 * 输入：lists = [[]]
 * 输出：[]
 * 提示：
 *
 * k == lists.length
 * 0 <= k <= 10^4
 * 0 <= lists[i].length <= 500
 * -10^4 <= lists[i][j] <= 10^4
 * lists[i] 按 升序 排列
 * lists[i].length 的总和不超过 10^4
 *  */

class Solution {
public:
    ListNode* mergeKLists(vector<ListNode*>& lists)
    {
        if (lists.size() < 1) {
            return nullptr;
        }
        if (lists.size() == 1) {
            return lists[0];
        }

        ListNode* target = lists[0];

        for (int i = 1; i < lists.size(); i++) {
            target = merge(target, lists[i]);
        }
        return target;
    }

    ListNode* merge(ListNode* l1, ListNode* l2) {
        ListNode head;
        ListNode* res = &head;

        while (l1 != nullptr && l2 != nullptr) {
            if (l1->val < l2->val) {
                res->next = l1;
                l1 = l1->next;
            }
            else {
                res->next = l2;
                l2 = l2->next;
            }
            res = res->next;
        }

        if (l1 != nullptr) {
            res->next = l1;
        }
        else if (l2 != nullptr) {
            res->next = l2;
        }

        return head.next;
    }
};


int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********" << endl;
    auto input = createLists({{1,4,5}, {1,3,4}, {2, 6}});
    printResult(input);

    // 2. Print that we are going on Solution
    cout << "*********" << endl;
    Solution sol;
    ListNode* result = sol.mergeKLists(input);

    // 3. Print the result
    cout << "*********" << endl;
    printList(result);

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
