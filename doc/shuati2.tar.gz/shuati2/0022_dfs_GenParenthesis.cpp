#include "prepare.hpp"
#include <string>
using namespace std;

//=============================================================================
// Cate-list
// Question:
// 数字 n 代表生成括号的对数，请你设计一个函数，用于能够生成所有可能的并且 有效的 括号组合。
// 示例 1：
//
// 输入：n = 3
// 输出：["((()))","(()())","(())()","()(())","()()()"]
// 示例 2：
//
// 输入：n = 1
// 输出：["()"]
//
//
// 提示：
//
// 1 <= n <= 8
//
//=============================================================================
class Solution {
public:
    vector<string>  res;
    string selectors = "()";
    vector<string> generateParenthesis(int n)
    {
        string str;
        backtrace(str, n*2);
        return res;
    }
    bool isValidInsert(string &str, char c, int n) {
        int lc = 0, rc = 0;
        for (char c : str) {
            if (c == '(') {
                lc++;
            }
            else if (c == ')') {
                rc++;
            }
        }
        if (c == ')') {
            rc++;
        }
        else {
            lc++;
        }

        return lc >= rc && lc <= n/2;
    }
    void backtrace(string &str, int n)
    {
        if (str.size() == n) {
            res.push_back(str);
            return;
        }

        for (auto c : selectors) {
            if (!isValidInsert(str, c, n)) {
                continue;
            }
            str.push_back(c);
            backtrace(str, n);
            str.pop_back();
        }
        return;
    }
};

int main(int argc, const char *argv[])
{
    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.generateParenthesis(4);
    printResult(result);

    cout << "*********" << endl;
    return 0;
} /* end of main */
