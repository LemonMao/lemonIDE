#include "prepare.hpp"
#include <vector>
using namespace std;

//=============================================================================
// Cate-arr
// Question:
// 给你一个按照非递减顺序排列的整数数组 nums，和一个目标值 target。请你找出给定目标值在数组中的开始位置和结束位置。
// 如果数组中不存在目标值 target，返回 [-1, -1]。
// 你必须设计并实现时间复杂度为 O(log n) 的算法解决此问题。
//
// 示例 1：
// 输入：nums = [5,7,7,8,8,10], target = 8
// 输出：[3,4]
//=============================================================================
class Solution {
public:
    vector<int> searchRange(vector<int>& nums, int target) {
        if (nums.empty()) {
            return {-1, -1};
        }

        int l = leftBound(nums, 0, nums.size(), target);
        int r = l == -1 ? -1 : rightBound(nums, l, nums.size(), target);
        return vector<int> {l, r};
    }

    int leftBound(vector<int>& nums, int s, int e, int t) {
        int maxidx = e;
        while (s < e)
        {
            int mid = s + (e - s) / 2;
            if (nums[mid] >= t) {
                e = mid;
            }
            else if (nums[mid] < t) {
                s = mid + 1;
            }
        }
        if (s != maxidx && nums[s] == t) {
            return s;
        }
        return -1;
    }

    int rightBound(vector<int>& nums, int s, int e, int t) {
        int maxidx = e;
        while (s < e)
        {
            int mid = s + (e - s) / 2;
            if (nums[mid] > t) {
                e = mid;
            }
            else if (nums[mid] <= t) {
                s = mid + 1;
            }
        }
        if (s-1 != maxidx && nums[s-1] == t) {
            return s-1;
        }
        return -1;
    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********" << endl;
    // std::vector<int> input{5,7,8,8,9,10};
    std::vector<int> input{2, 2};
    printArray(input);

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.searchRange(input, 3);

    // 3. Print the result
    cout << "*********" << endl;
    printArray(result);

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
