#include "prepare.hpp"
#include <algorithm>
#include <queue>
#include <stack>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;

//=============================================================================
// Cate-arr
// Question:
// 给定两个长度相等的数组 nums1 和 nums2，nums1 相对于 nums2 的优势可以用满足
// nums1[i] > nums2[i] 的索引 i 的数目来描述。
//
// 返回 nums1 的 任意 排列，使其相对于 nums2 的优势最大化。
//
// 示例 1：
//
// 输入：nums1 = [2,7,11,15], nums2 = [1,10,4,11]
// 输出：[2,11,7,15]
//
// 示例 2：
//
// 输入：nums1 = [12,24,8,32], nums2 = [13,25,32,11]
// 输出：[24,32,8,12]
//
//=============================================================================
class Solution {
public:
    vector<int> advantageCount(vector<int>& nums1, vector<int>& nums2) {
        vector<int> res(nums1.size());
        sort(nums1.begin(), nums1.end());

        priority_queue<pair<int, int>> nums2Que;
        for (int i=0; i < nums2.size(); i++) {
            nums2Que.push({nums2[i], i});
        }

        for (int l=0, r=nums1.size()-1; r >= l;) {
            int v1 = nums1[r];
            int v2 = nums2Que.top().first;
            int v2idx = nums2Que.top().second;
            nums2Que.pop();

            if (v1 > v2) {
                res[v2idx] = v1;
                r--;
            }
            else {
                res[v2idx] = nums1[l];
                l++;
            }
        }
        return res;
    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********" << endl;
    std::vector<int> input1{12,24,8,32};
    std::vector<int> input2{13,25,32,11};
    printArray(input1);
    printArray(input2);

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.advantageCount(input1, input2);

    // 3. Print the result
    cout << "*********" << endl;
    printResult(result);

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
