#include "prepare.hpp"
#include <unordered_set>
#include <vector>
using namespace std;

//=============================================================================
//  backtrace
//  子序列 - 全排列 - 组合
//=============================================================================

//=============================================================================
// Cate-dfs
//
// Question:
// 给你一个整数数组 nums ，数组中的元素 互不相同 。返回该数组所有可能的子集（幂集）。
//
// 解集 不能 包含重复的子集。你可以按 任意顺序 返回解集。
//
// 示例 1：
//
// 输入：nums = [1,2,3]
// 输出：[[],[1],[2],[1,2],[3],[1,3],[2,3],[1,2,3]]
// 示例 2：
//
// 输入：nums = [0]
// 输出：[[],[0]]
//
//
// 提示：
//
// 1 <= nums.length <= 10
// -10 <= nums[i] <= 10
// nums 中的所有元素 互不相同
//=============================================================================
class Solution {
public:
    vector<vector<int>> result;
    unordered_set<int> used;
    vector<vector<int>> subsets(vector<int>& nums) {
        vector<int> path;
        // backtrack(nums, 0, path);
        backtrack2(nums, path);
        return result;
    }

private:
    //  subset
    void backtrack(const vector<int>& nums, int start_index, vector<int>& path) {
        result.push_back(path); // Add the current subset to the result

        for (int i = start_index; i < nums.size(); ++i) {
            path.push_back(nums[i]); // Include the current element
            backtrack(nums, i + 1, path); // Recurse with the next element
            path.pop_back(); // Backtrack: remove the current element to explore other subsets
        }
    }

    // 全排列
    void backtrack2(const vector<int>& nums, vector<int>& path) {
        if (path.size() == nums.size()) {
            result.push_back(path);
        }

        for (auto &num : nums) {
            if (used.contains(num)) {
                continue;
            }
            path.push_back(num);
            used.insert(num);
            backtrack2(nums, path);
            path.pop_back();
            used.erase(num);
        }
    }

public:
    // 组合 也是 序列， 1-3 he  3-1 是一样的
    // 给定两个整数 n 和 k，返回 1 ... n 中所有可能的 k 个数的组合。
    vector<vector<int>> combine(int n, int k)
    {
        vector<vector<int>>  res;
        vector<int> path;
        backtrack3(res, path, 1, n, k);
        return res;
    }
private:
    void backtrack3(vector<vector<int>> &res, vector<int> &path, int start, int n, int k)
    {
        if (k == 0) {
            res.push_back(path);
            return;
        }

        for (int i = start; i <= n; i++) {
            path.push_back(i);
            backtrack3(res, path, i+1, n, k-1);
            path.pop_back();
        }
    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********" << endl;
    std::vector<int> input{1,2,3};
    printArray(input);

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    // auto result = sol.subsets(input);
    auto result = sol.combine(4, 2);

    // 3. Print the result
    cout << "*********" << endl;
    printResult(result);

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
