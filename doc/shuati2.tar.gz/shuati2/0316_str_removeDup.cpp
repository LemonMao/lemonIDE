#include "prepare.hpp"
#include <stack>
#include <string>
#include <unordered_map>
#include <unordered_set>
using namespace std;

//=============================================================================
// Cate-str
// Question: 去除重复字母  - M
// 给你一个字符串 s ，请你去除字符串中重复的字母，使得每个字母只出现一次。需保证 返回结果的字典序最小（要求不能打乱其他字符的相对位置）。
//
// 示例 1：
//
// 输入：s = "bcabc"
// 输出："abc"
//
//=============================================================================
class Solution {
public:
    string removeDup(string& s){
        unordered_map<char, int> instr;
        unordered_set<char> instack;
        for (auto c : s) {
            instr[c]++;
        }

        string st;
        for (auto c : s) {
            while (!st.empty() && !instack.count(c) && st.back() >= c && instr[st.back()] > 0)
            {
                instack.erase(st.back());
                st.pop_back();
            }
            if (!instack.count(c)) {
                st.push_back(c);
                instack.insert(c);
            }
            instr[c]--;
        }

        return st;
    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********" << endl;
    string input = "bbcaac";
    std::cout << "Input: " << input << std::endl;

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    auto result = sol.removeDup(input);

    // 3. Print the result
    cout << "*********" << endl;
    std::cout << "Result: " << result << std::endl;

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
