#include "prepare.hpp"
using namespace std;

// Cate-List
//
// Question:
// 给定单链表的头节点 head ，请反转链表，并返回反转后的链表的头节点。
// 输入：head = [1,2,3,4,5]
// 输出：[5,4,3,2,1]
//
// 反转链表
// - 迭代反转
// - 递归反转
// - 反转前N个
// - 反转【M,N】区间

class Solution {
public:
    // iterater
    ListNode* reverse(ListNode* head)
    {
        ListNode *prev = nullptr, *cur = head, *next = nullptr;
        while (cur != nullptr)
        {
            next = cur->next;
            cur->next = prev;
            prev = cur;
            cur = next;
        }
        return prev;
    }

    // recurse
    ListNode* nhead = nullptr;
    ListNode* nnext = nullptr;
    ListNode* reverse2(ListNode* head)
    {
        if (head->next == nullptr) {
            nhead = head;
            return head;
        }

        auto last = reverse2(head->next);
        last->next = head;
        head->next = nullptr;
        return head;
    }

    // reverse 前N个
    ListNode* reverse3(ListNode* head, int k)
    {
        if (k == 1) {
            nhead = head;
            nnext = head->next;
            return head;
        }

        auto last = reverse3(head->next, k-1);
        last->next = head;
        head->next = nnext;
        return head;
    }

    // 反转区间
    ListNode* reverse4(ListNode* head, int m, int n)
    {
        int cnt = 1;
        ListNode* node = head;
        ListNode* prev = nullptr;
        while (cnt < m)
        {
            prev = node;
            node = node->next;
            cnt++;
        }

        reverse3(node, n-m+1);
        prev->next = nhead;
        return head;
    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********" << endl;
    ListNode* input = createList({1,2,3,4,5});
    printList(input);

    // 2. Print that we are going on Solution
    Solution sol;
    // cout << "*********\n" << "Do solution 3..." << endl;
    // ListNode* result = sol.reverse3(input, 3);
    // printResult(sol.nhead);
    cout << "*********\n" << "Do solution 4..." << endl;
    ListNode* result2 = sol.reverse4(input, 2, 3);
    printResult(result2);

    // 4. End
    cout << "*********" << endl;
    return 0;
}
