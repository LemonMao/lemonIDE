
#include "prepare.hpp"
using namespace std;

//=============================================================================
// question:
//
// 给你单链表的头结点 head ，请你找出并返回链表的中间结点。
//
// 如果有两个中间结点，则返回第二个中间结点。
//
// 输入：head = [1,2,3,4,5,6]
// 输出：[4,5,6]
// 解释：该链表有两个中间结点，值分别为 3 和 4 ，返回第二个结点。
//
// 输入：head = [1,2,3,4,5]
// 输出：[3,4,5]
// 解释：链表只有一个中间结点，值为 3 。
//=============================================================================
class Solution {
public:
    ListNode* getMiddleNode(ListNode* head)
    {
        ListNode *slow = head, *fast = head;
        int fi = 0;

        while (fast->next != nullptr)
        {
            fast = fast->next;
            fi++;
            if (fi % 2 == 0)
            {
                slow = slow->next;
            }
        }
        if (fi % 2 != 0) {
            slow = slow->next;
        }

        return slow;
    }
};

int main(int argc, const char *argv[])
{
    // 1. Construct input example structure and print them
    cout << "*********" << endl;
    ListNode* input = createList({1,2,3,4,5});
    printList(input);

    // 2. Print that we are going on Solution
    cout << "*********\n" << "Do solution..." << endl;
    Solution sol;
    ListNode* result = sol.getMiddleNode(input);

    // 3. Print the result
    cout << "*********" << endl;
    printList(result);

    // 4. End
    cout << "*********" << endl;
    return 0;
} /* end of main */
